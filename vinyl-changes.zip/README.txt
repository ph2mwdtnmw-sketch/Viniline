Vinyl changes for Resona (v3)
1. Fork https://github.com/savo-o/resona on GitHub (or reuse your fork).
2. In your fork: Add file -> Upload files. Drag the folders "app" and ".github" from this archive. Commit to main.
3. Open the Actions tab, wait for "Build APK" to finish, download the "vinyl-apk" artifact.
4. Install app-universal-debug.apk on the phone (Android 8.0+).
