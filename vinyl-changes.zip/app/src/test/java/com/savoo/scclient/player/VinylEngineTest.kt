package com.savoo.scclient.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class VinylEngineTest {
    private val sr = 44100
    private val block = 128

    private fun rms(a: FloatArray, from: Int, to: Int): Double =
        sqrt((from until to).sumOf { (a[it] * a[it]).toDouble() } / (to - from))

    private fun risingZeroCrossingsPerSecond(a: FloatArray, from: Int, to: Int): Double {
        var z = 0
        for (i in from + 1 until to) if (a[i - 1] <= 0f && a[i] > 0f) z++
        return z / ((to - from) / sr.toDouble())
    }

    /**
     * Records 2 s of a 440 Hz tone, then plays the plan (speed, seconds) through the scratch voice
     * while the recording keeps running in real time, like the real processor does.
     */
    private fun scratchRun(plan: List<Pair<Float, Double>>): FloatArray {
        val history = ScratchHistory(sr)
        var phase = 0.0
        fun record(frames: Int) {
            repeat(frames) {
                phase += 2 * PI * 440.0 / sr
                val x = (0.5 * sin(phase)).toFloat()
                history.write(x, x)
            }
            history.commit()
        }
        record(sr * 2)
        val voice = ScratchVoice(history, VinylNoise(sr), VinylNoise(sr, 7), frictionAmount = 0f)
        voice.begin(1f, (sr * 0.25f).toInt())
        val out = ArrayList<Float>()
        val buf = ShortArray(block * 2)
        for ((speed, seconds) in plan) {
            var left = (sr * seconds).toInt()
            while (left > 0) {
                val n = min(block, left)
                record(n)
                voice.render(buf, n, true, speed, 0f)
                for (i in 0 until n) out.add(buf[i * 2] / 32768f)
                left -= n
            }
        }
        return out.toFloatArray()
    }

    @Test
    fun historyRecordsAndCommitsInOrder() {
        val h = ScratchHistory(sr)
        repeat(1000) { h.write(it.toFloat(), -it.toFloat()) }
        assertEquals(0L, h.committed)
        h.commit()
        assertEquals(1000L, h.committed)
        h.reset()
        assertEquals(0L, h.committed)
    }

    @Test
    fun heldRecordIsSilent() {
        val o = scratchRun(listOf(0f to 0.6))
        assertTrue(rms(o, (sr * 0.3).toInt(), o.size) < 0.001)
    }

    @Test
    fun reverseAtDoubleSpeedIsAnOctaveUp() {
        val o = scratchRun(listOf(-2f to 0.6))
        val f = risingZeroCrossingsPerSecond(o, (sr * 0.2).toInt(), o.size)
        assertTrue("freq was $f", abs(f - 880.0) < 40.0)
    }

    @Test
    fun forwardAtNormalSpeedKeepsThePitch() {
        val o = scratchRun(listOf(1f to 0.6))
        val f = risingZeroCrossingsPerSecond(o, (sr * 0.2).toInt(), o.size)
        assertTrue("freq was $f", abs(f - 440.0) < 25.0)
    }

    @Test
    fun scratchHasNoClicks() {
        val o = scratchRun(listOf(0f to 0.5, -2f to 0.5, 1f to 0.5, 0f to 0.3))
        var maxJump = 0f
        for (i in 1 until o.size) maxJump = maxOf(maxJump, abs(o[i] - o[i - 1]))
        // A 0.5 amplitude sine at 880 Hz has a maximum step of about 0.063.
        assertTrue("max jump was $maxJump", maxJump < 0.08f)
    }

    @Test
    fun firstBlockStartsFromSilenceWithoutAPop() {
        val o = scratchRun(listOf(1f to 0.05))
        assertTrue("first sample was ${o[0]}", abs(o[0]) < 0.01f)
    }

    @Test
    fun fadesOutAndTellsTheCallerToStop() {
        val history = ScratchHistory(sr)
        repeat(sr) { history.write(0.3f, 0.3f) }
        history.commit()
        val voice = ScratchVoice(history, VinylNoise(sr), VinylNoise(sr, 7))
        voice.begin(1f, 1000)
        val buf = ShortArray(block * 2)
        repeat(20) { voice.render(buf, block, true, 1f, 0f) }
        var alive = true
        var blocks = 0
        while (alive && blocks < 50) {
            alive = voice.render(buf, block, false, 1f, 0f)
            blocks++
        }
        assertFalse(alive)
        assertTrue("took $blocks blocks", blocks <= 6)
        assertEquals(0, buf[buf.size - 1].toInt())
    }

    @Test
    fun readingFarBackNeverCrashesOrGoesOutOfRange() {
        val o = scratchRun(listOf(-4f to 3.0, 4f to 3.0))
        assertTrue(o.none { it.isNaN() || abs(it) > 1f })
    }

    @Test
    fun fingerFrictionIsAudibleWhileMovingButNotWhenHeld() {
        val history = ScratchHistory(sr)
        repeat(sr) { history.write(0f, 0f) }
        history.commit()
        val voice = ScratchVoice(history, VinylNoise(sr), VinylNoise(sr, 7))
        voice.begin(1f, 1000)
        val buf = ShortArray(block * 2)
        var movingPeak = 0
        repeat(40) { voice.render(buf, block, true, -1.5f, 0f); movingPeak = maxOf(movingPeak, buf.maxOf { abs(it.toInt()) }) }
        var heldPeak = 0
        repeat(80) { voice.render(buf, block, true, 0f, 0f) }
        repeat(10) { voice.render(buf, block, true, 0f, 0f); heldPeak = maxOf(heldPeak, buf.maxOf { abs(it.toInt()) }) }
        assertTrue("moving peak $movingPeak", movingPeak > 100)
        assertTrue("held peak $heldPeak", heldPeak < 30)
    }

    @Test
    fun noiseIsSilentWhenOffEvenAfterNeedleDrop() {
        val n = VinylNoise(sr)
        n.needleDrop()
        repeat(sr) { assertEquals(0f, n.next(0f), 0f) }
    }

    @Test
    fun noiseStaysSubtleAndFinite() {
        val n = VinylNoise(sr)
        val buf = FloatArray(sr * 10) { n.next(0.4f) }
        assertTrue(buf.none { it.isNaN() || it.isInfinite() })
        assertTrue(buf.maxOf { abs(it) } < 0.3f)
        assertTrue(rms(buf, 0, buf.size) in 0.001..0.02)
    }
}
