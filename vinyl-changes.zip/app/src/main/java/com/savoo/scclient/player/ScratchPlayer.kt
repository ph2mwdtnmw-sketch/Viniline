package com.savoo.scclient.player

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Process
import android.util.Log

/**
 * Plays the scratch sound on its OWN low-latency AudioTrack, bypassing ExoPlayer.
 *
 * Why: everything that goes through the player sits in its output buffer (about 250 ms by default)
 * before it is heard, so a scratch made that way always lags the finger. Here the finger speed is
 * read every few milliseconds by a dedicated high priority thread, and the output uses the fast
 * audio path (PERFORMANCE_MODE_LOW_LATENCY), so the lag is a few tens of milliseconds.
 *
 * The caller is expected to mute the normal player while this runs.
 */
class ScratchPlayer(private val effects: SoundEffects) {

    @Volatile private var speed = 0f
    @Volatile private var stampNanos = 0L
    @Volatile private var active = false
    @Volatile private var noiseLevel = 0f

    private var thread: Thread? = null
    private var track: AudioTrack? = null
    private var trackSampleRate = 0

    /** Starts scratching. Returns false if there is nothing to scratch yet or audio output failed. */
    @Synchronized
    fun start(initialSpeed: Float, noise: Float): Boolean {
        val history = effects.history ?: return false
        if (history.committed < history.sampleRate / 10) return false

        // A previous voice may still be fading out (a few ms); wait for it.
        thread?.let { runCatching { it.join(100) } }

        val audioTrack = obtainTrack(history.sampleRate) ?: return false
        speed = initialSpeed
        stampNanos = System.nanoTime()
        noiseLevel = noise
        active = true

        val voice = ScratchVoice(
            history,
            VinylNoise(history.sampleRate, 0x1F123BB5),
            VinylNoise(history.sampleRate, 0x3C6EF372),
        )
        val latencyFrames = (history.sampleRate * OUTPUT_LATENCY_MS / 1000f).toInt()
        voice.begin(initialSpeed, latencyFrames)

        thread = Thread({ renderLoop(audioTrack, voice) }, "ScratchPlayer").also { it.start() }
        return true
    }

    /**
     * Creates the audio output ahead of time (it takes 10-50 ms, which would be a visible hitch at
     * the first touch). Safe to call often; does nothing if it is ready or a scratch is running.
     */
    @Synchronized
    fun prepare() {
        val history = effects.history ?: return
        if (thread?.isAlive == true) return
        obtainTrack(history.sampleRate)
    }

    /** Finger speed: 1 = normal forward speed, negative = backwards. Cheap, call as often as you like. */
    fun setSpeed(value: Float) {
        speed = value
        stampNanos = System.nanoTime()
    }

    /** Stops scratching. The voice fades out over a few milliseconds on its own thread. */
    fun stop() {
        active = false
    }

    @Synchronized
    fun release() {
        active = false
        thread?.let { runCatching { it.join(200) } }
        thread = null
        track?.let { runCatching { it.release() } }
        track = null
        trackSampleRate = 0
    }

    private fun renderLoop(audioTrack: AudioTrack, voice: ScratchVoice) {
        runCatching { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO) }
        val block = ShortArray(BLOCK_FRAMES * 2)
        try {
            // Pre-fill one block so the track does not start on an empty buffer.
            voice.render(block, BLOCK_FRAMES, true, currentSpeed(), noiseLevel)
            if (audioTrack.write(block, 0, block.size) < 0) return
            audioTrack.play()
            while (true) {
                val keepGoing = voice.render(block, BLOCK_FRAMES, active, currentSpeed(), noiseLevel)
                // Blocking write: this is what paces the loop to real time.
                if (audioTrack.write(block, 0, block.size) < 0) break
                if (!keepGoing) break
            }
        } catch (t: Throwable) {
            Log.w(TAG, "scratch voice stopped", t)
        } finally {
            runCatching {
                audioTrack.pause()
                audioTrack.flush()
            }
        }
    }

    /** A finger that stopped moving sends no updates, and that has to read as "held still". */
    private fun currentSpeed(): Float =
        if (System.nanoTime() - stampNanos < STALE_NANOS) speed else 0f

    private fun obtainTrack(sampleRate: Int): AudioTrack? {
        track?.let { existing ->
            if (trackSampleRate == sampleRate && existing.state == AudioTrack.STATE_INITIALIZED) return existing
            runCatching { existing.release() }
            track = null
        }
        return try {
            val channelMask = AudioFormat.CHANNEL_OUT_STEREO
            val encoding = AudioFormat.ENCODING_PCM_16BIT
            val minBytes = AudioTrack.getMinBufferSize(sampleRate, channelMask, encoding)
            if (minBytes <= 0) return null
            val created = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build(),
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setEncoding(encoding)
                        .setChannelMask(channelMask)
                        .build(),
                )
                .setBufferSizeInBytes(maxOf(minBytes, BLOCK_FRAMES * 4 * 2))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()
            if (created.state != AudioTrack.STATE_INITIALIZED) {
                created.release()
                return null
            }
            track = created
            trackSampleRate = sampleRate
            created
        } catch (t: Throwable) {
            Log.w(TAG, "could not create scratch AudioTrack", t)
            null
        }
    }

    private companion object {
        const val TAG = "ScratchPlayer"

        /** About 3 ms at 44.1 kHz: how often the finger speed is sampled. */
        const val BLOCK_FRAMES = 128
        const val STALE_NANOS = 50_000_000L

        /**
         * How far behind the processor's newest audio the listener really is: the player's default
         * output buffer is about 250 ms. The scratch starts reading from there so grabbing the
         * record does not jump forward in the music.
         */
        const val OUTPUT_LATENCY_MS = 250f
    }
}
