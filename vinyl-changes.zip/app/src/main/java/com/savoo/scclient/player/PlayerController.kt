package com.savoo.scclient.player

import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.RawResourceDataSource
import androidx.palette.graphics.Palette
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.google.common.util.concurrent.MoreExecutors
import com.savoo.scclient.R
import com.savoo.scclient.data.local.FavoriteTrackFilter
import com.savoo.scclient.data.local.FavoriteTrackOrder
import com.savoo.scclient.data.local.FavoriteTrackQueries
import com.savoo.scclient.data.local.FavoritesDao
import com.savoo.scclient.data.local.PlayHistoryDao
import com.savoo.scclient.data.local.UnavailableTrackDao
import com.savoo.scclient.data.model.PlayEvent
import com.savoo.scclient.data.model.Track
import com.savoo.scclient.data.model.UnavailableReason
import com.savoo.scclient.data.model.UnavailableTrackEntity
import com.savoo.scclient.data.model.restrictionReason
import com.savoo.scclient.data.model.toTrack
import com.savoo.scclient.data.model.User
import com.savoo.scclient.data.remote.ConnectivityEventBus
import com.savoo.scclient.data.repository.DefaultCrossfadeSeconds
import com.savoo.scclient.data.repository.SettingsRepository
import com.savoo.scclient.data.repository.TrackRepository
import com.savoo.scclient.debug.DebugLog
import retrofit2.HttpException
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject
import kotlin.math.roundToInt
import javax.inject.Singleton
import androidx.compose.ui.graphics.Color
import com.savoo.scclient.ui.components.GeneratedArtworkDebugState
import com.savoo.scclient.ui.components.generatedArtworkSeedColor

data class PlaybackState(
    val currentTrack: Track? = null,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val hasNext: Boolean = false,
    val hasPrev: Boolean = false,
    val loadingTrackId: Long? = null,
    val isRetryingNetwork: Boolean = false,
    val shuffleEnabled: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val playbackSpeed: Float = 1f,
    val soundMode: SoundMode = SoundMode(),
    // Which playQueue() call is currently active, e.g. "home_mix" - lets a caller tell "is MY queue
    // the one playing right now" apart from "does the current track merely also appear in my queue"
    // (the two look the same if you only check track membership, but they're not: e.g. a track played
    // from Jump Back In can also be part of the mix's pool without the mix itself being what's active).
    val queueTag: String? = null,
    // Index into the current queue, kept separate from currentTrack.id because a queue can legitimately
    // hold the same track id twice (playlists do this) - the id alone can't disambiguate which copy is
    // actually playing, which the Queue screen needs to highlight the right row.
    val queueIndex: Int = -1,
    val loop: LoopRegion? = null,
)

data class LoopRegion(val startMs: Long, val endMs: Long)

// Wraps a Track with a synthetic id that's stable for the life of this queue slot (assigned once, when
// the entry is added) and untouched by later moves/removes - unlike Track.id, which a queue can hold
// duplicates of (playlists do this), a QueueEntry.id always identifies exactly one slot, which is what
// the Queue screen's drag-to-reorder needs for smooth, uninterrupted dragging across list positions.
data class QueueEntry(val id: Long, val track: Track)

data class SkippedTrack(val track: Track, val reason: UnavailableReason?)

@UnstableApi
@Singleton
class PlayerController @Inject constructor(
    @ApplicationContext private val context: Context,
    private val trackRepository: TrackRepository,
    private val trackCache: TrackCache,
    val offlineTrackManager: OfflineTrackManager,
    private val playHistoryDao: PlayHistoryDao,
    private val settingsRepository: SettingsRepository,
    private val unavailableTrackDao: UnavailableTrackDao,
    private val favoritesDao: FavoritesDao,
    private val soundEffects: SoundEffects,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var controller: MediaController? = null
    private var positionJob: kotlinx.coroutines.Job? = null
    private var loopJob: kotlinx.coroutines.Job? = null
    private var seedColorJob: kotlinx.coroutines.Job? = null
    private var seedColorUrl: String? = null

    private val _state = MutableStateFlow(PlaybackState())
    val state = _state.asStateFlow()
    private val _seedColor = MutableStateFlow<Color?>(null)
    val seedColor = _seedColor.asStateFlow()
    private val _skippedTrackEvents = MutableSharedFlow<SkippedTrack>(extraBufferCapacity = 1)
    val skippedTrackEvents = _skippedTrackEvents.asSharedFlow()

    private val _expandRequests = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val expandRequests = _expandRequests.asSharedFlow()

    private fun expandIfCurrent(trackId: Long): Boolean {
        if (_state.value.currentTrack?.id != trackId) return false
        _expandRequests.tryEmit(Unit)
        return true
    }
    val unavailableReasons: StateFlow<Map<Long, UnavailableReason>> = unavailableTrackDao.observeAll()
        .map { list -> list.associate { it.trackId to it.reason } }
        .stateIn(scope, SharingStarted.Eagerly, emptyMap())
    private val offlineTrackIds: StateFlow<Set<Long>> = offlineTrackManager.getAllOfflineTracks()
        .map { list -> list.map { it.trackId }.toSet() }
        .stateIn(scope, SharingStarted.Eagerly, emptySet())
    private val _queueEntries = MutableStateFlow<List<QueueEntry>>(emptyList())
    val queueEntries = _queueEntries.asStateFlow()
    private val _sleepTimerRemainingMs = MutableStateFlow<Long?>(null)
    val sleepTimerRemainingMs = _sleepTimerRemainingMs.asStateFlow()
    private val _sleepAfterCurrentTrack = MutableStateFlow(false)
    val sleepAfterCurrentTrack = _sleepAfterCurrentTrack.asStateFlow()
    private var sleepTimerJob: kotlinx.coroutines.Job? = null
    private val queue = mutableListOf<QueueEntry>()
    private var nextQueueEntryId = 0L
    private var queueIndex = -1
    private var currentQueueTag: String? = null
    private var playRequestId = 0L
    private var favoritesContinuation: FavoritesContinuation? = null
    private var extendingQueue = false
    // Snapshot of queue's order right before shuffling, so toggling shuffle off can restore it. Empty when shuffle is off.
    // Shuffling is handled entirely at this level (queue itself is reordered) rather than via ExoPlayer's native
    // shuffleModeEnabled - replaceMediaItem() turned out to internally remove+reinsert the period, which mutates
    // ExoPlayer's own shuffle order as a side effect, so "previous" could land somewhere unexpected after any
    // background resolve had happened. Keeping native shuffle permanently off avoids that entirely.
    private val originalOrder = mutableListOf<QueueEntry>()
    private val prefs = context.getSharedPreferences("player_state", Context.MODE_PRIVATE)
    private val errorRetryCount = mutableMapOf<Long, Int>()
    private val resolvingMediaIds = mutableSetOf<Long>()
    // Serializes replaceMediaItem/prepare/play calls to the (IPC-backed) MediaController - concurrent preload
    // resolutions for the next and previous track were issuing these commands at overlapping times, which is
    // suspected to be involved in the shuffle-skip cascade (the player jumping through several unrelated tracks).
    private val playerCommandMutex = Mutex()
    private var isScrubbing = false
    private var wasPlayingBeforeScrub = false
    private var lastScrubSeekAtMs = 0L
    private var pendingScrubJob: kotlinx.coroutines.Job? = null
    private var fadeJob: kotlinx.coroutines.Job? = null
    private var fadeOutStartedForMediaId: Long? = null
    private var crossfadeEnabled = false
    @Volatile
    private var fadeOutLeadMs = DefaultCrossfadeSeconds * 1000L
    @Volatile
    private var fadeInMs = DefaultCrossfadeSeconds * 600L

    private var listenTrackId: Long? = null
    private var listenTrackDurationMs: Long = 0L
    private var listenAccumulatedMs: Long = 0L
    private var listenEventJob: kotlinx.coroutines.Deferred<Long?>? = null
    private var listenSegmentStartRealtime: Long? = null
    private val minListenMsToRecord = 5_000L

    companion object {
        const val MAX_SCRATCH_SPEED = 4f
        const val SCRATCH_RESUME_TOLERANCE_MS = 150L
        const val MIN_PLAYBACK_SPEED = 0.5f
        const val MAX_PLAYBACK_SPEED = 2f
        val PLAYBACK_SPEED_STEPS = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)

        const val TAG = "PlayerController"
        private const val PENDING_SCHEME = "rawresource"
        private const val SCRUB_THROTTLE_MS = 140L
        const val MIN_LOOP_MS = 1_000L
        private const val LOOP_END_GUARD_MS = 300L
        private const val LOOP_IDLE_POLL_MS = 200L
        private const val LOOP_MIN_POLL_MS = 8L
        private const val LOOP_MAX_POLL_MS = 250L
        private const val LOOP_SEEK_SETTLE_MS = 120L
        private const val UNAVAILABLE_MARK_TTL_MS = 7L * 24 * 60 * 60 * 1000
        private const val FADE_STEP_MS = 60L
        private const val FULL_FAVORITES_QUEUE_LIMIT = 5000
        private const val FAVORITES_QUEUE_CHUNK = 2000
        private const val FAVORITES_QUEUE_BEFORE = 250
        private const val QUEUE_EXTEND_THRESHOLD = 50
        private const val KEY_FAVORITES_CONTINUATION = "favorites_continuation"
        private const val SKIP_MAX_PLAYED_MS = 25_000L
        private const val SKIP_MAX_PLAYED_FRACTION = 0.35
        private const val MORE_LIKE_THIS_LIMIT = 8

        // Placeholder items point at a real, always-loadable local silent file rather than an invalid URI (which used
        // to make ExoPlayer choke while probing it during buffering/look-ahead). Every placeholder gets a distinct
        // fragment (#<trackId>) so each is a unique Uri - dozens of playlist entries sharing byte-identical URIs was
        // itself confusing ExoPlayer's Timeline/MediaSource bookkeeping and causing shuffle skips to cascade through
        // many unrelated tracks; the fragment doesn't affect how RawResourceDataSource resolves the resource id.
        fun pendingUriFor(trackId: Long): Uri =
            RawResourceDataSource.buildRawResourceUri(R.raw.silence).buildUpon().fragment(trackId.toString()).build()
    }

    // A queue entry can start out as a stripped-down Track (Home's recent list, for instance, builds
    // tracks straight from play history and has no permalink or media), so once a resolve hands back
    // the full one, the entry is swapped for it - otherwise everything downstream of the queue (sharing,
    // duration, genre) keeps seeing the stripped version.
    private fun adoptResolvedTrack(index: Int, resolved: Track) {
        val entry = queue.getOrNull(index) ?: return
        if (entry.track.id != resolved.id || entry.track === resolved) return
        queue[index] = entry.copy(track = resolved)
        updateQueueState()
        if (_state.value.currentTrack?.id == resolved.id) {
            _state.update { it.copy(currentTrack = resolved) }
        }
    }

    private fun isPending(mediaItem: MediaItem?): Boolean =
        mediaItem?.localConfiguration?.uri?.scheme == PENDING_SCHEME

    private fun wrap(track: Track): QueueEntry = QueueEntry(nextQueueEntryId++, track)
    private fun wrapAll(tracks: List<Track>): List<QueueEntry> = tracks.map { wrap(it) }

    // A queue can legitimately hold the same track twice (playlists do this), so a plain indexOf/find
    // by value would resolve every duplicate to the first copy and swap the URL onto the wrong window.
    // When the id being looked up is what's playing right now, the player's own index is authoritative.
    private fun queueIndexOf(mediaId: Long): Int {
        controller?.let { c ->
            val current = c.currentMediaItemIndex
            if (current in queue.indices && queue[current].track.id == mediaId) return current
        }
        return queue.indexOfFirst { it.track.id == mediaId }
    }

    init {
        primeFromSavedState()
        scope.launch {
            settingsRepository.settings.map { it.crossfadeEnabled }.distinctUntilChanged().collect { enabled ->
                crossfadeEnabled = enabled
                if (!enabled) {
                    fadeJob?.cancel()
                    fadeOutStartedForMediaId = null
                    controller?.volume = 1f
                }
            }
        }
        scope.launch {
            settingsRepository.settings.map { it.crossfadeSeconds }.distinctUntilChanged().collect { seconds ->
                fadeOutLeadMs = seconds * 1000L
                fadeInMs = seconds * 600L
            }
        }
        scope.launch {
            withContext(Dispatchers.IO) {
                unavailableTrackDao.clearExpired(System.currentTimeMillis() - UNAVAILABLE_MARK_TTL_MS)
            }
        }
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            controller = future.get()
            controller?.addListener(playerListener)
            controller?.shuffleModeEnabled = false // shuffling is handled at the queue level, see toggleShuffle()
            controller?.repeatMode = prefs.getInt("repeat_mode", Player.REPEAT_MODE_OFF)
            val savedSpeed = prefs.getFloat("playback_speed", 1f).coerceIn(MIN_PLAYBACK_SPEED, MAX_PLAYBACK_SPEED)
            _state.update {
                it.copy(
                    shuffleEnabled = prefs.getBoolean("shuffle_enabled", false),
                    repeatMode = controller?.repeatMode ?: Player.REPEAT_MODE_OFF,
                    playbackSpeed = savedSpeed,
                    soundMode = loadSoundMode(),
                )
            }
            applyPlaybackParameters()
            restorePlayLastTrack()
        }, MoreExecutors.directExecutor())
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) {
                _state.update { it.copy(isPlaying = true, loadingTrackId = null) }
                controller?.currentMediaItem?.mediaId?.toLongOrNull()?.let { errorRetryCount.remove(it) }
                resumeListenSegment()
                startPositionPolling()
            } else {
                _state.update { it.copy(isPlaying = false) }
                stopPositionPolling()
                pauseListenSegment()
                saveState()
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            DebugLog.log(TAG, "onPlaybackStateChanged: $playbackState currentId=${controller?.currentMediaItem?.mediaId} pos=${controller?.currentPosition} dur=${controller?.duration}")
            _state.update { it.copy(isBuffering = playbackState == Player.STATE_BUFFERING) }
            if (playbackState == Player.STATE_ENDED) _sleepAfterCurrentTrack.value = false
            if (playbackState == Player.STATE_READY) updatePosition()
        }

        override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int) {
            DebugLog.log(TAG, "onPositionDiscontinuity: reason=$reason oldItem=${oldPosition.mediaItem?.mediaId} oldPos=${oldPosition.positionMs} newItem=${newPosition.mediaItem?.mediaId} newPos=${newPosition.positionMs}")
        }

        override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) {
            DebugLog.log(TAG, "onTimelineChanged: reason=$reason windowCount=${timeline.windowCount}")
        }

        override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
            DebugLog.log(TAG, "Playback error: ${error.message}")
            val mediaId = controller?.currentMediaItem?.mediaId?.toLongOrNull() ?: return
            if (mediaId in resolvingMediaIds) return // an in-flight resolution will prepare()/play() or skip once it finishes
            val attempts = (errorRetryCount[mediaId] ?: 0) + 1
            errorRetryCount[mediaId] = attempts
            val track = queue.find { it.track.id == mediaId }?.track
            if (attempts > 2) {
                DebugLog.log(TAG, "Giving up on track $mediaId after $attempts failed attempts, skipping")
                errorRetryCount.remove(mediaId)
                if (track != null) scope.launch { skipDueToFailure(track) } else controller?.seekToNext()
                return
            }
            if (track == null) {
                scope.launch {
                    delay(400)
                    controller?.prepare()
                }
                return
            }
            resolvingMediaIds.add(mediaId)
            scope.launch {
                try {
                    delay(400)
                    val resolved = resolveTrack(track.copy(media = null))
                    if (resolved == null) {
                        skipDueToFailure(track)
                        return@launch
                    }
                    val i = queueIndexOf(mediaId)
                    if (i < 0) return@launch
                    playerCommandMutex.withLock {
                        replaceMediaItemSafely(i, buildMediaItem(resolved.track, resolved.url, resolved.isHls))
                        controller?.let {
                            if (it.currentMediaItem?.mediaId?.toLongOrNull() == mediaId) {
                                it.seekTo(i, 0L)
                                it.prepare()
                                if (it.playWhenReady) it.play()
                            }
                        }
                    }
                    if (resolved.needsCaching) {
                        trackCache.cacheAudioFile(resolved.track, resolved.url)
                    }
                } finally {
                    resolvingMediaIds.remove(mediaId)
                }
            }
        }

        override fun onPlaybackParametersChanged(playbackParameters: androidx.media3.common.PlaybackParameters) {
            _state.update {
                val userSpeed = playbackParameters.speed / it.soundMode.rate
                it.copy(playbackSpeed = (userSpeed * 100).roundToInt() / 100f)
            }
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            _state.update { it.copy(repeatMode = repeatMode) }
            updateQueueState()
            maybeExtendQueue()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val mediaId = mediaItem?.mediaId?.toLongOrNull() ?: return
            val track = queue.firstOrNull { it.track.id == mediaId }?.track
            DebugLog.log(TAG, "onMediaItemTransition: id=$mediaId title=${track?.title} reason=$reason pending=${isPending(mediaItem)} queueIndex(before)=$queueIndex")
            if (track != null) {
                val idx = queueIndexOf(mediaId)
                if (idx >= 0) {
                    queueIndex = idx
                    updateQueueState()
                    maybeExtendQueue()
                }

                // replaceMediaItem() (used to swap a resolved "pending" placeholder for the real URL) fires this same
                // callback with reason=PLAYLIST_CHANGED even when nothing the user asked for actually changed. Treating
                // that as a real transition was the cause of the cover/title flashing: it re-triggered preloadAdjacent(),
                // which replaced more items, which fired more PLAYLIST_CHANGED transitions - a self-sustaining cascade.
                val isSelfEcho = reason == Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED &&
                    _state.value.currentTrack?.id == mediaId
                if (!isSelfEcho) {
                    beginListenSegment(track)
                    if (_state.value.currentTrack?.id != mediaId) clearLoop()
                    _state.update { it.copy(currentTrack = track, durationMs = track.durationMs, loadingTrackId = null) }
                    extractSeedColor(track.artworkUrl, track.title)
                    fadeOutStartedForMediaId = null
                    fadeJob?.cancel()
                    val stoppingAfterPreviousTrack = _sleepAfterCurrentTrack.value &&
                        reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO
                    if (stoppingAfterPreviousTrack) {
                        _sleepAfterCurrentTrack.value = false
                        controller?.volume = 1f
                        controller?.pause()
                        controller?.seekTo(0L)
                    } else if (crossfadeEnabled) {
                        controller?.volume = 0f
                        startFade(from = 0f, to = 1f, durationMs = fadeInMs)
                    } else {
                        controller?.volume = 1f
                    }
                }

                if (isPending(mediaItem) && resolvingMediaIds.add(mediaId)) {
                    DebugLog.log(TAG, "reactive resolve start: id=$mediaId title=${track.title}")
                    scope.launch {
                        try {
                            val resolved = resolveTrack(track)
                            if (resolved == null) {
                                DebugLog.log(TAG, "reactive resolve FAILED after retries, skipping: id=$mediaId title=${track.title}")
                                skipDueToFailure(track)
                                return@launch
                            }
                            DebugLog.log(TAG, "reactive resolve OK: id=$mediaId title=${track.title}")

                            val i = queueIndexOf(mediaId)
                            if (i < 0) return@launch

                            playerCommandMutex.withLock {
                                adoptResolvedTrack(i, resolved.track)
                                replaceMediaItemSafely(i, buildMediaItem(resolved.track, resolved.url, resolved.isHls))

                                // Only do this if we're still actually the current item - playback may have moved on to a
                                // different (possibly still-pending) track while this resolve was in flight. replaceMediaItem
                                // on the ACTIVE window doesn't actually swap the audio being read: ExoPlayer keeps decoding
                                // whatever was already buffered from the placeholder (~0.5s of silence) until that period
                                // naturally "ends", THEN auto-advances - which is what was really driving the skip cascade.
                                // seekTo(sameIndex, 0) forces it to actually discard that and reload from the new source.
                                controller?.let {
                                    if (it.currentMediaItem?.mediaId?.toLongOrNull() == mediaId) {
                                        it.seekTo(i, 0L)
                                        it.prepare()
                                        if (it.playWhenReady) it.play()
                                    }
                                }
                            }

                            if (resolved.needsCaching) {
                                trackCache.cacheAudioFile(resolved.track, resolved.url)
                            }
                        } finally {
                            resolvingMediaIds.remove(mediaId)
                        }
                    }
                }

                // Don't re-trigger preloading off our own PLAYLIST_CHANGED echoes - see the isSelfEcho comment above.
                if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) {
                    preloadAdjacent()
                }
            }
        }
    }

    private data class ResolvedTrack(val track: Track, val url: String, val needsCaching: Boolean, val isHls: Boolean = false)

    private fun hasLocalCopy(trackId: Long): Boolean =
        trackId in offlineTrackIds.value || trackCache.getCachedFilePath(trackId) != null

    private fun knownReason(track: Track): UnavailableReason? {
        if (hasLocalCopy(track.id)) return null
        return unavailableReasons.value[track.id] ?: track.restrictionReason()
    }

    private suspend fun persistUnavailable(trackId: Long, reason: UnavailableReason) {
        withContext(Dispatchers.IO) {
            unavailableTrackDao.mark(UnavailableTrackEntity(trackId, reason, System.currentTimeMillis()))
        }
    }

    private suspend fun rememberUnavailable(trackId: Long, reason: UnavailableReason) {
        withContext(Dispatchers.IO) {
            unavailableTrackDao.markIfAbsent(UnavailableTrackEntity(trackId, reason, System.currentTimeMillis()))
        }
    }

    private suspend fun clearUnavailable(trackId: Long) {
        withContext(Dispatchers.IO) { unavailableTrackDao.clear(trackId) }
    }

    private fun evictFromQueue(trackId: Long) {
        while (true) {
            val index = queue.indexOfFirst { it.track.id == trackId }
            if (index < 0) break
            removeQueueItem(index)
        }
    }

    private suspend fun markUnavailable(trackId: Long, reason: UnavailableReason) {
        persistUnavailable(trackId, reason)
        evictFromQueue(trackId)
    }

    // Single source of truth for turning a queue entry into a playable URL: offline file, then disk cache, then network -
    // retrying the network step a couple of times before giving up, so a transient hiccup doesn't silently skip the track.
    private suspend fun resolveTrack(track: Track, attempts: Int = 3, reportProgress: Boolean = true): ResolvedTrack? {
        offlineTrackManager.getLocalPath(track.id)?.let { return ResolvedTrack(track, it, needsCaching = false) }
        trackCache.getCachedFilePath(track.id)?.let { return ResolvedTrack(track, it, needsCaching = false) }

        withContext(Dispatchers.IO) { unavailableTrackDao.get(track.id) }?.let {
            if (System.currentTimeMillis() - it.markedAt < UNAVAILABLE_MARK_TTL_MS) {
                DebugLog.log(TAG, "resolveTrack: id=${track.id} title=${track.title} already marked ${it.reason}, skipping")
                evictFromQueue(track.id)
                return null
            }
            DebugLog.log(TAG, "resolveTrack: id=${track.id} title=${track.title} mark ${it.reason} expired, re-checking")
            clearUnavailable(track.id)
        }


        val effectiveAttempts = if (ConnectivityEventBus.isUnreachable.value) 1 else attempts
        try {
            repeat(effectiveAttempts) { attempt ->
                if (attempt > 0 && reportProgress) _state.update { it.copy(isRetryingNetwork = true) }
                var deleted = false
                val fullTrack = if (attempt == 0 && track.media != null) track
                    else withContext(Dispatchers.IO) {
                        runCatching { trackRepository.getTrack(track.id) }
                            .onFailure { if (it is HttpException && it.code() == 404) deleted = true }
                            .getOrNull()
                    } ?: track
                if (deleted) {
                    DebugLog.log(TAG, "resolveTrack id=${track.id} title=${track.title}: getTrack() 404, marking DELETED")
                    markUnavailable(track.id, UnavailableReason.DELETED)
                    return null
                }
                fullTrack.restrictionReason()?.let { restriction ->
                    DebugLog.log(TAG, "resolveTrack id=${track.id} title=${track.title}: policy=${fullTrack.policy}, marking $restriction")
                    markUnavailable(track.id, restriction)
                    return null
                }
                if (fullTrack.media == null) {
                    DebugLog.log(TAG, "resolveTrack attempt=${attempt + 1}/$effectiveAttempts id=${track.id} title=${track.title}: getTrack() returned no media")
                }
                val streamResult = withContext(Dispatchers.IO) {
                    runCatching { trackRepository.resolvePlayableStream(fullTrack) }
                        .onFailure { DebugLog.log(TAG, "resolveTrack attempt=${attempt + 1}/$effectiveAttempts id=${track.id} title=${track.title}: resolvePlayableStream threw ${it}") }
                }
                streamResult.getOrNull()?.let { stream ->
                    return ResolvedTrack(fullTrack, stream.url, needsCaching = !stream.isHls, isHls = stream.isHls)
                }
                val streamFailure = streamResult.exceptionOrNull()
                if (streamFailure is HttpException && streamFailure.code() == 404) {
                    DebugLog.log(TAG, "resolveTrack id=${track.id} title=${track.title}: all playable formats 404 on resolve, marking DRM")
                    markUnavailable(track.id, UnavailableReason.DRM)
                    return null
                }
                if (attempt < effectiveAttempts - 1) delay(500L * (attempt + 1))
            }
            DebugLog.log(TAG, "resolveTrack GAVE UP after $effectiveAttempts attempts: id=${track.id} title=${track.title}")
            return null
        } finally {
            if (reportProgress) _state.update { it.copy(isRetryingNetwork = false) }
        }
    }

    private suspend fun skipDueToFailure(track: Track, fallbackIndex: Int = -1) {
        if (ConnectivityEventBus.isUnreachable.value) {
            DebugLog.log(TAG, "skipDueToFailure: id=${track.id} title=${track.title} offline, pausing instead of skipping")
            controller?.pause()
            _state.update { it.copy(loadingTrackId = null, isBuffering = false) }
            return
        }
        val reason = withContext(Dispatchers.IO) { unavailableTrackDao.get(track.id) }?.reason ?: track.restrictionReason()
        DebugLog.log(TAG, "skipDueToFailure: id=${track.id} title=${track.title} reason=$reason")
        _skippedTrackEvents.tryEmit(SkippedTrack(track, reason))

        val isCurrentInPlayer = controller?.currentMediaItem?.mediaId == track.id.toString()
        val isCurrentInQueue = queue.getOrNull(queueIndex)?.track?.id == track.id
        if (!isCurrentInPlayer && !isCurrentInQueue) {
            DebugLog.log(TAG, "skipDueToFailure: id=${track.id} no longer the selected track, leaving playback alone")
            return
        }
        if (isCurrentInPlayer) {
            controller?.seekToNext()
            return
        }
        val next = if (fallbackIndex >= 0) {
            queue.drop(fallbackIndex).firstOrNull { it.track.id != track.id && knownReason(it.track) == null }
        } else null
        val nextIndex = next?.let { entry -> queue.indexOfFirst { it.id == entry.id } } ?: -1
        if (nextIndex >= 0) {
            playFromQueue(nextIndex)
        } else {
            _state.update { it.copy(loadingTrackId = null, isBuffering = false) }
        }
    }

    private fun buildMediaItem(track: Track, url: String, isHls: Boolean = false): MediaItem =
        MediaItem.Builder()
            .setUri(url)
            .apply { if (isHls) setMimeType(MimeTypes.APPLICATION_M3U8) }
            .setMediaId(track.id.toString())
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(track.title)
                    .setArtist(track.user.username)
                    .setArtworkUri(track.artworkUrl?.replace("-large", "-t500x500")?.let { Uri.parse(it) })
                    .build()
            ).build()

    private fun replaceMediaItemSafely(index: Int, item: MediaItem) {
        val c = controller ?: return
        val repeatOneOnCurrent = c.repeatMode == Player.REPEAT_MODE_ONE && c.currentMediaItemIndex == index
        if (repeatOneOnCurrent) c.repeatMode = Player.REPEAT_MODE_OFF
        c.replaceMediaItem(index, item)
        if (repeatOneOnCurrent) c.repeatMode = Player.REPEAT_MODE_ONE
    }

    private fun buildPendingMediaItem(track: Track): MediaItem =
        MediaItem.Builder()
            .setMediaId(track.id.toString())
            .setUri(pendingUriFor(track.id))
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(track.title)
                    .setArtist(track.user.username)
                    .setArtworkUri(track.artworkUrl?.replace("-large", "-t500x500")?.let { Uri.parse(it) })
                    .build()
            ).build()

    // Preloads neighbours via media3's shuffle/repeat-aware next/previous index so skips rarely hit an unresolved "pending" item.
    private fun preloadAdjacent() {
        val c = controller ?: return
        val indices = listOfNotNull(
            c.nextMediaItemIndex.takeIf { it != androidx.media3.common.C.INDEX_UNSET },
            c.previousMediaItemIndex.takeIf { it != androidx.media3.common.C.INDEX_UNSET },
        )
        DebugLog.log(TAG, "preloadAdjacent: currentIndex=${c.currentMediaItemIndex} candidates=$indices shuffle=${c.shuffleModeEnabled}")
        for (idx in indices) {
            if (idx !in 0 until c.mediaItemCount) continue
            val item = runCatching { c.getMediaItemAt(idx) }.getOrNull() ?: continue
            if (isPending(item)) {
                item.mediaId.toLongOrNull()?.let { resolveAndReplace(it, idx) }
            }
        }
    }

    private fun resolveAndReplace(mediaId: Long, preloadIndex: Int) {
        if (!resolvingMediaIds.add(mediaId)) {
            DebugLog.log(TAG, "resolveAndReplace: id=$mediaId already in flight, skipping duplicate")
            return
        }
        DebugLog.log(TAG, "preload resolve start: id=$mediaId")
        scope.launch {
            try {
                val track = queue.getOrNull(preloadIndex)?.track?.takeIf { it.id == mediaId }
                    ?: queue.firstOrNull { it.track.id == mediaId }?.track
                    ?: return@launch
                val resolved = resolveTrack(track, reportProgress = false)
                if (resolved == null) {
                    DebugLog.log(TAG, "preload resolve FAILED: id=$mediaId title=${track.title}")
                    return@launch
                }
                DebugLog.log(TAG, "preload resolve OK: id=$mediaId title=${track.title}")

                // The queue may have been reordered (shuffle) or rebuilt while this was resolving, so the
                // index we prefetched for can now hold a different track - only replace if it still matches.
                val idx = preloadIndex.takeIf { queue.getOrNull(it)?.track?.id == mediaId } ?: queueIndexOf(mediaId)
                if (idx < 0) return@launch

                playerCommandMutex.withLock {
                    val stillThere = controller?.let { c ->
                        idx < c.mediaItemCount && runCatching { c.getMediaItemAt(idx).mediaId.toLongOrNull() }.getOrNull() == mediaId
                    } ?: false
                    if (!stillThere) return@withLock
                    adoptResolvedTrack(idx, resolved.track)
                    replaceMediaItemSafely(idx, buildMediaItem(resolved.track, resolved.url, resolved.isHls))

                    // If this neighbour became the current item while we were resolving it, recover it the same way the
                    // reactive path does - see the comment there for why seekTo() is needed, not just prepare().
                    controller?.let {
                        if (it.currentMediaItem?.mediaId?.toLongOrNull() == mediaId) {
                            it.seekTo(idx, 0L)
                            it.prepare()
                            if (it.playWhenReady) it.play()
                        }
                    }
                }

                if (resolved.needsCaching) {
                    trackCache.cacheAudioFile(resolved.track, resolved.url)
                }
            } finally {
                resolvingMediaIds.remove(mediaId)
            }
        }
    }

    private fun startPositionPolling() {
        stopPositionPolling()
        positionJob = scope.launch {
            var tick = 0
            while (true) {
                updatePosition()
                tick++
                if (tick % 6 == 0) saveState()
                delay(500L)
            }
        }
    }

    private fun stopPositionPolling() {
        positionJob?.cancel()
        positionJob = null
    }

    private fun updatePosition() {
        val pos = controller?.currentPosition ?: return
        val dur = controller?.duration ?: return
        _state.update { it.copy(positionMs = pos, durationMs = dur.coerceAtLeast(0L)) }
        maybeStartFadeOut(pos, dur)
    }

    private fun maybeStartFadeOut(pos: Long, dur: Long) {
        if (dur <= 0 || isScrubbing || !crossfadeEnabled || _state.value.loop != null) return
        val mediaId = controller?.currentMediaItem?.mediaId?.toLongOrNull() ?: return
        val remaining = dur - pos
        if (remaining in 0..fadeOutLeadMs && fadeOutStartedForMediaId != mediaId) {
            fadeOutStartedForMediaId = mediaId
            startFade(from = controller?.volume ?: 1f, to = 0f, durationMs = remaining)
        } else if (remaining > fadeOutLeadMs && fadeOutStartedForMediaId == mediaId) {
            fadeOutStartedForMediaId = null
            fadeJob?.cancel()
            controller?.volume = 1f
        }
    }

    private fun beginListenSegment(track: Track) {
        // A new record: drop the needle (crackle burst on the vinyl noise).
        soundEffects.triggerNeedleDrop()
        flushListenSegment()
        listenTrackId = track.id
        listenTrackDurationMs = track.durationMs
        listenAccumulatedMs = 0L
        listenSegmentStartRealtime = if (controller?.isPlaying == true) System.currentTimeMillis() else null
        val event = PlayEvent(
            trackId = track.id,
            title = track.title,
            artistId = track.user.id,
            artistName = track.user.username,
            artworkUrl = track.artworkUrl,
            msPlayed = 0L,
            playedAt = System.currentTimeMillis(),
            genre = track.genre,
        )
        listenEventJob = scope.async(Dispatchers.IO) {
            runCatching { playHistoryDao.insert(event) }.getOrNull()
        }
    }

    private fun resumeListenSegment() {
        if (listenTrackId != null && listenSegmentStartRealtime == null) {
            listenSegmentStartRealtime = System.currentTimeMillis()
        }
    }

    private fun pauseListenSegment() {
        val start = listenSegmentStartRealtime ?: return
        listenAccumulatedMs += System.currentTimeMillis() - start
        listenSegmentStartRealtime = null
    }

    private fun flushListenSegment() {
        pauseListenSegment()
        val trackId = listenTrackId
        val ms = listenAccumulatedMs
        val durationMs = listenTrackDurationMs
        val eventJob = listenEventJob
        listenEventJob = null
        if (trackId != null && eventJob != null) {
            val skipped = ms in 1 until SKIP_MAX_PLAYED_MS &&
                (durationMs <= 0L || ms < durationMs * SKIP_MAX_PLAYED_FRACTION)
            scope.launch(Dispatchers.IO) {
                val eventId = eventJob.await() ?: return@launch
                runCatching { playHistoryDao.updatePlayOutcome(eventId, ms, skipped) }
            }
        }
        listenTrackId = null
        listenTrackDurationMs = 0L
        listenAccumulatedMs = 0L
        listenSegmentStartRealtime = null
    }

    private fun startFade(from: Float, to: Float, durationMs: Long) {
        fadeJob?.cancel()
        if (durationMs <= 0) {
            controller?.volume = to
            return
        }
        fadeJob = scope.launch {
            val steps = (durationMs / FADE_STEP_MS).toInt().coerceAtLeast(1)
            for (i in 1..steps) {
                controller?.volume = from + (to - from) * (i.toFloat() / steps)
                delay(FADE_STEP_MS)
            }
            controller?.volume = to
        }
    }

    fun play(track: Track) {
        if (expandIfCurrent(track.id)) return
        knownReason(track)?.let { reason ->
            DebugLog.log(TAG, "play: id=${track.id} title=${track.title} known unavailable ($reason), not touching playback")
            _skippedTrackEvents.tryEmit(SkippedTrack(track, reason))
            scope.launch { rememberUnavailable(track.id, reason) }
            return
        }
        currentQueueTag = null
        favoritesContinuation = null
        _state.update { it.copy(loadingTrackId = track.id) }
        val idx = queue.indexOfFirst { it.track.id == track.id }
        val idxForThisTrack = if (idx >= 0) idx else {
            queue.add(wrap(track))
            queue.lastIndex
        }
        queueIndex = idxForThisTrack
        updateQueueState()
        doPlay(track, idxForThisTrack, ++playRequestId)
    }

    fun retryTrack(track: Track) {
        scope.launch {
            clearUnavailable(track.id)
            val idx = queue.indexOfFirst { it.track.id == track.id }
            if (idx >= 0) playFromQueue(idx) else play(track)
        }
    }

    fun playQueue(
        sourceTracks: List<Track>,
        startIndex: Int = 0,
        repeatAll: Boolean = false,
        tag: String? = null,
        startExact: Boolean = true,
        startPositionMs: Long = 0L,
    ) {
        if (sourceTracks.isEmpty()) return
        val requested = sourceTracks[startIndex.coerceIn(0, sourceTracks.lastIndex)]
        if (startExact && startPositionMs == 0L && expandIfCurrent(requested.id)) return
        if (startExact) {
            knownReason(requested)?.let { reason ->
                DebugLog.log(TAG, "playQueue: requested id=${requested.id} title=${requested.title} unavailable ($reason), not starting a queue")
                _skippedTrackEvents.tryEmit(SkippedTrack(requested, reason))
                scope.launch { rememberUnavailable(requested.id, reason) }
                return
            }
        }
        val tracks = sourceTracks.filter { knownReason(it) == null }
        if (tracks.isEmpty()) {
            _skippedTrackEvents.tryEmit(SkippedTrack(requested, knownReason(requested)))
            return
        }
        val clampedStart = tracks.indexOfFirst { it.id == requested.id }.coerceAtLeast(0).coerceAtMost(tracks.lastIndex)
        currentQueueTag = tag
        favoritesContinuation = null

        // Session-only, not persisted to prefs (unlike cycleRepeatMode()) - a queue that wants to loop
        // (e.g. the Home mix, which should feel near-endless) shouldn't silently change the user's
        // saved repeat preference for every other queue they play afterwards.
        if (repeatAll) {
            controller?.repeatMode = Player.REPEAT_MODE_ALL
        }

        // Starting an unrelated queue (e.g. a different playlist) while shuffle is on used to leave
        // shuffleEnabled=true and originalOrder pointing at the PREVIOUS queue: the toggle looked on
        // but this queue played in order, and turning shuffle off would jump back to the old queue's
        // tracks. Re-shuffle the new queue up front instead, same as toggleShuffle()'s own algorithm.
        if (_state.value.shuffleEnabled) {
            val wrapped = wrapAll(tracks)
            val startEntry = wrapped[clampedStart]
            originalOrder.clear()
            originalOrder.addAll(wrapped)
            val previousEntry = if (startExact) wrapped.getOrNull(clampedStart - 1) else null
            val rest = wrapped.filter { it.id != startEntry.id && it.id != previousEntry?.id }.shuffled()
            queue.clear()
            previousEntry?.let { queue.add(it) }
            queue.add(startEntry)
            queue.addAll(rest)
            queueIndex = if (previousEntry != null) 1 else 0
        } else {
            originalOrder.clear()
            queue.clear()
            queue.addAll(wrapAll(tracks))
            queueIndex = clampedStart
        }

        _state.update { it.copy(loadingTrackId = queue[queueIndex].track.id) }
        updateQueueState()
        doPlay(queue[queueIndex].track, queueIndex, ++playRequestId, startPositionMs)
    }

    fun playFavorites(filter: FavoriteTrackFilter, index: Int, track: Track, repeatAll: Boolean = false) {
        if (expandIfCurrent(track.id)) return
        scope.launch {
            val loaded = runCatching {
                withContext(Dispatchers.IO) {
                    val total = favoritesDao.queryCount(FavoriteTrackQueries.count(filter))
                    if (total <= FULL_FAVORITES_QUEUE_LIMIT) {
                        Triple(favoritesDao.queryTracks(FavoriteTrackQueries.window(filter, 0, total)), 0, false)
                    } else {
                        val start = (index - FAVORITES_QUEUE_BEFORE).coerceAtLeast(0)
                        Triple(favoritesDao.queryTracks(FavoriteTrackQueries.window(filter, start, FAVORITES_QUEUE_CHUNK)), start, true)
                    }
                }
            }.getOrNull()
            val tracks = loaded?.first?.map { it.toTrack() }.orEmpty()
            val startIndex = tracks.indexOfFirst { it.id == track.id }
            if (loaded == null || startIndex < 0) {
                playQueue(listOf(track), 0, repeatAll = repeatAll, tag = FAVORITES_QUEUE_TAG)
                return@launch
            }
            playQueue(tracks, startIndex, repeatAll = repeatAll, tag = FAVORITES_QUEUE_TAG)
            if (loaded.third && queue.getOrNull(queueIndex)?.track?.id == track.id) {
                favoritesContinuation = FavoritesContinuation(
                    filter = filter,
                    windowStart = loaded.second,
                    nextOffset = loaded.second + loaded.first.size,
                )
                maybeExtendQueue()
            }
        }
    }

    private fun maybeExtendQueue() {
        val continuation = favoritesContinuation ?: return
        if (extendingQueue || queueIndex !in queue.indices) return
        if (queue.size - queueIndex > QUEUE_EXTEND_THRESHOLD) return
        if (continuation.wrapping && controller?.repeatMode != Player.REPEAT_MODE_ALL) return
        extendingQueue = true
        scope.launch {
            try {
                val limit = if (continuation.wrapping) {
                    minOf(FAVORITES_QUEUE_CHUNK, continuation.windowStart - continuation.nextOffset)
                } else {
                    FAVORITES_QUEUE_CHUNK
                }
                val rows = if (limit <= 0) emptyList() else runCatching {
                    withContext(Dispatchers.IO) {
                        favoritesDao.queryTracks(FavoriteTrackQueries.window(continuation.filter, continuation.nextOffset, limit))
                    }
                }.getOrElse {
                    DebugLog.log(TAG, "maybeExtendQueue: load failed: $it")
                    return@launch
                }
                if (favoritesContinuation !== continuation) return@launch

                val nextOffset = continuation.nextOffset + rows.size
                favoritesContinuation = when {
                    continuation.wrapping && (rows.size < limit || nextOffset >= continuation.windowStart) -> null
                    continuation.wrapping -> continuation.copy(nextOffset = nextOffset)
                    rows.size < limit && continuation.windowStart == 0 -> null
                    rows.size < limit -> continuation.copy(nextOffset = 0, wrapping = true)
                    else -> continuation.copy(nextOffset = nextOffset)
                }
                appendToQueue(rows.map { it.toTrack() })
                DebugLog.log(TAG, "maybeExtendQueue: appended ${rows.size} favorites, queue=${queue.size}, next=$favoritesContinuation")
            } finally {
                extendingQueue = false
            }
            if (favoritesContinuation != null) maybeExtendQueue()
        }
    }

    private fun appendToQueue(sourceTracks: List<Track>) {
        if (queue.isEmpty()) return
        val known = queue.mapTo(HashSet()) { it.track.id }
        val tracks = sourceTracks.filter { knownReason(it) == null && it.id !in known }
        if (tracks.isEmpty()) return
        val entries = wrapAll(tracks)
        val insertIndex = queue.size
        if (originalOrder.isNotEmpty()) {
            originalOrder.addAll(entries)
            val shuffled = entries.shuffled()
            queue.addAll(shuffled)
            controller?.addMediaItems(insertIndex, shuffled.map { buildPendingMediaItem(it.track) })
        } else {
            queue.addAll(entries)
            controller?.addMediaItems(insertIndex, entries.map { buildPendingMediaItem(it.track) })
        }
        updateQueueState()
    }

    fun skipToNext() {
        controller?.let { if (it.hasNextMediaItem()) it.seekToNext() }
    }

    suspend fun queueMoreLikeThis(track: Track): Int {
        val related = runCatching { trackRepository.getRelatedTracksPage(track.id) }
            .onFailure { DebugLog.log(TAG, "queueMoreLikeThis(${track.id}) failed: $it") }
            .getOrDefault(emptyList())
        val queuedIds = queue.mapTo(HashSet()) { it.track.id }
        val fresh = related.filter { it.id !in queuedIds && knownReason(it) == null && it.restrictionReason() == null }
            .take(MORE_LIKE_THIS_LIMIT)
        if (fresh.isEmpty()) return 0
        insertIntoQueue(fresh, atEnd = false)
        return fresh.size
    }

    fun playNext(tracks: List<Track>) {
        insertIntoQueue(tracks, atEnd = false)
    }

    fun addToQueue(tracks: List<Track>) {
        insertIntoQueue(tracks, atEnd = true)
    }

    private fun insertIntoQueue(sourceTracks: List<Track>, atEnd: Boolean) {
        val tracks = sourceTracks.filter { knownReason(it) == null }
        if (tracks.isEmpty()) return
        if (queue.isEmpty() || queueIndex !in queue.indices) {
            playQueue(tracks, 0, tag = currentQueueTag)
            return
        }
        val entries = wrapAll(tracks)
        val insertIndex = if (atEnd) queue.size else (queueIndex + 1).coerceAtMost(queue.size)
        queue.addAll(insertIndex, entries)
        if (originalOrder.isNotEmpty()) originalOrder.addAll(entries)
        controller?.addMediaItems(insertIndex, entries.map { buildPendingMediaItem(it.track) })
        updateQueueState()
        preloadAdjacent()
    }

    fun excludeArtistFromQueue(artistId: Long, artistUsername: String) {
        val usernameLower = artistUsername.trim().lowercase()
        fun matches(t: Track): Boolean =
            t.user.id == artistId || (usernameLower.isNotEmpty() && t.title.lowercase().contains(usernameLower))

        if (queue.isEmpty() || queue.none { matches(it.track) }) return

        var resumeTrack: Track? = null
        for (offset in 1..queue.size) {
            val candidate = queue[(queueIndex + offset) % queue.size].track
            if (!matches(candidate)) {
                resumeTrack = candidate
                break
            }
        }

        val filteredQueue = queue.filterNot { matches(it.track) }
        if (filteredQueue.isEmpty()) {
            queue.clear()
            originalOrder.clear()
            queueIndex = -1
            currentQueueTag = null
            favoritesContinuation = null
            controller?.stop()
            controller?.clearMediaItems()
            flushListenSegment()
            _queueEntries.value = emptyList()
            _state.update {
                it.copy(currentTrack = null, isPlaying = false, isBuffering = false, hasNext = false, hasPrev = false, queueTag = null, queueIndex = -1)
            }
            return
        }

        if (originalOrder.isNotEmpty()) {
            val filteredOriginal = originalOrder.filterNot { matches(it.track) }
            originalOrder.clear()
            originalOrder.addAll(filteredOriginal)
        }

        queue.clear()
        queue.addAll(filteredQueue)
        queueIndex = resumeTrack?.let { rt -> queue.indexOfFirst { it.track.id == rt.id } }?.takeIf { it >= 0 } ?: 0

        _state.update { it.copy(loadingTrackId = queue[queueIndex].track.id) }
        updateQueueState()
        doPlay(queue[queueIndex].track, queueIndex, ++playRequestId)
    }

    fun skipToPrevious() {
        controller?.seekToPrevious()
    }

    // Repositions a queue entry without touching what's actually playing - moveMediaItem() re-indexes the
    // existing window in place (no re-resolve, no audible hiccup), unlike the setMediaItems()-based rebuilds
    // used elsewhere in this file for bulk queue changes.
    fun moveQueueItem(from: Int, to: Int) {
        if (from !in queue.indices || to !in queue.indices || from == to) return
        val item = queue.removeAt(from)
        queue.add(to, item)
        queueIndex = when {
            from == queueIndex -> to
            from < queueIndex && to >= queueIndex -> queueIndex - 1
            from > queueIndex && to <= queueIndex -> queueIndex + 1
            else -> queueIndex
        }
        controller?.moveMediaItem(from, to)
        // Belt-and-suspenders resync: MediaController mirrors the session's player state locally and
        // synchronously for commands it issues itself, so this reflects the post-move reality immediately.
        controller?.currentMediaItemIndex?.takeIf { it in queue.indices }?.let { queueIndex = it }
        updateQueueState()
    }

    // Removing the currently playing entry is the one case that can trigger a real onMediaItemTransition
    // (ExoPlayer auto-advances to whatever now occupies that slot) - queueIndex is deliberately NOT adjusted
    // by hand for that case below; it's resynced straight from the controller once the removal has applied.
    fun removeQueueItem(index: Int) {
        if (index !in queue.indices) return
        val removed = queue.removeAt(index)
        if (originalOrder.isNotEmpty()) {
            val i = originalOrder.indexOfFirst { it.id == removed.id }
            if (i >= 0) originalOrder.removeAt(i)
        }
        if (queue.isEmpty()) {
            queueIndex = -1
            currentQueueTag = null
            favoritesContinuation = null
            controller?.stop()
            controller?.clearMediaItems()
            flushListenSegment()
            _queueEntries.value = emptyList()
            _state.update {
                it.copy(currentTrack = null, isPlaying = false, isBuffering = false, hasNext = false, hasPrev = false, queueTag = null, queueIndex = -1)
            }
            return
        }
        val wasCurrent = index == queueIndex
        if (!wasCurrent && index < queueIndex) queueIndex--
        controller?.let { if (index < it.mediaItemCount) it.removeMediaItem(index) }
        if (wasCurrent) {
            queueIndex = controller?.currentMediaItemIndex?.takeIf { it in queue.indices } ?: index.coerceIn(0, queue.lastIndex)
        }
        updateQueueState()
    }

    // Jumps playback straight to an existing queue slot (tap-to-play in the Queue screen) without
    // reshuffling or otherwise touching the rest of the queue.
    fun playFromQueue(index: Int) {
        if (index !in queue.indices) return
        val entry = queue[index]
        knownReason(entry.track)?.let { reason ->
            DebugLog.log(TAG, "playFromQueue: id=${entry.track.id} title=${entry.track.title} known unavailable ($reason)")
            _skippedTrackEvents.tryEmit(SkippedTrack(entry.track, reason))
            scope.launch { markUnavailable(entry.track.id, reason) }
            return
        }
        queueIndex = index
        _state.update { it.copy(loadingTrackId = entry.track.id) }
        updateQueueState()
        doPlay(entry.track, index, ++playRequestId)
    }

    fun toggleShuffle() {
        val enabling = !_state.value.shuffleEnabled
        val current = queue.getOrNull(queueIndex)

        if (enabling) {
            originalOrder.clear()
            originalOrder.addAll(queue)
            val previous = if (current != null) queue.getOrNull(queueIndex - 1) else null
            val rest = queue.filter { it.id != current?.id && it.id != previous?.id }.shuffled()
            queue.clear()
            previous?.let { queue.add(it) }
            current?.let { queue.add(it) }
            queue.addAll(rest)
            queueIndex = if (previous != null) 1 else 0
        } else if (originalOrder.isNotEmpty()) {
            queue.clear()
            queue.addAll(originalOrder)
            originalOrder.clear()
            queueIndex = current?.let { c -> queue.indexOfFirst { it.id == c.id } }?.takeIf { it >= 0 } ?: 0
        }
        // `current`/originalOrder entries are matched by QueueEntry.id above, not Track.id - correctly
        // disambiguates duplicate tracks in the queue, unlike matching on the track's own id would.

        rebuildTimelinePreservingPlayback()
        _state.update { it.copy(shuffleEnabled = enabling) }
        prefs.edit().putBoolean("shuffle_enabled", enabling).apply()
    }

    // Rebuilds the controller's playlist to match `queue`'s current order without disturbing what's actually
    // playing: the current window reuses its already-resolved MediaItem (no re-fetch, no audible hiccup), every
    // other position goes back to a fresh "pending" placeholder to be resolved again as needed.
    private fun rebuildTimelinePreservingPlayback() {
        val c = controller ?: return
        val currentItem = c.currentMediaItem ?: return
        val pos = c.currentPosition
        val items = queue.mapIndexed { i, t -> if (i == queueIndex) currentItem else buildPendingMediaItem(t.track) }
        c.setMediaItems(items, queueIndex, pos)
        c.prepare()
        if (c.playWhenReady) c.play()
        updateQueueState()
        preloadAdjacent()
    }

    fun setPlaybackSpeed(speed: Float) {
        val clamped = speed.coerceIn(MIN_PLAYBACK_SPEED, MAX_PLAYBACK_SPEED)
        _state.update { it.copy(playbackSpeed = clamped) }
        applyPlaybackParameters()
        prefs.edit().putFloat("playback_speed", clamped).apply()
    }

    fun setSoundMode(mode: SoundMode) {
        val clamped = mode.copy(
            customRate = mode.customRate.coerceIn(SoundMode.MIN_RATE, SoundMode.MAX_RATE),
            customReverb = mode.customReverb.coerceIn(0f, 1f),
            customBass = mode.customBass.coerceIn(0f, 1f),
            eq = mode.eq.normalizedEq(),
            noise = mode.noise.coerceIn(0f, 1f),
        )
        _state.update { it.copy(soundMode = clamped) }
        applyPlaybackParameters()
        prefs.edit()
            .putString("sound_preset", clamped.preset.name)
            .putFloat("sound_custom_rate", clamped.customRate)
            .putFloat("sound_custom_reverb", clamped.customReverb)
            .putFloat("sound_custom_bass", clamped.customBass)
            .putString("sound_eq", clamped.eq.joinToString(","))
            .putFloat("sound_noise", clamped.noise)
            .apply()
    }

    private fun loadSoundMode(): SoundMode = SoundMode(
        preset = prefs.getString("sound_preset", null)
            ?.let { runCatching { SoundPreset.valueOf(it) }.getOrNull() }
            ?: SoundPreset.OFF,
        customRate = prefs.getFloat("sound_custom_rate", 1f).coerceIn(SoundMode.MIN_RATE, SoundMode.MAX_RATE),
        customReverb = prefs.getFloat("sound_custom_reverb", 0f).coerceIn(0f, 1f),
        customBass = prefs.getFloat("sound_custom_bass", 0f).coerceIn(0f, 1f),
        eq = prefs.getString("sound_eq", null)
            ?.split(",")
            ?.mapNotNull { it.toFloatOrNull() }
            .orEmpty()
            .normalizedEq(),
        noise = prefs.getFloat("sound_noise", SoundMode.DEFAULT_NOISE).coerceIn(0f, 1f),
    )

    private fun applyPlaybackParameters() {
        val current = _state.value
        val mode = current.soundMode
        soundEffects.reverb = mode.reverb
        soundEffects.bass = mode.bass
        soundEffects.eq = mode.eq.toFloatArray()
        soundEffects.noise = mode.noise
        soundEffects.outputRate = current.playbackSpeed * mode.rate
        controller?.playbackParameters = androidx.media3.common.PlaybackParameters(
            current.playbackSpeed * mode.rate,
            mode.rate,
        )
    }

    fun cycleRepeatMode() {
        controller?.let {
            val next = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
            it.repeatMode = next
            prefs.edit().putInt("repeat_mode", next).apply()
        }
    }

    fun startSleepTimerAfterCurrentTrack() {
        sleepTimerJob?.cancel()
        sleepTimerJob = null
        _sleepTimerRemainingMs.value = null
        _sleepAfterCurrentTrack.value = true
    }

    fun startSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        _sleepAfterCurrentTrack.value = false
        sleepTimerJob = scope.launch {
            var remaining = minutes * 60_000L
            _sleepTimerRemainingMs.value = remaining
            while (remaining > 0) {
                delay(1000L)
                remaining -= 1000L
                _sleepTimerRemainingMs.value = remaining.coerceAtLeast(0L)
            }
            _sleepTimerRemainingMs.value = null
            controller?.pause()
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        sleepTimerJob = null
        _sleepTimerRemainingMs.value = null
        _sleepAfterCurrentTrack.value = false
    }

    private fun updateQueueState() {
        _queueEntries.value = queue.toList()
        _state.update {
            it.copy(
                hasNext = controller?.hasNextMediaItem() ?: (queueIndex < queue.lastIndex),
                hasPrev = controller?.hasPreviousMediaItem() ?: (queueIndex > 0),
                queueTag = currentQueueTag,
                queueIndex = queueIndex,
            )
        }
    }

    private fun doPlay(track: Track, requestIndex: Int, requestId: Long, startPositionMs: Long = 0L) {
        scope.launch {
            val resolved = resolveTrack(track)
            if (requestId != playRequestId) return@launch
            if (resolved == null) {
                _state.update { it.copy(loadingTrackId = null) }
                skipDueToFailure(track, requestIndex)
                return@launch
            }
            val (fullTrack, url, needsCaching, isHls) = resolved


            playerCommandMutex.withLock {
                if (requestId != playRequestId) return@withLock

                // toggleShuffle() reorders `queue` without issuing a new play request, so requestIndex
                // can be stale by the time a slow resolve finishes - trusting it would drop this track's
                // real URL onto whatever now sits at that position and play the wrong song.
                val index = queue.indexOfFirst { it.track.id == fullTrack.id }
                    .takeIf { it >= 0 } ?: requestIndex.coerceIn(0, queue.lastIndex.coerceAtLeast(0))
                queueIndex = index
                adoptResolvedTrack(index, fullTrack)

                val allItems = queue.mapIndexed { i, t ->
                    if (i == index) buildMediaItem(fullTrack, url, isHls) else buildPendingMediaItem(t.track)
                }

                beginListenSegment(fullTrack)
                _state.update { it.copy(currentTrack = fullTrack, durationMs = fullTrack.durationMs, loadingTrackId = null) }
                extractSeedColor(fullTrack.artworkUrl, fullTrack.title)
                controller?.apply {
                    val startAt = if (fullTrack.durationMs > 0) {
                        startPositionMs.coerceIn(0L, (fullTrack.durationMs - 1000L).coerceAtLeast(0L))
                    } else {
                        startPositionMs.coerceAtLeast(0L)
                    }
                    setMediaItems(allItems, index, startAt)
                    prepare()
                    play()
                }
                updateQueueState()
                preloadAdjacent()
            }

            if (needsCaching) {
                trackCache.cacheAudioFile(fullTrack, url)
            }
        }
    }

    fun togglePlayPause() {
        controller?.let { if (it.isPlaying) it.pause() else it.play() }
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
    }

    // --- "Hand on the record" ---------------------------------------------------------------
    // While the finger is on a playing record, the normal player is muted and the scratch sound is
    // played on a separate low-latency output (see ScratchPlayer): the last seconds of the track at
    // the finger's speed and direction. The real player keeps running silently underneath, and is
    // only moved when the finger lets go. Speed 1 is normal forward speed, negative is backwards.

    private val scratchPlayer = ScratchPlayer(soundEffects)
    private var scratchActive = false
    private var volumeBeforeScratch = 1f

    fun beginScratch(initialSpeed: Float) {
        if (scratchActive) return
        val started = scratchPlayer.start(
            initialSpeed.coerceIn(-MAX_SCRATCH_SPEED, MAX_SCRATCH_SPEED),
            soundEffects.noise,
        )
        if (!started) return // nothing to scratch yet: leave the player alone
        scratchActive = true
        fadeJob?.cancel()
        volumeBeforeScratch = controller?.volume ?: 1f
        controller?.volume = 0f
    }

    /** Warms up the scratch output on a background thread. Call when playback starts. */
    fun prepareScratch() {
        scope.launch(Dispatchers.Default) { scratchPlayer.prepare() }
    }

    fun scratchSpeed(speed: Float) {
        if (scratchActive) scratchPlayer.setSpeed(speed.coerceIn(-MAX_SCRATCH_SPEED, MAX_SCRATCH_SPEED))
    }

    /**
     * The finger let go. When [seek] is true the player is moved to [positionMs], the point the
     * record was wound to, unless it is already within [SCRATCH_RESUME_TOLERANCE_MS] of it, in
     * which case it just carries on without any gap.
     */
    fun endScratch(positionMs: Long, seek: Boolean) {
        val wasScratching = scratchActive
        if (wasScratching) {
            scratchActive = false
            scratchPlayer.stop()
        }
        if (seek) {
            val actual = controller?.currentPosition ?: positionMs
            if (kotlin.math.abs(actual - positionMs) > SCRATCH_RESUME_TOLERANCE_MS) seekTo(positionMs)
        }
        // Only undo our own mute, so a fade-out that is running at the end of a track is left alone.
        if (wasScratching) controller?.volume = volumeBeforeScratch
    }

    fun beginScrub() {
        isScrubbing = true
        wasPlayingBeforeScrub = controller?.isPlaying == true
        if (!wasPlayingBeforeScrub) controller?.play()
    }

    fun scrubTo(positionMs: Long) {
        if (!isScrubbing) return
        pendingScrubJob?.cancel()
        val now = System.currentTimeMillis()
        val elapsed = now - lastScrubSeekAtMs
        if (elapsed >= SCRUB_THROTTLE_MS) {
            lastScrubSeekAtMs = now
            controller?.seekTo(positionMs)
        } else {
            pendingScrubJob = scope.launch {
                delay(SCRUB_THROTTLE_MS - elapsed)
                lastScrubSeekAtMs = System.currentTimeMillis()
                controller?.seekTo(positionMs)
            }
        }
    }

    fun endScrub(positionMs: Long) {
        if (!isScrubbing) {
            controller?.seekTo(positionMs)
            return
        }
        pendingScrubJob?.cancel()
        pendingScrubJob = null
        isScrubbing = false
        controller?.seekTo(positionMs)
        if (!wasPlayingBeforeScrub) controller?.pause()
    }

    fun currentPosition(): Long = controller?.currentPosition ?: 0L

    fun setLoop(startMs: Long, endMs: Long) {
        val duration = _state.value.durationMs
        if (duration <= 0L) return
        val end = endMs.coerceIn(MIN_LOOP_MS, (duration - LOOP_END_GUARD_MS).coerceAtLeast(MIN_LOOP_MS))
        val start = startMs.coerceIn(0L, (end - MIN_LOOP_MS).coerceAtLeast(0L))
        _state.update { it.copy(loop = LoopRegion(start, end)) }
        if (loopJob?.isActive != true) loopJob = scope.launch { runLoop() }
    }

    fun clearLoop() {
        loopJob?.cancel()
        loopJob = null
        _state.update { it.copy(loop = null) }
    }

    private suspend fun runLoop() {
        while (true) {
            val region = _state.value.loop ?: return
            val player = controller
            if (player == null || !player.isPlaying || isScrubbing) {
                delay(LOOP_IDLE_POLL_MS)
                continue
            }
            val position = player.currentPosition
            if (position >= region.endMs) {
                player.seekTo(region.startMs)
                updatePosition()
                delay(LOOP_SEEK_SETTLE_MS)
                continue
            }
            val speed = _state.value.playbackSpeed.coerceAtLeast(0.1f)
            delay(((region.endMs - position) / speed).toLong().coerceIn(LOOP_MIN_POLL_MS, LOOP_MAX_POLL_MS))
        }
    }

    fun release() {
        stopPositionPolling()
        sleepTimerJob?.cancel()
        flushListenSegment()
        saveState()
        scratchPlayer.release()
        controller?.release()
        controller = null
    }

    fun saveState() {
        val track = _state.value.currentTrack ?: return
        prefs.edit().apply {
            putString("last_track", trackToJson(track).toString())
            putLong("position_ms", _state.value.positionMs)
            val queueJson = JSONArray()
            queue.forEach { queueJson.put(trackToJson(it.track)) }
            putString("queue", queueJson.toString())
            putInt("queue_index", queueIndex)
            val continuation = favoritesContinuation
            if (continuation == null) {
                remove(KEY_FAVORITES_CONTINUATION)
            } else {
                putString(KEY_FAVORITES_CONTINUATION, continuation.toJson().toString())
            }
            apply()
        }
    }

    private fun primeFromSavedState() {
        val trackStr = prefs.getString("last_track", null) ?: return
        val track = runCatching { jsonToTrack(JSONObject(trackStr)) }.getOrNull() ?: return
        val cachedUrl = prefs.getString("seed_color_url", null)
        if (cachedUrl != null && cachedUrl == track.artworkUrl && prefs.contains("seed_color")) {
            seedColorUrl = cachedUrl
            _seedColor.value = Color(prefs.getInt("seed_color", 0))
        }
        _state.update {
            it.copy(
                currentTrack = track,
                durationMs = track.durationMs,
                positionMs = prefs.getLong("position_ms", 0L).coerceAtLeast(0L),
                loadingTrackId = track.id,
            )
        }
        extractSeedColor(track.artworkUrl, track.title)
    }

    private fun restorePlayLastTrack() {
        val trackStr = prefs.getString("last_track", null)
        if (trackStr == null) return
        val position = prefs.getLong("position_ms", 0)
        try {
            val track = jsonToTrack(JSONObject(trackStr))
            val queueStr = prefs.getString("queue", null)
            val queueIdx = prefs.getInt("queue_index", 0)
            if (queueStr != null) {
                val arr = JSONArray(queueStr)
                queue.clear()
                for (i in 0 until arr.length()) {
                    queue.add(wrap(jsonToTrack(arr.getJSONObject(i))))
                }
                queueIndex = queueIdx.coerceIn(0, queue.lastIndex.coerceAtLeast(0))
            }
            favoritesContinuation = prefs.getString(KEY_FAVORITES_CONTINUATION, null)
                ?.let { runCatching { FavoritesContinuation.fromJson(JSONObject(it)) }.getOrNull() }
            if (queue.getOrNull(queueIndex)?.track?.id != track.id) {
                queueIndex = queue.indexOfFirst { it.track.id == track.id }
                if (queueIndex < 0) {
                    queue.add(wrap(track))
                    queueIndex = queue.lastIndex
                }
            }
            val requestId = ++playRequestId
            updateQueueState()
            scope.launch {
                val resolved = resolveTrack(track)
                if (resolved == null) {
                    if (requestId == playRequestId && controller?.mediaItemCount == 0) {
                        _state.update { it.copy(currentTrack = null, loadingTrackId = null) }
                    }
                    return@launch
                }
                if (requestId != playRequestId) return@launch
                val (fullTrack, url, needsCaching, isHls) = resolved
                playerCommandMutex.withLock {
                    if (requestId != playRequestId) return@withLock
                    adoptResolvedTrack(queueIndex, fullTrack)
                    val items = queue.mapIndexed { index, entry ->
                        if (index == queueIndex) buildMediaItem(fullTrack, url, isHls)
                        else buildPendingMediaItem(entry.track)
                    }
                    beginListenSegment(fullTrack)
                    _state.update { it.copy(currentTrack = fullTrack, durationMs = fullTrack.durationMs, loadingTrackId = null) }
                    extractSeedColor(fullTrack.artworkUrl, fullTrack.title)
                    controller?.apply {
                        setMediaItems(items, queueIndex, position.coerceAtLeast(0L))
                        prepare()
                    }
                    updateQueueState()
                    preloadAdjacent()
                    maybeExtendQueue()
                }
                if (needsCaching) {
                    trackCache.cacheAudioFile(fullTrack, url)
                }
            }
        } catch (_: Exception) {
            _state.update { it.copy(currentTrack = null, loadingTrackId = null) }
        }
    }

    private fun trackToJson(track: Track): JSONObject = JSONObject().apply {
        put("id", track.id)
        put("title", track.title)
        put("durationMs", track.durationMs)
        put("artworkUrl", track.artworkUrl)
        put("permalinkUrl", track.permalinkUrl)
        put("userId", track.user.id)
        put("username", track.user.username)
        put("userAvatarUrl", track.user.avatarUrl)
    }

    private fun jsonToTrack(obj: JSONObject): Track = Track(
        id = obj.getLong("id"),
        title = obj.getString("title"),
        durationMs = obj.getLong("durationMs"),
        artworkUrl = obj.optString("artworkUrl", null),
        permalinkUrl = obj.optString("permalinkUrl", null),
        user = User(
            id = obj.getLong("userId"),
            username = obj.getString("username"),
            avatarUrl = obj.optString("userAvatarUrl", null)
        )
    )

    // Cancelling the previous extraction is what keeps the color in sync while skipping quickly:
    // these run at wildly different speeds (cache hit vs network fetch vs decode), so without it
    // whichever request happens to finish last wins, which is rarely the track now playing.
    private fun extractSeedColor(sourceUrl: String?, title: String) {
        val artworkUrl = sourceUrl.takeUnless { GeneratedArtworkDebugState.forceEverywhere.value }
        val key = artworkUrl ?: "generated:$title"
        if (key == seedColorUrl && (_seedColor.value != null || seedColorJob?.isActive == true)) return
        seedColorJob?.cancel()
        seedColorUrl = key
        val fallback = generatedArtworkSeedColor(title)
        if (artworkUrl == null) {
            _seedColor.value = fallback
            return
        }
        seedColorJob = scope.launch {
            try {
                val request = ImageRequest.Builder(context)
                    .data(artworkUrl.replace("-large", "-t500x500"))
                    .allowHardware(false)
                    .build()
                val result = context.imageLoader.execute(request)
                val bitmap = ((result as? SuccessResult)?.drawable as? BitmapDrawable)?.bitmap
                val swatch = bitmap?.let { Palette.from(it).generate() }?.let { it.vibrantSwatch ?: it.dominantSwatch }
                ensureActive()
                if (swatch != null) {
                    _seedColor.value = Color(swatch.rgb)
                    prefs.edit()
                        .putString("seed_color_url", artworkUrl)
                        .putInt("seed_color", swatch.rgb)
                        .apply()
                } else {
                    _seedColor.value = fallback
                }
            } catch (_: CancellationException) {
                throw CancellationException()
            } catch (_: Exception) {
                _seedColor.value = fallback
            }
        }
    }
}

const val FAVORITES_QUEUE_TAG = "favorites"

private data class FavoritesContinuation(
    val filter: FavoriteTrackFilter,
    val windowStart: Int,
    val nextOffset: Int,
    val wrapping: Boolean = false,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("search", filter.search)
        put("order", filter.order.name)
        put("descending", filter.descending)
        put("windowStart", windowStart)
        put("nextOffset", nextOffset)
        put("wrapping", wrapping)
    }

    companion object {
        fun fromJson(json: JSONObject) = FavoritesContinuation(
            filter = FavoriteTrackFilter(
                search = json.optString("search"),
                order = FavoriteTrackOrder.valueOf(json.getString("order")),
                descending = json.optBoolean("descending"),
            ),
            windowStart = json.getInt("windowStart"),
            nextOffset = json.getInt("nextOffset"),
            wrapping = json.optBoolean("wrapping"),
        )
    }
}
