package com.savoo.scclient.ui.screens.player

import com.savoo.scclient.ui.components.LocalLiquidGlass
import com.savoo.scclient.ui.components.LocalGlassState
import com.savoo.scclient.ui.components.liquidGlass
import com.savoo.scclient.ui.components.glassStretch
import com.savoo.scclient.ui.components.glassHighlight
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.haze
import androidx.compose.material3.contentColorFor
import androidx.compose.runtime.CompositionLocalProvider
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.Spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.automirrored.filled.Comment
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lyrics
import androidx.compose.material.icons.filled.LibraryAdd
import androidx.compose.material.icons.filled.Loop
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PersonOff
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LoadingIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SliderState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import android.content.Intent
import android.widget.Toast
import com.savoo.scclient.R
import com.savoo.scclient.data.model.LyricsResult
import com.savoo.scclient.data.model.LyricsSource
import com.savoo.scclient.data.model.Track
import com.savoo.scclient.data.model.TrackComment
import com.savoo.scclient.data.repository.AppBackgroundMode
import com.savoo.scclient.data.repository.ArtworkShape
import com.savoo.scclient.data.repository.PlayerBackgroundStyle
import com.savoo.scclient.data.repository.PlayerStyle
import com.savoo.scclient.data.repository.SeekBarStyle
import com.savoo.scclient.data.repository.TimedCommentsRate
import com.savoo.scclient.player.BulkDownloadProgress
import com.savoo.scclient.player.PlaybackState
import com.savoo.scclient.player.PlayerController
import com.savoo.scclient.ui.haptics.rememberHapticTick
import com.savoo.scclient.ui.haptics.rememberHaptics
import com.savoo.scclient.ui.theme.buildPixelScheme
import com.savoo.scclient.ui.components.AddToPlaylistSheet
import com.savoo.scclient.ui.components.FavoritesSyncBanner
import com.savoo.scclient.ui.components.PlaylistAddBanner
import com.savoo.scclient.data.repository.FavoritesSyncState
import com.savoo.scclient.data.repository.PlaylistAddProgress
import com.savoo.scclient.ui.components.TrackArtwork
import com.savoo.scclient.ui.components.artworkProgressRing
import com.savoo.scclient.ui.components.rememberArtworkShape
import com.savoo.scclient.ui.components.TrackSkippedBanner
import com.savoo.scclient.ui.components.AppDivider
import com.savoo.scclient.ui.components.PlayerInfoBanner
import com.savoo.scclient.ui.components.BulkDownloadBanner
import com.savoo.scclient.ui.components.FavoritesImportBanner
import com.savoo.scclient.data.repository.FavoritesImportState
import com.savoo.scclient.ui.components.ConfirmOfflineRemoval
import com.savoo.scclient.ui.components.UndoAction
import com.savoo.scclient.ui.components.UndoBanner
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.cos
import kotlin.math.roundToLong
import kotlin.math.sin
import kotlin.math.pow
import kotlin.math.abs
import kotlin.math.exp
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableIntStateOf

@OptIn(ExperimentalMaterial3Api::class)
@UnstableApi
@Composable
fun PlayerSheet(
    onArtistClick: (Long) -> Unit = {},
    viewModel: PlayerViewModel = hiltViewModel(),
    showDockBar: Boolean = true,
    dockBar: @Composable () -> Unit,
) {
    val state by viewModel.controller.state.collectAsState()
    val glowColor by viewModel.controller.seedColor.collectAsState()
    val offlineSaveResult by viewModel.offlineSaveResult.collectAsState()
    var showFullPlayer by rememberSaveable { mutableStateOf(false) }
    val track = state.currentTrack
    val haptics = rememberHaptics()
    val shareContext = LocalContext.current
    val onShare: () -> Unit = {
        state.currentTrack?.let { current ->
            viewModel.shareTrack(current) { url ->
                if (url != null) {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, url)
                    }
                    shareContext.startActivity(Intent.createChooser(intent, null))
                } else {
                    Toast.makeText(shareContext, R.string.player_share_failed, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    var skippedTrack by remember { mutableStateOf<com.savoo.scclient.player.SkippedTrack?>(null) }
    val undoAction by viewModel.undoController.current.collectAsState()
    val bulkDownload by viewModel.bulkDownload.collectAsState()
    val favoritesImport by viewModel.favoritesImport.collectAsState()
    val playlistAdd by viewModel.playlistAdd.collectAsState()
    val favoritesPush by viewModel.favoritesPush.collectAsState()

    BackHandler(enabled = showFullPlayer) { showFullPlayer = false }

    LaunchedEffect(offlineSaveResult) {
        when (offlineSaveResult) {
            true -> haptics.success()
            false -> haptics.error()
            null -> Unit
        }
        if (offlineSaveResult != null) viewModel.consumeOfflineSaveResult()
    }

    LaunchedEffect(undoAction) {
        val action = undoAction ?: return@LaunchedEffect
        delay(4000)
        viewModel.undoController.dismiss(action)
    }

    LaunchedEffect(Unit) {
        viewModel.controller.expandRequests.collect { showFullPlayer = true }
    }

    LaunchedEffect(Unit) {
        viewModel.controller.skippedTrackEvents.collect { skipped ->
            skippedTrack = skipped
            delay(5000)
            if (skippedTrack?.track?.id == skipped.track.id) skippedTrack = null
        }
    }

    Column {
        val bannerEnter = expandVertically(
            animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMedium),
            expandFrom = Alignment.Bottom,
        ) + fadeIn(spring(stiffness = Spring.StiffnessMedium)) +
            slideInVertically(
                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
                initialOffsetY = { -it / 2 },
            )
        val bannerExit = shrinkVertically(
            animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMedium),
            shrinkTowards = Alignment.Bottom,
        ) + fadeOut(spring(stiffness = Spring.StiffnessMedium)) +
            slideOutVertically(
                animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMedium),
                targetOffsetY = { -it / 2 },
            )
        var lastBulkDownload by remember { mutableStateOf<BulkDownloadProgress?>(null) }
        bulkDownload?.let { lastBulkDownload = it }
        AnimatedVisibility(visible = bulkDownload != null, enter = bannerEnter, exit = bannerExit) {
            lastBulkDownload?.let { progress ->
                BulkDownloadBanner(
                    progress = progress,
                    onCancel = { viewModel.cancelBulkDownloads() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
        }
        var lastFavoritesImport by remember { mutableStateOf<FavoritesImportState?>(null) }
        favoritesImport?.let { lastFavoritesImport = it }
        AnimatedVisibility(visible = favoritesImport != null, enter = bannerEnter, exit = bannerExit) {
            lastFavoritesImport?.let { importState ->
                FavoritesImportBanner(
                    state = importState,
                    onCancel = { viewModel.cancelFavoritesImport() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
        }
        var lastPlaylistAdd by remember { mutableStateOf<PlaylistAddProgress?>(null) }
        playlistAdd?.let { lastPlaylistAdd = it }
        AnimatedVisibility(visible = playlistAdd != null, enter = bannerEnter, exit = bannerExit) {
            lastPlaylistAdd?.let { progress ->
                PlaylistAddBanner(
                    progress = progress,
                    onCancel = { viewModel.cancelPlaylistAdd() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
        }
        var lastFavoritesPush by remember { mutableStateOf<FavoritesSyncState?>(null) }
        favoritesPush?.let { lastFavoritesPush = it }
        AnimatedVisibility(visible = favoritesPush != null, enter = bannerEnter, exit = bannerExit) {
            lastFavoritesPush?.let { pushState ->
                FavoritesSyncBanner(
                    state = pushState,
                    onCancel = { viewModel.cancelFavoritesPush() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
        }
        var lastSkippedTrack by remember { mutableStateOf<com.savoo.scclient.player.SkippedTrack?>(null) }
        skippedTrack?.let { lastSkippedTrack = it }
        AnimatedVisibility(
            visible = skippedTrack != null,
            enter = bannerEnter,
            exit = bannerExit,
        ) {
            lastSkippedTrack?.let { skipped ->
                TrackSkippedBanner(
                    trackTitle = skipped.track.title,
                    reason = skipped.reason,
                    onRetry = {
                        skippedTrack = null
                        viewModel.controller.retryTrack(skipped.track)
                    },
                    onDismiss = { skippedTrack = null },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
        }
        var lastUndoAction by remember { mutableStateOf<UndoAction?>(null) }
        undoAction?.let { lastUndoAction = it }
        AnimatedVisibility(visible = undoAction != null, enter = bannerEnter, exit = bannerExit) {
            lastUndoAction?.let { action ->
                UndoBanner(
                    message = stringResource(action.messageRes, *action.messageArgs.toTypedArray()),
                    icon = action.icon,
                    onUndo = { viewModel.undoController.undo(action) },
                    onDismiss = { viewModel.undoController.dismiss(action) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
        }
        if (track != null || showDockBar) Surface(
        color = if (LocalLiquidGlass.current) Color.Transparent else MaterialTheme.colorScheme.surfaceContainerHigh,
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .navigationBarsPadding()
            .glassStretch(pressScale = 1.02f, stretch = 0.04f)
            .liquidGlass(RoundedCornerShape(28.dp))
            // Extra clearance on top of the system nav-bar inset: on some devices (MIUI's gesture
            // nav in particular) touches near the very bottom edge get eaten by the OS gesture
            // recognizer before this composable ever sees them, even though the reported inset says
            // there's room - buttons placed right at that boundary can end up untappable.
            .padding(bottom = 8.dp),
    ) {
        Column {
            if (track != null) {
                MiniPlayerRow(
                    track = track,
                    state = state,
                    isFavorite = viewModel.isFavorite.collectAsState().value,
                    onExpand = { showFullPlayer = true },
                    onTogglePlay = { viewModel.controller.togglePlayPause() },
                    onToggleFavorite = { viewModel.toggleFavoriteWithUndo() },
                    onNext = { haptics.skipForward(); viewModel.controller.skipToNext() },
                    onPrev = { haptics.skipBack(); viewModel.controller.skipToPrevious() },
                )
                if (showDockBar) Spacer(Modifier.height(6.dp))
                if (showDockBar) AppDivider(
                    modifier = Modifier.padding(horizontal = 18.dp),
                    alpha = 0.3f,
                )
            }
            if (showDockBar) dockBar()
        }
    }
    }

    if (showFullPlayer && track != null) {
        FullPlayerSheet(
            controller = viewModel.controller,
            state = state,
            isFavorite = viewModel.isFavorite.collectAsState().value,
            isOffline = viewModel.isOffline.collectAsState().value,
            isSavingOffline = viewModel.isSavingOffline.collectAsState().value,
            isMixPlaying = viewModel.isMixPlaying.collectAsState().value,
            onShare = onShare,
            pulse = rememberBeatPulse(
                effects = viewModel.soundEffects,
                enabled = viewModel.beatPulseEnabled.collectAsState().value,
                isPlaying = state.isPlaying,
            ),
            glowColor = glowColor,
            seekBarStyle = viewModel.seekBarStyle.collectAsState().value,
            waveform = viewModel.waveform.collectAsState().value,
            playerStyle = viewModel.playerStyle.collectAsState().value,
            backgroundMode = viewModel.backgroundMode.collectAsState().value,
            showCustomizeHint = !viewModel.playerHintShown.collectAsState().value,
            onDismissCustomizeHint = { viewModel.dismissPlayerHint() },
            backgroundStyle = viewModel.playerBackgroundStyle.collectAsState().value,
            pixelGlowEnabled = viewModel.pixelGlowEnabled.collectAsState().value,
            artworkShape = viewModel.artworkShape.collectAsState().value,
            artworkRingEnabled = viewModel.artworkRingEnabled.collectAsState().value,
            artworkScale = viewModel.artworkScale.collectAsState().value,
            lyrics = viewModel.lyrics.collectAsState().value,
            lyricsAnnotations = viewModel.lyricsAnnotations.collectAsState().value,
            onRequestLyricsAnnotations = { viewModel.requestLyricsAnnotations() },
            timedComments = viewModel.timedComments.collectAsState().value,
            commentsEnabled = viewModel.timedCommentsEnabled.collectAsState().value,
            commentsRate = viewModel.timedCommentsRate.collectAsState().value,
            currentUserId = viewModel.currentUserId.collectAsState().value,
            onDeleteComment = { comment -> viewModel.deleteComment(comment) },
            canComment = viewModel.canComment.collectAsState().value,
            onSubmitComment = { body, at -> viewModel.postComment(body, at) },
            activeLyricsLine = viewModel.activeLyricsLine.collectAsState().value,
            lyricsSync = viewModel.lyricsSyncState.collectAsState().value,
            onLyricsSyncAction = { viewModel.onLyricsSyncAction(it) },
            onForceLyrics = { source -> viewModel.forceLyrics(source) },
            onDismiss = { showFullPlayer = false },
            onTogglePlay = { viewModel.controller.togglePlayPause() },
            onScrubStart = { viewModel.controller.beginScrub() },
            onScrub = { viewModel.controller.scrubTo(it) },
            onSeek = { viewModel.controller.endScrub(it) },
            onToggleFavorite = { viewModel.toggleFavorite() },
            onSaveForOffline = { viewModel.saveForOffline() },
            onRemoveFromOffline = { viewModel.removeFromOffline() },
            onNext = { haptics.skipForward(); viewModel.controller.skipToNext() },
            onPrev = { haptics.skipBack(); viewModel.controller.skipToPrevious() },
            onToggleShuffle = { viewModel.controller.toggleShuffle() },
            onCycleRepeat = { viewModel.controller.cycleRepeatMode() },
            onArtistClick = { id -> showFullPlayer = false; onArtistClick(id) },
            onExcludeArtist = { viewModel.excludeCurrentArtistAndSkip() },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@androidx.annotation.OptIn(UnstableApi::class)
@Composable
private fun FullPlayerSheet(
    controller: PlayerController,
    state: PlaybackState,
    isFavorite: Boolean,
    isOffline: Boolean,
    isSavingOffline: Boolean,
    isMixPlaying: Boolean,
    onShare: () -> Unit,
    pulse: () -> Float,
    glowColor: Color?,
    seekBarStyle: SeekBarStyle,
    waveform: FloatArray?,
    playerStyle: PlayerStyle,
    backgroundMode: AppBackgroundMode,
    backgroundStyle: PlayerBackgroundStyle,
    pixelGlowEnabled: Boolean,
    artworkShape: ArtworkShape,
    artworkRingEnabled: Boolean,
    artworkScale: Float,
    showCustomizeHint: Boolean,
    onDismissCustomizeHint: () -> Unit,
    lyrics: LyricsResult?,
    lyricsAnnotations: Map<Int, List<com.savoo.scclient.data.model.GeniusAnnotation>>,
    onRequestLyricsAnnotations: () -> Unit,
    timedComments: List<TrackComment>,
    commentsEnabled: Boolean,
    commentsRate: TimedCommentsRate,
    currentUserId: Long?,
    onDeleteComment: (TrackComment) -> Unit,
    canComment: Boolean,
    onSubmitComment: suspend (String, Long) -> TrackComment?,
    activeLyricsLine: Int,
    lyricsSync: LyricsSyncState,
    onLyricsSyncAction: (LyricsSyncAction) -> Unit,
    onForceLyrics: (LyricsSource) -> Unit,
    onDismiss: () -> Unit,
    onTogglePlay: () -> Unit,
    onScrubStart: () -> Unit,
    onScrub: (Long) -> Unit,
    onSeek: (Long) -> Unit,
    onToggleFavorite: () -> Unit,
    onSaveForOffline: () -> Unit,
    onRemoveFromOffline: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onArtistClick: (Long) -> Unit = {},
    onExcludeArtist: () -> Unit = {},
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val sheetScope = rememberCoroutineScope()
    val collapseWithAnimation: () -> Unit = { sheetScope.launch { sheetState.hide(); onDismiss() } }
    val pixelPalette = rememberPixelPalette(glowColor, backgroundMode == AppBackgroundMode.PLAYER_ONLY)
    val classicPalette = rememberPlayerPalette()
    val isPixel = playerStyle == PlayerStyle.PIXEL

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        sheetMaxWidth = Dp.Unspecified,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        containerColor = if (isPixel) pixelPalette.background else classicPalette.bg,
        dragHandle = null,
    ) {
        if (!isPixel) {
            ClassicPlayerContent(
                controller = controller,
                state = state,
                isFavorite = isFavorite,
                isOffline = isOffline,
                isSavingOffline = isSavingOffline,
                isMixPlaying = isMixPlaying,
                onShare = onShare,
                pulse = pulse,
                glowColor = glowColor,
                seekBarStyle = seekBarStyle,
                waveform = waveform,
                backgroundStyle = backgroundStyle,
                artworkShape = artworkShape,
                artworkRingEnabled = artworkRingEnabled,
                artworkScale = artworkScale,
                lyrics = lyrics,
                lyricsAnnotations = lyricsAnnotations,
                onRequestLyricsAnnotations = onRequestLyricsAnnotations,
                timedComments = timedComments,
                commentsEnabled = commentsEnabled,
                commentsRate = commentsRate,
                currentUserId = currentUserId,
                onDeleteComment = onDeleteComment,
                canComment = canComment,
                onSubmitComment = onSubmitComment,
                activeLyricsLine = activeLyricsLine,
                lyricsSync = lyricsSync,
                onLyricsSyncAction = onLyricsSyncAction,
                onForceLyrics = onForceLyrics,
                onCollapse = collapseWithAnimation,
                onTogglePlay = onTogglePlay,
                onScrubStart = onScrubStart,
                onScrub = onScrub,
                onSeek = onSeek,
                onToggleFavorite = onToggleFavorite,
                onSaveForOffline = onSaveForOffline,
                onRemoveFromOffline = onRemoveFromOffline,
                onNext = onNext,
                onPrev = onPrev,
                onToggleShuffle = onToggleShuffle,
                onCycleRepeat = onCycleRepeat,
                onArtistClick = onArtistClick,
                onExcludeArtist = onExcludeArtist,
            )
            return@ModalBottomSheet
        }
        PixelPlayerContent(
            controller = controller,
            state = state,
            isFavorite = isFavorite,
            isOffline = isOffline,
            isSavingOffline = isSavingOffline,
            isMixPlaying = isMixPlaying,
            onShare = onShare,
            pulse = pulse,
            palette = pixelPalette,
            seekBarStyle = seekBarStyle,
            waveform = waveform,
            glowColor = glowColor,
            showGlow = pixelGlowEnabled,
            artworkShape = artworkShape,
            artworkRingEnabled = artworkRingEnabled,
            artworkScale = artworkScale,
            showCustomizeHint = showCustomizeHint,
            onDismissCustomizeHint = onDismissCustomizeHint,
            lyrics = lyrics,
            lyricsAnnotations = lyricsAnnotations,
            onRequestLyricsAnnotations = onRequestLyricsAnnotations,
            timedComments = timedComments,
            commentsEnabled = commentsEnabled,
            commentsRate = commentsRate,
            currentUserId = currentUserId,
            onDeleteComment = onDeleteComment,
            canComment = canComment,
            onSubmitComment = onSubmitComment,
            activeLyricsLine = activeLyricsLine,
            lyricsSync = lyricsSync,
            onLyricsSyncAction = onLyricsSyncAction,
            onForceLyrics = onForceLyrics,
            onCollapse = collapseWithAnimation,
            onTogglePlay = onTogglePlay,
            onScrubStart = onScrubStart,
            onScrub = onScrub,
            onSeek = onSeek,
            onToggleFavorite = onToggleFavorite,
            onSaveForOffline = onSaveForOffline,
            onRemoveFromOffline = onRemoveFromOffline,
            onNext = onNext,
            onPrev = onPrev,
            onToggleShuffle = onToggleShuffle,
            onCycleRepeat = onCycleRepeat,
            onArtistClick = onArtistClick,
            onExcludeArtist = onExcludeArtist,
        )
    }
}

private val PlayButtonShape = RoundedCornerShape(16.dp)

private val PlayerDarkBg = Color(0xFF17181A)
private val PlayerCardDim = Color(0xFF232420)
private val PlayerOnDark = Color(0xFFF5F3E7)
private val PlayerOnDarkMuted = Color(0xFFAFAEA2)

// The main play button always sits on top of `accent`, which is itself blended heavily toward
// white (see FullPlayerContent), so its content stays dark regardless of light/dark theme.
private val PlayerAccentInk = Color(0xFF17181A)

private data class PlayerPalette(val bg: Color, val card: Color, val on: Color, val onMuted: Color)

// The big player uses a bespoke dark palette (not tied to the seed/dynamic color theme) for its
// dark-mode look, but in light mode it should just match every other surface in the app - so the
// light variant pulls straight from MaterialTheme instead of a second hand-picked palette.
// `background`'s luminance mirrors the app's light/dark setting exactly (see Theme.kt's
// buildDarkScheme/buildLightScheme/buildSeedScheme), so it's a reliable signal here without
// threading the dark/light flag through every composable in this file.
@Composable
private fun rememberPlayerPalette(): PlayerPalette {
    val scheme = MaterialTheme.colorScheme
    val isLight = scheme.background.luminance() > 0.5f
    return if (isLight) {
        PlayerPalette(scheme.background, scheme.surfaceContainerHigh, scheme.onSurface, scheme.onSurfaceVariant)
    } else {
        PlayerPalette(PlayerDarkBg, PlayerCardDim, PlayerOnDark, PlayerOnDarkMuted)
    }
}

// Swallows whatever scroll the lyrics list itself didn't use, so it never reaches the bottom sheet's
// own nested-scroll connection - otherwise scrolling past the first line drags the whole player closed.
internal val sheetDragGuard = object : NestedScrollConnection {
    override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource) = available
    override suspend fun onPostFling(consumed: Velocity, available: Velocity) = available
}

private val PixelPillShape = RoundedCornerShape(28.dp)

private data class PixelPalette(
    val background: Color,
    val surface: Color,
    val accent: Color,
    val accentInk: Color,
    val onBackground: Color,
    val onBackgroundMuted: Color,
    val scheme: ColorScheme,
)

// Every color here is derived from the current track's extracted artwork color (glowColor) - a
// flat, deeply-toned background with lighter translucent surfaces and an even lighter accent for
// the play button, matching PixelPlayer's per-track color wash instead of a fixed dark/light theme.
// Reads straight from the app's own colour scheme instead of deriving a second palette from the
// artwork: with the Pixel style the scheme is already artwork-tinted, so the player and the rest of
// the app are literally the same colours and follow light/dark together.
@Composable
private fun rememberPixelPalette(glowColor: Color?, artworkOnly: Boolean): PixelPalette {
    // In every mode but PLAYER_ONLY the app scheme is already what the player should look like, so it
    // is read as-is; PLAYER_ONLY builds the same artwork scheme just for this screen and animates it
    // itself, since the app theme around it stays neutral.
    val artworkScheme = if (artworkOnly && glowColor != null) buildPixelScheme(glowColor) else null
    val spec = tween<Color>(1400, easing = FastOutSlowInEasing)
    val scheme = if (artworkScheme != null) {
        artworkScheme.copy(
            background = animateColorAsState(artworkScheme.background, spec, label = "playerOnlyBg").value,
            surfaceContainerHigh = animateColorAsState(artworkScheme.surfaceContainerHigh, spec, label = "playerOnlySurface").value,
            primary = animateColorAsState(artworkScheme.primary, spec, label = "playerOnlyAccent").value,
        )
    } else {
        MaterialTheme.colorScheme
    }
    return PixelPalette(
        background = scheme.background,
        surface = scheme.surfaceContainerHigh,
        accent = scheme.primary,
        accentInk = scheme.onPrimary,
        onBackground = scheme.onSurface,
        onBackgroundMuted = scheme.onSurfaceVariant,
        scheme = scheme,
    )
}

private fun Color.tone(amount: Float, towards: Color): Color = lerp(this, towards, amount)

@Composable
private fun PixelArtwork(
    artworkUrl: String?,
    artworkSeed: Any?,
    progress: Float,
    palette: PixelPalette,
    slideOffsetX: androidx.compose.animation.core.Animatable<Float, androidx.compose.animation.core.AnimationVector1D>,
    glowColor: Color?,
    showGlow: Boolean,
    isPlaying: Boolean,
    artworkShape: ArtworkShape,
    artworkRingEnabled: Boolean,
    modifier: Modifier = Modifier,
    pulse: () -> Float = { 0f },
) {
    val shape = rememberArtworkShape(artworkShape)
    val ringColor = palette.accent
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(300, easing = LinearEasing),
        label = "artworkRingProgress",
    )

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val artSize = maxWidth
        val ringGap = 14.dp
        val ringStroke = 4.dp
        val ringSize = artSize + ringGap * 2 + ringStroke
        Box(modifier = Modifier.size(artSize), contentAlignment = Alignment.Center) {
            if (showGlow) {
                OrbGlow(glowColor = glowColor, isPlaying = isPlaying, orbSize = artSize * 1.1f, pulse = pulse)
            }
            TrackArtwork(
                artworkUrl = artworkUrl,
                contentDescription = null,
                seed = artworkSeed,
                animated = true,
                shape = shape,
                modifier = Modifier
                    .fillMaxSize()
                    .offset { IntOffset(slideOffsetX.value.roundToInt(), 0) },
            )
            if (artworkRingEnabled) {
                Box(
                    modifier = Modifier
                        .requiredSize(ringSize)
                        .artworkProgressRing(shape, { animatedProgress }, ringColor, ringStroke),
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun MiniPlayerRow(
    track: com.savoo.scclient.data.model.Track,
    state: PlaybackState,
    isFavorite: Boolean,
    onExpand: () -> Unit,
    onTogglePlay: () -> Unit,
    onToggleFavorite: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
) {
    val haptics = rememberHaptics()
    var heartAnimating by remember { mutableStateOf(false) }
    val heartScale by animateFloatAsState(
        targetValue = if (heartAnimating) 1.4f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessHigh),
        label = "miniHeart",
        finishedListener = { heartAnimating = false }
    )

    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        targetValue = if (isPressed) 0.98f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessHigh),
        label = "miniPlayerPress",
    )

    val playInteractionSource = remember { MutableInteractionSource() }
    val isPlayPressed by playInteractionSource.collectIsPressedAsState()
    val playScale by animateFloatAsState(
        targetValue = if (isPlayPressed) 0.88f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessHigh),
        label = "miniPlayButtonScale",
    )

    val progress = if (state.durationMs > 0) {
        (state.positionMs.toFloat() / state.durationMs.toFloat()).coerceIn(0f, 1f)
    } else 0f
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(300, easing = LinearEasing),
        label = "miniPlayerProgress",
    )

    Column(
        modifier = Modifier
            .scale(pressScale)
            .clickable(interactionSource = interactionSource, indication = null) { onExpand() },
    ) {
        Row(
            modifier = Modifier.padding(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            TrackArtwork(
                artworkUrl = track.artworkUrl,
                contentDescription = null,
                seed = track.title,
                shape = CircleShape,
                modifier = Modifier.size(40.dp),
            )
            Column(modifier = Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(
                    track.title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    if (state.isRetryingNetwork) stringResource(R.string.network_retrying) else track.user.username,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (state.isRetryingNetwork) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            IconButton(onClick = { onPrev() }, modifier = Modifier.size(48.dp), enabled = state.hasPrev || state.positionMs > 0L) {
                Icon(
                    Icons.Filled.SkipPrevious,
                    contentDescription = stringResource(R.string.player_previous),
                    tint = MaterialTheme.colorScheme.onSurface.copy(alpha = if (state.hasPrev || state.positionMs > 0L) 1f else 0.38f),
                    modifier = Modifier.size(20.dp),
                )
            }
            Surface(
                onClick = { onTogglePlay() },
                interactionSource = playInteractionSource,
                shape = PlayButtonShape,
                color = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier
                    .padding(horizontal = 4.dp)
                    .size(48.dp)
                    .scale(playScale),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    if (state.isBuffering) {
                        LoadingIndicator(
                            modifier = Modifier.size(20.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                        )
                    } else {
                        Icon(
                            if (state.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = stringResource(if (state.isPlaying) R.string.player_pause else R.string.player_play),
                            modifier = Modifier.size(24.dp),
                        )
                    }
                }
            }
            IconButton(onClick = { onNext() }, modifier = Modifier.size(48.dp), enabled = state.hasNext) {
                Icon(
                    Icons.Filled.SkipNext,
                    contentDescription = stringResource(R.string.player_next),
                    tint = MaterialTheme.colorScheme.onSurface.copy(alpha = if (state.hasNext) 1f else 0.38f),
                    modifier = Modifier.size(20.dp),
                )
            }
            IconButton(onClick = { haptics.like(); heartAnimating = true; onToggleFavorite() }, modifier = Modifier.size(48.dp)) {
                Icon(
                    if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = stringResource(R.string.player_favorite),
                    tint = if (isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.scale(heartScale).size(20.dp),
                )
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 18.dp, end = 18.dp, top = 4.dp, bottom = 5.dp)
                .height(3.dp)
                .clip(RoundedCornerShape(50))
                .background(MaterialTheme.colorScheme.surfaceContainerHighest),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(animatedProgress)
                    .clip(RoundedCornerShape(50))
                    .background(MaterialTheme.colorScheme.primary),
            )
        }
    }
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class)
@androidx.annotation.OptIn(UnstableApi::class)
@Composable
private fun PixelPlayerContent(
    controller: PlayerController,
    state: PlaybackState,
    isFavorite: Boolean,
    isOffline: Boolean,
    isSavingOffline: Boolean,
    isMixPlaying: Boolean,
    onShare: () -> Unit,
    pulse: () -> Float,
    palette: PixelPalette,
    seekBarStyle: SeekBarStyle,
    waveform: FloatArray?,
    glowColor: Color?,
    showGlow: Boolean,
    artworkShape: ArtworkShape,
    artworkRingEnabled: Boolean,
    artworkScale: Float,
    showCustomizeHint: Boolean = false,
    onDismissCustomizeHint: () -> Unit = {},
    lyrics: LyricsResult?,
    lyricsAnnotations: Map<Int, List<com.savoo.scclient.data.model.GeniusAnnotation>>,
    onRequestLyricsAnnotations: () -> Unit,
    timedComments: List<TrackComment>,
    commentsEnabled: Boolean,
    commentsRate: TimedCommentsRate,
    currentUserId: Long?,
    onDeleteComment: (TrackComment) -> Unit,
    canComment: Boolean,
    onSubmitComment: suspend (String, Long) -> TrackComment?,
    activeLyricsLine: Int,
    lyricsSync: LyricsSyncState,
    onLyricsSyncAction: (LyricsSyncAction) -> Unit,
    onForceLyrics: (LyricsSource) -> Unit,
    onCollapse: () -> Unit,
    onTogglePlay: () -> Unit,
    onScrubStart: () -> Unit,
    onScrub: (Long) -> Unit,
    onSeek: (Long) -> Unit,
    onToggleFavorite: () -> Unit,
    onSaveForOffline: () -> Unit,
    onRemoveFromOffline: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onArtistClick: (Long) -> Unit = {},
    onExcludeArtist: () -> Unit = {},
) {
    val context = LocalContext.current
    val accent = palette.accent
    val haptics = rememberHaptics()
    var showLyrics by rememberSaveable { mutableStateOf(false) }
    var showComments by remember { mutableStateOf(false) }
    var showLyricsSourceMenu by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var panel by remember { mutableStateOf<PixelPanel?>(null) }
    var lastPanel by remember { mutableStateOf(PixelPanel.QUEUE) }
    panel?.let { lastPanel = it }
    var showOverflowMenu by remember { mutableStateOf(false) }
    var showAddToPlaylist by remember { mutableStateOf(false) }
    if (showAddToPlaylist) {
        state.currentTrack?.let { track ->
            AddToPlaylistSheet(tracks = listOf(track), onDismiss = { showAddToPlaylist = false })
        }
    }
    val sleepTimerRemainingMs by controller.sleepTimerRemainingMs.collectAsState()
    val sleepAfterCurrentTrack by controller.sleepAfterCurrentTrack.collectAsState()
    val sleepTimerActive = sleepTimerRemainingMs != null || sleepAfterCurrentTrack
    var isDragging by remember { mutableStateOf(false) }
    var dragPosition by remember { mutableFloatStateOf(0f) }
    var lastScrubDetent by remember { mutableIntStateOf(-1) }
    var heartAnimating by remember { mutableStateOf(false) }
    val heartScale by animateFloatAsState(
        targetValue = if (heartAnimating) 1.4f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessHigh),
        label = "heartFull",
        finishedListener = { heartAnimating = false }
    )
    val playScale by animateFloatAsState(
        targetValue = if (state.isPlaying) 1f else 0.94f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMedium),
        label = "playFull"
    )

    val commentPositionMs = if (isDragging) dragPosition.toLong() else state.positionMs
    var pinnedComment by remember { mutableStateOf<TrackComment?>(null) }
    var infoMessage by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(pinnedComment) {
        if (pinnedComment != null) {
            kotlinx.coroutines.delay(4_000)
            pinnedComment = null
        }
    }
    val activeComment = rememberVisibleComment(timedComments, commentPositionMs, state.durationMs, commentsRate, pinnedComment)

    if (showComments) {
        TimedCommentsSheet(
            comments = timedComments,
            positionMs = commentPositionMs,
            accent = accent,
            canComment = canComment,
            currentUserId = currentUserId,
            initialHighlightId = activeComment?.id,
            onSubmit = onSubmitComment,
            onSelect = { comment ->
                pinnedComment = comment
                comment.timestampMs?.let(onSeek)
            },
            onPosted = { comment -> pinnedComment = comment },
            onDelete = onDeleteComment,
            onDismiss = { showComments = false },
            onUserClick = { id -> showComments = false; onArtistClick(id) },
        )
    }

    var prevTrackId by remember { mutableStateOf(state.currentTrack?.id) }
    val slideOffset = remember { androidx.compose.animation.core.Animatable(0f) }

    LaunchedEffect(Unit) {
        snapshotFlow { state.currentTrack?.id }
            .distinctUntilChanged()
            .collect { newId ->
                if (prevTrackId != null && newId != prevTrackId) {
                    val dir = if (newId!! > (prevTrackId ?: 0)) 1 else -1
                    slideOffset.snapTo(dir * 300f)
                    slideOffset.animateTo(
                        0f,
                        spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessMediumLow,
                        )
                    )
                }
                prevTrackId = newId
            }
    }

    val playerGlass = remember { HazeState() }
    val glassOn = LocalLiquidGlass.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.92f)
            .navigationBarsPadding(),
    ) {
    PlayerInfoBanner(
        message = infoMessage,
        onHide = { infoMessage = null },
        modifier = Modifier.align(Alignment.TopCenter).zIndex(1f).padding(top = 8.dp),
    )
    AdaptivePlayerLayout(
        showLyrics = showLyrics,
        modifier = Modifier.fillMaxSize().then(if (glassOn) Modifier.background(palette.background).haze(playerGlass) else Modifier),
        lyrics = {
            PlayerLyricsScreen(
                backgroundColor = palette.background,
                onClose = { showLyrics = false },
                result = lyrics,
                annotations = lyricsAnnotations,
                onRequestAnnotations = onRequestLyricsAnnotations,
                activeIndex = activeLyricsLine,
                onSeek = onSeek,
                sync = lyricsSync,
                onSyncAction = onLyricsSyncAction,
                accent = palette.accent,
                onColor = palette.onBackground,
                mutedColor = palette.onBackgroundMuted,
                surfaceColor = palette.surface,
                track = state.currentTrack,
                positionMs = state.positionMs,
                durationMs = state.durationMs,
                isPlaying = state.isPlaying,
                onTogglePlay = onTogglePlay,
                onNext = onNext,
                onPrev = onPrev,
            )
        },
        lyricsInline = {
            LyricsView(
                result = lyrics,
                annotations = lyricsAnnotations,
                onRequestAnnotations = onRequestLyricsAnnotations,
                activeIndex = activeLyricsLine,
                onSeek = onSeek,
                sync = lyricsSync,
                onSyncAction = onLyricsSyncAction,
                accent = palette.accent,
                onColor = palette.onBackground,
                mutedColor = palette.onBackgroundMuted,
                surfaceColor = palette.surface,
                track = state.currentTrack,
                positionMs = state.positionMs,
                isPlaying = state.isPlaying,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 14.dp)
                    .nestedScroll(sheetDragGuard),
            )
        },
        header = { compact, _ ->
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            PixelIconButton(
                icon = Icons.Filled.KeyboardArrowDown,
                contentDescription = stringResource(R.string.player_collapse),
                onClick = { onCollapse() },
                tint = palette.onBackground,
                background = palette.surface,
                iconSize = 24.dp,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (isSavingOffline) {
                    Box(modifier = Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                        LoadingIndicator(modifier = Modifier.size(20.dp), color = accent)
                    }
                } else if (isOffline) {
                    ConfirmOfflineRemoval(onRemove = onRemoveFromOffline) { armed, onPress, bounce ->
                        PixelIconButton(
                            icon = if (armed) Icons.Filled.Delete else Icons.Filled.CloudDone,
                            contentDescription = stringResource(R.string.player_saved_offline),
                            onClick = onPress,
                            tint = if (armed) MaterialTheme.colorScheme.error else accent,
                            background = palette.surface,
                            modifier = bounce,
                        )
                    }
                } else {
                    PixelIconButton(
                        icon = Icons.Filled.CloudDownload,
                        contentDescription = stringResource(R.string.player_save_offline),
                        onClick = { onSaveForOffline() },
                        tint = palette.onBackground,
                        background = palette.surface,
                    )
                }
                Box {
                    PixelIconButton(
                        icon = Icons.Filled.Lyrics,
                        contentDescription = stringResource(R.string.player_lyrics),
                        onClick = { showLyrics = !showLyrics },
                        onLongClick = { haptics.longPress(); showLyricsSourceMenu = true },
                        tint = if (showLyrics) accent else palette.onBackground,
                        background = palette.surface,
                    )
                    LyricsSourceMenu(
                        expanded = showLyricsSourceMenu,
                        onDismiss = { showLyricsSourceMenu = false },
                        onPick = { source -> onForceLyrics(source); showLyrics = true },
                    )
                }
                PixelIconButton(
                    icon = Icons.Filled.MoreVert,
                    contentDescription = stringResource(R.string.player_more_options),
                    onClick = { showOverflowMenu = !showOverflowMenu },
                    tint = if (sleepTimerActive) accent else palette.onBackground,
                    background = palette.surface,
                )
            }
        }

        AnimatedVisibility(
            visible = showCustomizeHint && !compact,
            enter = fadeIn(spring(stiffness = Spring.StiffnessMedium)),
            exit = fadeOut(spring(stiffness = Spring.StiffnessMedium)),
        ) {
            Surface(
                onClick = { onDismissCustomizeHint() },
                shape = RoundedCornerShape(20.dp),
                color = palette.surface,
                contentColor = palette.onBackground,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                ) {
                    Icon(
                        Icons.Filled.Palette,
                        contentDescription = null,
                        tint = palette.accent,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        stringResource(R.string.player_customize_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.onBackgroundMuted,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        stringResource(R.string.track_dialog_ok),
                        style = MaterialTheme.typography.labelLarge,
                        color = palette.accent,
                    )
                }
            }
        }

        },
        middle = { compact, _ ->
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    BoxWithConstraints(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(bottom = if (compact) 4.dp else 12.dp),
                    ) {
                        val artSize = ((minOf(maxWidth, maxHeight) - 20.dp) * artworkScale).coerceAtLeast(0.dp)
                        if (VINYL_PLAYER_ENABLED) {
                            VinylTurntable(
                                artworkUrl = state.currentTrack?.artworkUrl,
                                artworkSeed = state.currentTrack?.title,
                                isPlaying = state.isPlaying,
                                rate = state.playbackSpeed * state.soundMode.rate,
                                positionMs = state.positionMs,
                                durationMs = state.durationMs,
                                onSeek = { controller.seekTo(it) },
                                onScratchStart = { controller.beginScratch(it) },
                                onScratchSpeed = { controller.scratchSpeed(it) },
                                onScratchEnd = { position, seek -> controller.endScratch(position, seek) },
                                onPrepareScratch = { controller.prepareScratch() },
                                modifier = Modifier
                                    .requiredSize(artSize)
                                    .align(Alignment.BottomCenter)
                                    .offset { IntOffset(slideOffset.value.roundToInt(), 0) },
                            )
                        } else {
                            PixelArtwork(
                                artworkUrl = state.currentTrack?.artworkUrl,
                                artworkSeed = state.currentTrack?.title,
                                progress = if (state.durationMs > 0) {
                                    ((if (isDragging) dragPosition else state.positionMs.toFloat()) / state.durationMs.toFloat()).coerceIn(0f, 1f)
                                } else 0f,
                                palette = palette,
                                slideOffsetX = slideOffset,
                                glowColor = glowColor,
                                showGlow = showGlow,
                                artworkShape = artworkShape,
                                artworkRingEnabled = artworkRingEnabled,
                                isPlaying = state.isPlaying,
                                pulse = pulse,
                                modifier = Modifier
                                    .requiredSize(artSize)
                                    .align(Alignment.BottomCenter),
                            )
                        }
                    }

                    Spacer(Modifier.height(if (compact) 4.dp else 16.dp))

                    if (!compact || isMixPlaying) state.currentTrack?.let { track ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .offset { IntOffset(slideOffset.value.roundToInt(), 0) },
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = stringResource(R.string.player_playing_from, playingFromSource(state.queueTag, track.user.username)),
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.onBackgroundMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            if (isMixPlaying) {
                                Spacer(Modifier.width(6.dp))
                                Surface(
                                    onClick = { onExcludeArtist() },
                                    shape = RoundedCornerShape(50),
                                    color = palette.surface,
                                    contentColor = palette.onBackgroundMuted,
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    ) {
                                        Icon(
                                            Icons.Filled.PersonOff,
                                            contentDescription = null,
                                            modifier = Modifier.size(13.dp),
                                        )
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            stringResource(R.string.player_exclude_artist_short),
                                            style = MaterialTheme.typography.labelSmall,
                                        )
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(9.dp))
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .offset { IntOffset(slideOffset.value.roundToInt(), 0) },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        state.currentTrack?.let { track ->
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Text(
                                    track.title,
                                    style = (if (compact) MaterialTheme.typography.titleLarge else MaterialTheme.typography.headlineMedium).copy(fontWeight = FontWeight.ExtraBold),
                                    maxLines = if (compact) 1 else 2,
                                    overflow = TextOverflow.Ellipsis,
                                    textAlign = TextAlign.Center,
                                    color = palette.onBackground,
                                )
                                Text(
                                    track.user.username,
                                    style = if (compact) MaterialTheme.typography.bodyMedium else MaterialTheme.typography.titleMedium,
                                    color = palette.onBackgroundMuted,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier
                                        .padding(top = if (compact) 4.dp else 7.dp)
                                        .clickable(
                                            interactionSource = remember { MutableInteractionSource() },
                                            indication = null,
                                        ) { onArtistClick(track.user.id) },
                                )
                            }
                        }
                    }
                }
        },
        controls = { compact, horizontal ->
        AdaptivePlayerControls(
            horizontal = horizontal,
            seekSpacing = if (compact) 8.dp else 18.dp,
            actionSpacing = if (compact) 8.dp else 14.dp,
            seek = {
            val seekValue = if (isDragging) dragPosition else state.positionMs.toFloat()
            val scrubLevels = remember(waveform) { waveformLevels(waveform, SCRUB_DETENTS) }
            val onSeekValueChange: (Float) -> Unit = { value ->
                val detent = scrubDetent(value, state.durationMs)
                if (!isDragging) {
                    haptics.seekGrab()
                    lastScrubDetent = detent
                    onScrubStart()
                } else if (detent != lastScrubDetent) {
                    haptics.scrub(if (waveform == null) SCRUB_FALLBACK_LEVEL else scrubLevels[detent])
                    lastScrubDetent = detent
                }
                dragPosition = value
                isDragging = true
                onScrub(value.roundToLong())
            }
            val onSeekValueChangeFinished: () -> Unit = {
                haptics.seekRelease()
                onSeek(dragPosition.roundToLong())
                isDragging = false
            }
            val seekValueRange = 0f..(state.durationMs.coerceAtLeast(1L)).toFloat()
            val seekColors = SliderDefaults.colors(
                thumbColor = accent,
                activeTrackColor = accent,
                inactiveTrackColor = palette.onBackgroundMuted.copy(alpha = 0.25f),
            )
            val markerColor = palette.onBackgroundMuted.copy(alpha = 0.5f)

            TimedCommentChip(
                comment = activeComment,
                enabled = commentsEnabled,
                accent = accent,
                onColor = palette.onBackground,
                surfaceColor = palette.surface,
                highlighted = pinnedComment != null && pinnedComment?.id == activeComment?.id,
                onClick = { showComments = true },
                modifier = Modifier.padding(top = 12.dp, bottom = 4.dp),
            )

            AdaptivePlayerSeek(
                horizontal = horizontal,
                elapsed = formatTime(if (isDragging) dragPosition.toLong() else state.positionMs),
                duration = formatTime(state.durationMs),
                color = palette.onBackgroundMuted,
            ) {
            if (seekBarStyle == SeekBarStyle.WAVEFORM) {
                WaveformSeekSlider(
                    value = seekValue,
                    onValueChange = onSeekValueChange,
                    onValueChangeFinished = onSeekValueChangeFinished,
                    valueRange = seekValueRange,
                    samples = waveform,
                    activeColor = accent,
                    inactiveColor = palette.onBackgroundMuted.copy(alpha = 0.25f),
                    isDragging = isDragging,
                    modifier = Modifier.loopRegion(
                        loop = state.loop,
                        durationMs = state.durationMs,
                        color = accent,
                        trackInset = 2.dp,
                    ).timedCommentMarkers(
                        comments = timedComments,
                        durationMs = state.durationMs,
                        activeId = activeComment?.id,
                        color = markerColor,
                        activeColor = accent,
                        trackInset = 2.dp,
                        lift = 24.dp,
                    ),
                )
            } else if (seekBarStyle == SeekBarStyle.WAVY) {
                Slider(
                    value = seekValue,
                    onValueChange = onSeekValueChange,
                    onValueChangeFinished = onSeekValueChangeFinished,
                    valueRange = seekValueRange,
                    colors = seekColors,
                    modifier = Modifier.loopRegion(
                        loop = state.loop,
                        durationMs = state.durationMs,
                        color = accent,
                        trackInset = 8.dp,
                    ).timedCommentMarkers(
                        comments = timedComments,
                        durationMs = state.durationMs,
                        activeId = activeComment?.id,
                        color = markerColor,
                        activeColor = accent,
                        trackInset = 8.dp,
                    ),
                    track = { sliderState ->
                        WavySeekTrack(
                            sliderState = sliderState,
                            activeColor = accent,
                            inactiveColor = palette.onBackgroundMuted.copy(alpha = 0.25f),
                            isDragging = isDragging,
                        )
                    },
                    thumb = {
                        val thumbScale by animateFloatAsState(
                            targetValue = if (isDragging) 1.3f else 1f,
                            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
                            label = "wavySeekThumbScale",
                        )
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .scale(thumbScale)
                                .background(accent, CircleShape),
                        )
                    },
                )
            } else {
                Slider(
                    value = seekValue,
                    onValueChange = onSeekValueChange,
                    onValueChangeFinished = onSeekValueChangeFinished,
                    valueRange = seekValueRange,
                    colors = seekColors,
                    modifier = Modifier.loopRegion(
                        loop = state.loop,
                        durationMs = state.durationMs,
                        color = accent,
                        trackInset = 10.dp,
                    ).timedCommentMarkers(
                        comments = timedComments,
                        durationMs = state.durationMs,
                        activeId = activeComment?.id,
                        color = markerColor,
                        activeColor = accent,
                        trackInset = 10.dp,
                    ),
                )
            }
            }

            },
            primary = {

            val prevSource = remember { MutableInteractionSource() }
            val playSource = remember { MutableInteractionSource() }
            val nextSource = remember { MutableInteractionSource() }
            val prevPressed by prevSource.collectIsPressedAsState()
            val playPressed by playSource.collectIsPressedAsState()
            val nextPressed by nextSource.collectIsPressedAsState()
            // Held button eats width from its neighbours instead of scaling, so the row stays the same
            // height and only stretches sideways.
            val widthSpring = spring<Float>(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMedium)
            fun pillWeight(pressed: Boolean, anyPressed: Boolean) = when {
                pressed -> 1.45f
                anyPressed -> 0.8f
                else -> 1f
            }
            val anyPressed = prevPressed || playPressed || nextPressed
            val prevWeight by animateFloatAsState(pillWeight(prevPressed, anyPressed), widthSpring, label = "prevPillWeight")
            val playWeight by animateFloatAsState(pillWeight(playPressed, anyPressed), widthSpring, label = "playPillWeight")
            val nextWeight by animateFloatAsState(pillWeight(nextPressed, anyPressed), widthSpring, label = "nextPillWeight")

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PixelPillButton(
                    icon = Icons.Filled.SkipPrevious,
                    contentDescription = stringResource(R.string.player_previous),
                    onClick = { onPrev() },
                    background = palette.surface,
                    tint = palette.onBackground,
                    interactionSource = prevSource,
                    height = if (compact) 48.dp else 72.dp,
                    modifier = Modifier.weight(prevWeight),
                )
                PixelPillButton(
                    icon = if (state.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = stringResource(if (state.isPlaying) R.string.player_pause else R.string.player_play),
                    onClick = { onTogglePlay() },
                    background = accent,
                    tint = palette.accentInk,
                    iconSize = 32.dp,
                    isLoading = state.isBuffering || state.loadingTrackId != null,
                    glassStrength = 0.15f,
                    interactionSource = playSource,
                    height = if (compact) 48.dp else 72.dp,
                    modifier = Modifier.weight(playWeight),
                )
                PixelPillButton(
                    icon = Icons.Filled.SkipNext,
                    contentDescription = stringResource(R.string.player_next),
                    onClick = { onNext() },
                    background = palette.surface,
                    tint = palette.onBackground,
                    interactionSource = nextSource,
                    height = if (compact) 48.dp else 72.dp,
                    modifier = Modifier.weight(nextWeight),
                )
            }

            },
            secondary = {

            Surface(
                shape = RoundedCornerShape(50),
                color = palette.surface,
                modifier = Modifier
                    .fillMaxWidth()
                    .glassStretch(pressScale = 1.03f, stretch = 0.06f)
                    .glassHighlight(RoundedCornerShape(50), palette.surface.luminance() < 0.5f, 0.3f),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = if (compact) 2.dp else 6.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    PixelIconButton(
                        icon = Icons.Filled.Shuffle,
                        contentDescription = stringResource(R.string.player_shuffle),
                        onClick = { onToggleShuffle() },
                        tint = if (state.shuffleEnabled) accent else palette.onBackgroundMuted,
                        background = Color.Transparent,
                        size = 48.dp,
                        iconSize = 22.dp,
                    )
                    PixelIconButton(
                        icon = if (state.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        contentDescription = stringResource(R.string.player_repeat),
                        onClick = { onCycleRepeat() },
                        tint = if (state.repeatMode != Player.REPEAT_MODE_OFF) accent else palette.onBackgroundMuted,
                        background = Color.Transparent,
                        size = 48.dp,
                        iconSize = 22.dp,
                    )
                    PixelIconButton(
                        icon = if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = stringResource(R.string.player_favorite),
                        onClick = { haptics.like(); heartAnimating = true; onToggleFavorite() },
                        tint = if (isFavorite) accent else palette.onBackgroundMuted,
                        background = Color.Transparent,
                        size = 48.dp,
                        iconSize = 22.dp,
                        iconModifier = Modifier.scale(heartScale),
                    )
                }
            }
        },
        )
        },
    )

        // Deliberately not a DropdownMenu: that opens its own popup window, and every open/close of
        // one inside a ModalBottomSheet makes the sheet re-settle - spamming the button had the whole
        // player scaling down and back like it was being dismissed. Drawn in-place, nothing moves.
        if (showOverflowMenu) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) { showOverflowMenu = false },
            )
        }
        AnimatedVisibility(
            visible = showOverflowMenu,
            enter = fadeIn(spring(stiffness = Spring.StiffnessMedium)) + scaleIn(
                initialScale = 0.8f,
                transformOrigin = TransformOrigin(1f, 0f),
                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
            ),
            exit = fadeOut(spring(stiffness = Spring.StiffnessMedium)) + scaleOut(
                targetScale = 0.85f,
                transformOrigin = TransformOrigin(1f, 0f),
                animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMedium),
            ),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 76.dp, end = 24.dp),
        ) {
            CompositionLocalProvider(LocalGlassState provides playerGlass) {
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = if (glassOn) Color.Transparent else palette.surface,
                contentColor = if (glassOn) palette.onBackground else contentColorFor(palette.surface),
                shadowElevation = if (glassOn) 0.dp else 8.dp,
                modifier = Modifier
                    .width(240.dp)
                    .glassStretch(pressScale = 1.03f, stretch = 0.05f)
                    .liquidGlass(RoundedCornerShape(28.dp), tint = palette.background, density = 0.72f, blurRadius = 24.dp),
            ) {
                Column(
                    modifier = Modifier.padding(6.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    PixelMenuItem(
                        icon = Icons.Filled.Bedtime,
                        label = stringResource(R.string.player_sleep_timer),
                        palette = palette,
                        active = sleepTimerActive,
                        onClick = { showOverflowMenu = false; panel = PixelPanel.SLEEP_TIMER },
                    )
                    PixelMenuItem(
                        icon = Icons.AutoMirrored.Filled.QueueMusic,
                        label = stringResource(R.string.player_queue),
                        palette = palette,
                        onClick = { showOverflowMenu = false; panel = PixelPanel.QUEUE },
                    )
                    if (commentsEnabled) {
                        PixelMenuItem(
                            icon = Icons.AutoMirrored.Filled.Comment,
                            label = stringResource(R.string.player_comments),
                            palette = palette,
                            onClick = { showOverflowMenu = false; showComments = true },
                        )
                    }
                    PixelMenuItem(
                        icon = Icons.Filled.AutoAwesome,
                        label = stringResource(R.string.player_more_like_this),
                        palette = palette,
                        onClick = {
                            showOverflowMenu = false
                            state.currentTrack?.let { track ->
                                moreLikeThis(scope, context, controller, track) { infoMessage = it }
                            }
                        },
                    )
                    PixelMenuItem(
                        icon = Icons.Filled.LibraryAdd,
                        label = stringResource(R.string.playlist_add_to),
                        palette = palette,
                        onClick = { showOverflowMenu = false; showAddToPlaylist = true },
                    )
                    PixelMenuItem(
                        icon = Icons.Filled.Speed,
                        label = stringResource(R.string.player_speed),
                        palette = palette,
                        active = state.playbackSpeed != 1f,
                        onClick = { showOverflowMenu = false; panel = PixelPanel.SPEED },
                    )
                    PixelMenuItem(
                        icon = Icons.Filled.GraphicEq,
                        label = stringResource(R.string.player_sound),
                        palette = palette,
                        active = state.soundMode.isActive,
                        onClick = { showOverflowMenu = false; panel = PixelPanel.SOUND },
                    )
                    PixelMenuItem(
                        icon = Icons.Filled.Loop,
                        label = stringResource(R.string.player_loop),
                        palette = palette,
                        active = state.loop != null,
                        onClick = { showOverflowMenu = false; panel = PixelPanel.LOOP },
                    )
                    PixelMenuItem(
                        icon = Icons.Filled.Share,
                        label = stringResource(R.string.player_share),
                        palette = palette,
                        onClick = {
                            showOverflowMenu = false
                            onShare()
                        },
                    )
                }
            }
            }
        }

        BackHandler(enabled = showOverflowMenu || panel != null) {
            showOverflowMenu = false
            panel = null
        }

        if (panel != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.4f))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) { panel = null },
            )
        }
        AnimatedVisibility(
            visible = panel != null,
            enter = fadeIn(spring(stiffness = Spring.StiffnessMedium)) +
                slideInVertically(
                    animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
                    initialOffsetY = { it },
                ),
            exit = fadeOut(spring(stiffness = Spring.StiffnessMedium)) +
                slideOutVertically(
                    animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMedium),
                    targetOffsetY = { it },
                ),
            modifier = Modifier.align(Alignment.BottomCenter),
        ) {
            Surface(
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                color = palette.background,
                contentColor = palette.onBackground,
                shadowElevation = 12.dp,
                modifier = Modifier.fillMaxWidth(),
            ) {
                MaterialTheme(
                    colorScheme = palette.scheme.copy(
                        background = palette.background,
                        surface = palette.surface,
                        onSurface = palette.onBackground,
                        onSurfaceVariant = palette.onBackgroundMuted,
                        primary = palette.accent,
                        onPrimary = palette.accentInk,
                    )
                ) {
                    Column(modifier = Modifier.fillMaxWidth().padding(top = 14.dp)) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .size(width = 34.dp, height = 4.dp)
                                .background(palette.onBackgroundMuted.copy(alpha = 0.4f), RoundedCornerShape(50)),
                        )
                        Spacer(Modifier.height(10.dp))
                        when (lastPanel) {
                            PixelPanel.QUEUE -> QueueContent(
                                controller = controller,
                                modifier = Modifier.fillMaxWidth().fillMaxHeight(0.8f),
                            )
                            PixelPanel.SLEEP_TIMER -> SleepTimerContent(
                                controller = controller,
                                onDismiss = { panel = null },
                            )
                            PixelPanel.SPEED -> PlaybackSpeedContent(controller = controller)
                            PixelPanel.SOUND -> SoundModeContent(controller = controller)
                            PixelPanel.LOOP -> LoopContent(controller = controller, waveform = waveform)
                        }
                    }
                }
            }
        }
    }
}

private const val ORB_PULSE = 0.12f

// Set to false to go back to the original flat cover art in the full-screen player.
private const val VINYL_PLAYER_ENABLED = true

private enum class PixelPanel { QUEUE, SLEEP_TIMER, SPEED, SOUND, LOOP }


@Composable
private fun PixelMenuItem(
    icon: ImageVector,
    label: String,
    palette: PixelPalette,
    onClick: () -> Unit,
    active: Boolean = false,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Surface(
            shape = CircleShape,
            color = if (active) palette.accent else palette.background,
            modifier = Modifier.size(38.dp),
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    icon,
                    contentDescription = null,
                    tint = if (active) palette.accentInk else palette.onBackground,
                    modifier = Modifier.size(19.dp),
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            color = palette.onBackground,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WavySeekTrack(
    sliderState: SliderState,
    activeColor: Color,
    inactiveColor: Color,
    isDragging: Boolean,
) {
    val fraction = ((sliderState.value - sliderState.valueRange.start) /
        (sliderState.valueRange.endInclusive - sliderState.valueRange.start).coerceAtLeast(0.0001f))
        .coerceIn(0f, 1f)

    val amplitudeDp by animateFloatAsState(
        targetValue = if (isDragging) 5f else 3f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "wavySeekAmplitude",
    )
    val infiniteTransition = rememberInfiniteTransition(label = "wavySeekPhase")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(animation = tween(1600, easing = LinearEasing)),
        label = "wavySeekPhaseAnim",
    )

    Canvas(modifier = Modifier.fillMaxWidth().height(20.dp)) {
        val midY = size.height / 2f
        val activeWidth = size.width * fraction
        val strokeWidthPx = 4.dp.toPx()
        val waveLengthPx = 30.dp.toPx()
        val amplitudePx = amplitudeDp.dp.toPx()

        if (activeWidth > 0f) {
            val path = Path()
            var x = 0f
            var first = true
            while (x <= activeWidth) {
                val y = midY + sin((x / waveLengthPx) * 2f * PI.toFloat() + phase) * amplitudePx
                if (first) {
                    path.moveTo(x, y)
                    first = false
                } else {
                    path.lineTo(x, y)
                }
                x += 3f
            }
            drawPath(
                path = path,
                color = activeColor,
                style = Stroke(width = strokeWidthPx, cap = StrokeCap.Round, join = StrokeJoin.Round),
            )
        }
        if (activeWidth < size.width) {
            drawLine(
                color = inactiveColor,
                start = Offset(activeWidth, midY),
                end = Offset(size.width, midY),
                strokeWidth = strokeWidthPx,
                cap = StrokeCap.Round,
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WaveformSeekSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    samples: FloatArray?,
    activeColor: Color,
    inactiveColor: Color,
    isDragging: Boolean,
    modifier: Modifier = Modifier,
) {
    Slider(
        value = value,
        onValueChange = onValueChange,
        onValueChangeFinished = onValueChangeFinished,
        valueRange = valueRange,
        modifier = modifier,
        track = { sliderState ->
            WaveformSeekTrack(
                sliderState = sliderState,
                samples = samples,
                activeColor = activeColor,
                inactiveColor = inactiveColor,
                isDragging = isDragging,
            )
        },
        thumb = {
            val thumbWidth by animateFloatAsState(
                targetValue = if (isDragging) 6f else 4f,
                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
                label = "waveformSeekThumbWidth",
            )
            Box(modifier = Modifier.size(width = 6.dp, height = 44.dp), contentAlignment = Alignment.Center) {
                Box(
                    modifier = Modifier
                        .size(width = thumbWidth.dp, height = 44.dp)
                        .background(activeColor, RoundedCornerShape(50)),
                )
            }
        },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WaveformSeekTrack(
    sliderState: SliderState,
    samples: FloatArray?,
    activeColor: Color,
    inactiveColor: Color,
    isDragging: Boolean,
) {
    val fraction = ((sliderState.value - sliderState.valueRange.start) /
        (sliderState.valueRange.endInclusive - sliderState.valueRange.start).coerceAtLeast(0.0001f))
        .coerceIn(0f, 1f)

    val boost by animateFloatAsState(
        targetValue = if (isDragging) 1.12f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "waveformSeekBoost",
    )
    val density = LocalDensity.current
    var widthPx by remember { mutableIntStateOf(0) }
    val barWidthPx = with(density) { 3.dp.toPx() }
    val gapPx = with(density) { 2.dp.toPx() }
    val barCount = ((widthPx + gapPx) / (barWidthPx + gapPx)).toInt().coerceAtLeast(1)
    val targets = remember(samples, barCount) { waveformLevels(samples, barCount) }
    val displayed = remember(barCount) { FloatArray(barCount) }
    val sweep = remember { floatArrayOf(0f) }
    var frame by remember { mutableLongStateOf(0L) }
    val hasData = samples != null

    LaunchedEffect(targets, hasData) {
        if (!hasData) sweep[0] = 0f
        var last = 0L
        while (true) {
            val now = withFrameNanos { it }
            val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
            last = now
            if (hasData) sweep[0] = (sweep[0] + dt / WAVEFORM_SWEEP_SECONDS).coerceAtMost(1f)
            val k = 1f - exp(-dt * WAVEFORM_EASE_RATE)
            var moving = hasData && sweep[0] < 1f
            for (i in displayed.indices) {
                val target = if ((i + 0.5f) / barCount <= sweep[0]) targets[i] else 0f
                val delta = target - displayed[i]
                if (abs(delta) > 0.002f) {
                    displayed[i] += delta * k
                    moving = true
                } else {
                    displayed[i] = target
                }
            }
            frame = now
            if (!moving) break
        }
    }

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(36.dp)
            .onSizeChanged { widthPx = it.width },
    ) {
        frame
        val minHeight = barWidthPx
        val count = displayed.size
        val step = (size.width - barWidthPx) / (count - 1).coerceAtLeast(1)
        val midY = size.height / 2f
        val corner = CornerRadius(barWidthPx / 2f, barWidthPx / 2f)
        fun drawBars(color: Color) {
            for (index in 0 until count) {
                val h = (minHeight + (size.height - minHeight) * displayed[index] * boost).coerceIn(minHeight, size.height)
                drawRoundRect(
                    color = color,
                    topLeft = Offset(index * step, midY - h / 2f),
                    size = Size(barWidthPx, h),
                    cornerRadius = corner,
                )
            }
        }
        val activeWidth = size.width * fraction
        clipRect(left = activeWidth) { drawBars(inactiveColor) }
        clipRect(right = activeWidth) { drawBars(activeColor) }
    }
}

internal const val SCRUB_DETENTS = 48
private const val SCRUB_FALLBACK_LEVEL = 0.35f

internal fun scrubDetent(valueMs: Float, durationMs: Long): Int =
    (valueMs / durationMs.coerceAtLeast(1L) * SCRUB_DETENTS).toInt().coerceIn(0, SCRUB_DETENTS - 1)

private const val WAVEFORM_SWEEP_SECONDS = 0.6f
private const val WAVEFORM_EASE_RATE = 10f

internal fun waveformLevels(samples: FloatArray?, barCount: Int): FloatArray {
    if (samples == null || samples.isEmpty()) return FloatArray(barCount)
    val averages = FloatArray(barCount) { index ->
        val from = index * samples.size / barCount
        val to = ((index + 1) * samples.size / barCount).coerceIn(from + 1, samples.size)
        var sum = 0f
        var known = 0
        for (i in from until to) {
            val v = samples[i]
            if (!v.isNaN()) {
                sum += v
                known++
            }
        }
        if (known == 0) Float.NaN else sum / known
    }
    val sorted = averages.filter { !it.isNaN() }.sorted()
    if (sorted.isEmpty()) return FloatArray(barCount)
    val low = sorted[(sorted.size * 0.05f).toInt().coerceIn(0, sorted.lastIndex)]
    val high = sorted.last()
    val range = (high - low).coerceAtLeast(0.0001f)
    return FloatArray(barCount) { index ->
        val value = averages[index]
        if (value.isNaN()) 0f else 0.08f + 0.92f * ((value - low) / range).coerceIn(0f, 1f).pow(1.6f)
    }
}

@Composable
private fun ExpressiveMenuItem(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    active: Boolean = false,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Surface(
            shape = CircleShape,
            color = if (active) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer,
            modifier = Modifier.size(40.dp),
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    icon,
                    contentDescription = null,
                    tint = if (active) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.size(20.dp),
                )
            }
        }
        Spacer(Modifier.width(14.dp))
        Text(
            label,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
internal fun PixelIconButton(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
    tint: Color,
    background: Color,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    iconSize: Dp = 20.dp,
    iconModifier: Modifier = Modifier,
    onLongClick: (() -> Unit)? = null,
) {
    Surface(
        shape = CircleShape,
        color = background,
        contentColor = tint,
        modifier = modifier
            .size(size)
            .then(
                if (background.alpha > 0f) Modifier.glassStretch().glassHighlight(CircleShape, background.luminance() < 0.5f)
                else Modifier
            ),
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick),
        ) {
            Icon(icon, contentDescription = contentDescription, modifier = iconModifier.size(iconSize))
        }
    }
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
internal fun PixelPillButton(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
    background: Color,
    tint: Color,
    interactionSource: MutableInteractionSource,
    modifier: Modifier = Modifier,
    height: Dp = 72.dp,
    iconSize: Dp = 26.dp,
    isLoading: Boolean = false,
    glassStrength: Float = 0.3f,
) {
    Surface(
        onClick = onClick,
        interactionSource = interactionSource,
        shape = PixelPillShape,
        color = background,
        contentColor = tint,
        modifier = modifier
            .height(height)
            .glassStretch()
            .glassHighlight(PixelPillShape, background.luminance() < 0.5f, glassStrength),
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (isLoading) {
                LoadingIndicator(modifier = Modifier.size(iconSize), color = tint)
            } else {
                Icon(icon, contentDescription = contentDescription, modifier = Modifier.size(iconSize))
            }
        }
    }
}

@Composable
internal fun LyricsSyncControls(
    state: LyricsSyncState,
    onAction: (LyricsSyncAction) -> Unit,
    mutedColor: Color,
    surfaceColor: Color,
    accent: Color,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    trailing: (@Composable () -> Unit)? = null,
) {
    val haptic = rememberHapticTick()
    val adjusted = !state.sync.isDefault
    val manuallyAdjusted = state.sync != state.automatic
    val offsetText = "%+.1fs".format(state.sync.offsetMs / 1000f)
    val driftText = stringResource(R.string.player_lyrics_drift_value, state.sync.driftMsPerMin / 1000f)

    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(surfaceColor.copy(alpha = 0.9f))
                    .clickable { onExpandedChange(!expanded) }
                    .padding(start = 10.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
            ) {
                Icon(
                    Icons.Filled.Tune,
                    contentDescription = null,
                    tint = if (manuallyAdjusted) accent else mutedColor,
                    modifier = Modifier.size(16.dp),
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = when {
                        !adjusted -> stringResource(R.string.player_lyrics_sync)
                        state.sync.driftMsPerMin == 0L -> offsetText
                        state.sync.offsetMs == 0L -> driftText
                        else -> "$offsetText · $driftText"
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = mutedColor,
                )
                Icon(
                    if (expanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                    contentDescription = null,
                    tint = mutedColor,
                    modifier = Modifier.size(18.dp),
                )
            }
            if (trailing != null) {
                Spacer(Modifier.width(8.dp))
                trailing()
            }
        }

        AnimatedVisibility(visible = expanded) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 8.dp),
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    LyricsLabeledStepper(
                        label = stringResource(R.string.player_lyrics_offset_label),
                        value = offsetText,
                        decreaseDescription = stringResource(R.string.player_lyrics_offset_later),
                        increaseDescription = stringResource(R.string.player_lyrics_offset_earlier),
                        onDecrease = { haptic(); onAction(LyricsSyncAction.AdjustOffset(-LYRICS_OFFSET_STEP_MS)) },
                        onIncrease = { haptic(); onAction(LyricsSyncAction.AdjustOffset(LYRICS_OFFSET_STEP_MS)) },
                        onReset = if (state.sync.offsetMs != state.automatic.offsetMs) ({ haptic(); onAction(LyricsSyncAction.ResetOffset) }) else null,
                        mutedColor = mutedColor,
                        surfaceColor = surfaceColor,
                    )
                    LyricsLabeledStepper(
                        label = stringResource(R.string.player_lyrics_drift_label),
                        value = driftText,
                        decreaseDescription = stringResource(R.string.player_lyrics_drift_slower),
                        increaseDescription = stringResource(R.string.player_lyrics_drift_faster),
                        onDecrease = { haptic(); onAction(LyricsSyncAction.AdjustDrift(-LYRICS_DRIFT_STEP_MS_PER_MIN)) },
                        onIncrease = { haptic(); onAction(LyricsSyncAction.AdjustDrift(LYRICS_DRIFT_STEP_MS_PER_MIN)) },
                        onReset = if (state.sync.driftMsPerMin != state.automatic.driftMsPerMin) ({ haptic(); onAction(LyricsSyncAction.ResetDrift) }) else null,
                        mutedColor = mutedColor,
                        surfaceColor = surfaceColor,
                    )
                }
            }
        }
    }
}

@Composable
private fun LyricsLabeledStepper(
    label: String,
    value: String,
    decreaseDescription: String,
    increaseDescription: String,
    onDecrease: () -> Unit,
    onIncrease: () -> Unit,
    onReset: (() -> Unit)?,
    mutedColor: Color,
    surfaceColor: Color,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = mutedColor.copy(alpha = 0.8f))
        Spacer(Modifier.height(4.dp))
        LyricsStepper(
            value = value,
            decreaseDescription = decreaseDescription,
            increaseDescription = increaseDescription,
            onDecrease = onDecrease,
            onIncrease = onIncrease,
            onReset = onReset,
            mutedColor = mutedColor,
            surfaceColor = surfaceColor,
        )
    }
}

@Composable
private fun LyricsStepper(
    value: String,
    decreaseDescription: String,
    increaseDescription: String,
    onDecrease: () -> Unit,
    onIncrease: () -> Unit,
    onReset: (() -> Unit)?,
    mutedColor: Color,
    surfaceColor: Color,
) {
    Surface(
        color = surfaceColor.copy(alpha = 0.9f),
        contentColor = mutedColor,
        shape = RoundedCornerShape(50),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
        ) {
            IconButton(onClick = onDecrease, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Filled.Remove, contentDescription = decreaseDescription, modifier = Modifier.size(18.dp))
            }
            Text(
                text = value,
                style = MaterialTheme.typography.labelMedium,
                color = mutedColor,
                modifier = Modifier
                    .padding(horizontal = 4.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        enabled = onReset != null,
                    ) { onReset?.invoke() },
            )
            IconButton(onClick = onIncrease, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Filled.Add, contentDescription = increaseDescription, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
internal fun LyricsSharePill(
    onClick: () -> Unit,
    mutedColor: Color,
    surfaceColor: Color,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(surfaceColor.copy(alpha = 0.9f))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(start = 10.dp, end = 12.dp, top = 6.dp, bottom = 6.dp),
    ) {
        Box(Modifier.size(18.dp), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Share, contentDescription = null, tint = mutedColor, modifier = Modifier.size(16.dp))
        }
        Spacer(Modifier.width(6.dp))
        Text(stringResource(R.string.lyrics_card_share), style = MaterialTheme.typography.labelMedium, color = mutedColor)
    }
}

private const val LYRICS_OFFSET_STEP_MS = 500L
private const val LYRICS_DRIFT_STEP_MS_PER_MIN = 100L

private fun moreLikeThis(
    scope: kotlinx.coroutines.CoroutineScope,
    context: android.content.Context,
    controller: PlayerController,
    track: Track,
    onMessage: (String) -> Unit,
) {
    scope.launch {
        val added = controller.queueMoreLikeThis(track)
        onMessage(
            if (added > 0) {
                context.resources.getQuantityString(R.plurals.player_more_like_this_added, added, added)
            } else {
                context.getString(R.string.player_more_like_this_empty)
            }
        )
    }
}

@Composable
private fun LyricsSourceMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    onPick: (LyricsSource) -> Unit,
) {
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
    ) {
        DropdownMenuItem(
            text = { Text(stringResource(R.string.player_lyrics_force_lrclib)) },
            onClick = { onDismiss(); onPick(LyricsSource.LRCLIB) },
        )
        DropdownMenuItem(
            text = { Text(stringResource(R.string.player_lyrics_force_genius)) },
            onClick = { onDismiss(); onPick(LyricsSource.GENIUS) },
        )
    }
}

@Composable
internal fun playingFromSource(queueTag: String?, artistName: String): String = when {
    queueTag == null -> artistName
    queueTag == "home_mix" -> stringResource(R.string.player_source_mix)
    queueTag == "favorites" -> stringResource(R.string.player_source_favorites)
    queueTag == "offline" -> stringResource(R.string.player_source_offline)
    queueTag == "recent" -> stringResource(R.string.home_section_jump_back_in)
    queueTag == "search" -> stringResource(R.string.player_source_search)
    queueTag.startsWith("artist:") -> queueTag.removePrefix("artist:")
    queueTag.startsWith("playlist:") -> queueTag.removePrefix("playlist:")
    else -> artistName
}

internal fun formatTime(ms: Long): String {
    val totalSec = ms / 1000
    val min = totalSec / 60
    val sec = totalSec % 60
    return "%d:%02d".format(min, sec)
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
@androidx.annotation.OptIn(UnstableApi::class)
@Composable
private fun ClassicPlayerContent(
    controller: PlayerController,
    state: PlaybackState,
    isFavorite: Boolean,
    isOffline: Boolean,
    isSavingOffline: Boolean,
    isMixPlaying: Boolean,
    onShare: () -> Unit,
    pulse: () -> Float,
    glowColor: Color?,
    seekBarStyle: SeekBarStyle,
    waveform: FloatArray?,
    backgroundStyle: PlayerBackgroundStyle,
    artworkShape: ArtworkShape,
    artworkRingEnabled: Boolean,
    artworkScale: Float,
    lyrics: LyricsResult?,
    lyricsAnnotations: Map<Int, List<com.savoo.scclient.data.model.GeniusAnnotation>>,
    onRequestLyricsAnnotations: () -> Unit,
    timedComments: List<TrackComment>,
    commentsEnabled: Boolean,
    commentsRate: TimedCommentsRate,
    currentUserId: Long?,
    onDeleteComment: (TrackComment) -> Unit,
    canComment: Boolean,
    onSubmitComment: suspend (String, Long) -> TrackComment?,
    activeLyricsLine: Int,
    lyricsSync: LyricsSyncState,
    onLyricsSyncAction: (LyricsSyncAction) -> Unit,
    onForceLyrics: (LyricsSource) -> Unit,
    onCollapse: () -> Unit,
    onTogglePlay: () -> Unit,
    onScrubStart: () -> Unit,
    onScrub: (Long) -> Unit,
    onSeek: (Long) -> Unit,
    onToggleFavorite: () -> Unit,
    onSaveForOffline: () -> Unit,
    onRemoveFromOffline: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onArtistClick: (Long) -> Unit = {},
    onExcludeArtist: () -> Unit = {},
) {
    val context = LocalContext.current
    val palette = rememberPlayerPalette()
    val haptics = rememberHaptics()
    var showLyrics by rememberSaveable { mutableStateOf(false) }
    var showComments by remember { mutableStateOf(false) }
    var showLyricsSourceMenu by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var showQueue by remember { mutableStateOf(false) }
    var showSleepTimer by remember { mutableStateOf(false) }
    var showSpeed by remember { mutableStateOf(false) }
    var showSound by remember { mutableStateOf(false) }
    var showLoop by remember { mutableStateOf(false) }
    var showOverflowMenu by remember { mutableStateOf(false) }
    var showAddToPlaylist by remember { mutableStateOf(false) }
    if (showAddToPlaylist) {
        state.currentTrack?.let { track ->
            AddToPlaylistSheet(tracks = listOf(track), onDismiss = { showAddToPlaylist = false })
        }
    }
    val sleepTimerRemainingMs by controller.sleepTimerRemainingMs.collectAsState()
    val sleepAfterCurrentTrack by controller.sleepAfterCurrentTrack.collectAsState()
    val sleepTimerActive = sleepTimerRemainingMs != null || sleepAfterCurrentTrack
    var isDragging by remember { mutableStateOf(false) }
    var dragPosition by remember { mutableFloatStateOf(0f) }
    var lastScrubDetent by remember { mutableIntStateOf(-1) }
    var heartAnimating by remember { mutableStateOf(false) }
    val heartScale by animateFloatAsState(
        targetValue = if (heartAnimating) 1.4f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessHigh),
        label = "heartFull",
        finishedListener = { heartAnimating = false }
    )
    val playScale by animateFloatAsState(
        targetValue = if (state.isPlaying) 1f else 0.94f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMedium),
        label = "playFull"
    )

    val themeAccent = MaterialTheme.colorScheme.primary
    val accent by animateColorAsState(
        targetValue = (glowColor ?: themeAccent).tone(0.55f, Color.White),
        animationSpec = tween(1400, easing = FastOutSlowInEasing),
        label = "playerAccent",
    )

    val commentPositionMs = if (isDragging) dragPosition.toLong() else state.positionMs
    var pinnedComment by remember { mutableStateOf<TrackComment?>(null) }
    var infoMessage by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(pinnedComment) {
        if (pinnedComment != null) {
            kotlinx.coroutines.delay(4_000)
            pinnedComment = null
        }
    }
    val activeComment = rememberVisibleComment(timedComments, commentPositionMs, state.durationMs, commentsRate, pinnedComment)

    if (showComments) {
        TimedCommentsSheet(
            comments = timedComments,
            positionMs = commentPositionMs,
            accent = accent,
            canComment = canComment,
            currentUserId = currentUserId,
            initialHighlightId = activeComment?.id,
            onSubmit = onSubmitComment,
            onSelect = { comment ->
                pinnedComment = comment
                comment.timestampMs?.let(onSeek)
            },
            onPosted = { comment -> pinnedComment = comment },
            onDelete = onDeleteComment,
            onDismiss = { showComments = false },
            onUserClick = { id -> showComments = false; onArtistClick(id) },
        )
    }

    var prevTrackId by remember { mutableStateOf(state.currentTrack?.id) }
    val slideOffset = remember { androidx.compose.animation.core.Animatable(0f) }

    LaunchedEffect(Unit) {
        snapshotFlow { state.currentTrack?.id }
            .distinctUntilChanged()
            .collect { newId ->
                if (prevTrackId != null && newId != prevTrackId) {
                    val dir = if (newId!! > (prevTrackId ?: 0)) 1 else -1
                    slideOffset.snapTo(dir * 300f)
                    slideOffset.animateTo(
                        0f,
                        spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessMediumLow,
                        )
                    )
                }
                prevTrackId = newId
            }
    }

    val libraryActions: @Composable () -> Unit = {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { haptics.like(); heartAnimating = true; onToggleFavorite() }) {
                Icon(
                    if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = stringResource(R.string.player_favorite),
                    tint = if (isFavorite) accent else palette.onMuted,
                    modifier = Modifier.scale(heartScale),
                )
            }
            if (isSavingOffline) {
                Box(modifier = Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                    LoadingIndicator(
                        modifier = Modifier.size(22.dp),
                        color = accent,
                    )
                }
            } else if (isOffline) {
                ConfirmOfflineRemoval(onRemove = onRemoveFromOffline) { armed, onPress, bounce ->
                    IconButton(onClick = onPress, modifier = bounce) {
                        Icon(
                            if (armed) Icons.Filled.Delete else Icons.Filled.CloudDone,
                            contentDescription = stringResource(R.string.player_saved_offline),
                            tint = if (armed) MaterialTheme.colorScheme.error else accent,
                            modifier = Modifier.size(22.dp),
                        )
                    }
                }
            } else {
                IconButton(onClick = { onSaveForOffline() }) {
                    Icon(
                        Icons.Filled.CloudDownload,
                        contentDescription = stringResource(R.string.player_save_offline),
                        tint = palette.onMuted,
                        modifier = Modifier.size(22.dp),
                    )
                }
            }
        }
    }

    Box(Modifier.fillMaxWidth().fillMaxHeight(0.92f).navigationBarsPadding()) {
    PlayerInfoBanner(
        message = infoMessage,
        onHide = { infoMessage = null },
        modifier = Modifier.align(Alignment.TopCenter).zIndex(1f).padding(top = 8.dp),
    )
    AdaptivePlayerLayout(
        showLyrics = showLyrics,
        modifier = Modifier.fillMaxSize(),
        lyrics = {
            PlayerLyricsScreen(
                backgroundColor = palette.bg,
                onClose = { showLyrics = false },
                result = lyrics,
                annotations = lyricsAnnotations,
                onRequestAnnotations = onRequestLyricsAnnotations,
                activeIndex = activeLyricsLine,
                onSeek = onSeek,
                sync = lyricsSync,
                onSyncAction = onLyricsSyncAction,
                accent = accent,
                onColor = palette.on,
                mutedColor = palette.onMuted,
                surfaceColor = palette.card,
                track = state.currentTrack,
                positionMs = state.positionMs,
                durationMs = state.durationMs,
                isPlaying = state.isPlaying,
                onTogglePlay = onTogglePlay,
                onNext = onNext,
                onPrev = onPrev,
            )
        },
        lyricsInline = {
            LyricsView(
                result = lyrics,
                annotations = lyricsAnnotations,
                onRequestAnnotations = onRequestLyricsAnnotations,
                activeIndex = activeLyricsLine,
                onSeek = onSeek,
                sync = lyricsSync,
                onSyncAction = onLyricsSyncAction,
                accent = accent,
                onColor = palette.on,
                mutedColor = palette.onMuted,
                surfaceColor = palette.card,
                track = state.currentTrack,
                positionMs = state.positionMs,
                isPlaying = state.isPlaying,
                modifier = Modifier
                    .fillMaxSize()
                    .nestedScroll(sheetDragGuard),
            )
        },
        header = { _, mini ->
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { onCollapse() }) {
                Icon(
                    Icons.Filled.KeyboardArrowDown,
                    contentDescription = stringResource(R.string.player_collapse),
                    modifier = Modifier.size(32.dp),
                    tint = palette.on,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (mini) libraryActions()
                Box {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .combinedClickable(
                                onClick = { showLyrics = !showLyrics },
                                onLongClick = { haptics.longPress(); showLyricsSourceMenu = true },
                            ),
                    ) {
                        Icon(
                            Icons.Filled.Lyrics,
                            contentDescription = stringResource(R.string.player_lyrics),
                            modifier = Modifier.size(24.dp),
                            tint = if (showLyrics) accent else palette.on,
                        )
                    }
                    LyricsSourceMenu(
                        expanded = showLyricsSourceMenu,
                        onDismiss = { showLyricsSourceMenu = false },
                        onPick = { source -> onForceLyrics(source); showLyrics = true },
                    )
                }
                Box {
                    IconButton(onClick = { showOverflowMenu = true }) {
                        Icon(
                            Icons.Filled.MoreVert,
                            contentDescription = stringResource(R.string.player_more_options),
                            modifier = Modifier.size(24.dp),
                            tint = if (sleepTimerActive) accent else palette.on,
                        )
                    }
                    DropdownMenu(
                        expanded = showOverflowMenu,
                        onDismissRequest = { showOverflowMenu = false },
                        shape = RoundedCornerShape(28.dp),
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                        shadowElevation = 8.dp,
                    ) {
                        Column(
                            modifier = Modifier.padding(6.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp),
                        ) {
                            ExpressiveMenuItem(
                                icon = Icons.Filled.Bedtime,
                                label = stringResource(R.string.player_sleep_timer),
                                active = sleepTimerActive,
                                onClick = { showOverflowMenu = false; showSleepTimer = true },
                            )
                            ExpressiveMenuItem(
                                icon = Icons.AutoMirrored.Filled.QueueMusic,
                                label = stringResource(R.string.player_queue),
                                onClick = { showOverflowMenu = false; showQueue = true },
                            )
                            if (commentsEnabled) {
                                ExpressiveMenuItem(
                                    icon = Icons.AutoMirrored.Filled.Comment,
                                    label = stringResource(R.string.player_comments),
                                    onClick = { showOverflowMenu = false; showComments = true },
                                )
                            }
                            ExpressiveMenuItem(
                                icon = Icons.Filled.AutoAwesome,
                                label = stringResource(R.string.player_more_like_this),
                                onClick = {
                                    showOverflowMenu = false
                                    state.currentTrack?.let { track ->
                                moreLikeThis(scope, context, controller, track) { infoMessage = it }
                            }
                                },
                            )
                            ExpressiveMenuItem(
                                icon = Icons.Filled.LibraryAdd,
                                label = stringResource(R.string.playlist_add_to),
                                onClick = { showOverflowMenu = false; showAddToPlaylist = true },
                            )
                            ExpressiveMenuItem(
                                icon = Icons.Filled.Speed,
                                label = stringResource(R.string.player_speed),
                                active = state.playbackSpeed != 1f,
                                onClick = { showOverflowMenu = false; showSpeed = true },
                            )
                            ExpressiveMenuItem(
                                icon = Icons.Filled.GraphicEq,
                                label = stringResource(R.string.player_sound),
                                active = state.soundMode.isActive,
                                onClick = { showOverflowMenu = false; showSound = true },
                            )
                            ExpressiveMenuItem(
                                icon = Icons.Filled.Loop,
                                label = stringResource(R.string.player_loop),
                                active = state.loop != null,
                                onClick = { showOverflowMenu = false; showLoop = true },
                            )
                            ExpressiveMenuItem(
                                icon = Icons.Filled.Share,
                                label = stringResource(R.string.player_share),
                                onClick = {
                                    showOverflowMenu = false
                                    onShare()
                                },
                            )
                        }
                    }
                }
            }
        }

        },
        middle = { compact, _ ->
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    BoxWithConstraints(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(bottom = if (compact) 4.dp else 20.dp),
                    ) {
                        val artSize = (minOf(maxWidth * 0.92f, maxHeight) * artworkScale).coerceAtLeast(0.dp)
                        if (VINYL_PLAYER_ENABLED) {
                            VinylTurntable(
                                artworkUrl = state.currentTrack?.artworkUrl,
                                artworkSeed = state.currentTrack?.title,
                                isPlaying = state.isPlaying,
                                rate = state.playbackSpeed * state.soundMode.rate,
                                positionMs = state.positionMs,
                                durationMs = state.durationMs,
                                onSeek = { controller.seekTo(it) },
                                onScratchStart = { controller.beginScratch(it) },
                                onScratchSpeed = { controller.scratchSpeed(it) },
                                onScratchEnd = { position, seek -> controller.endScratch(position, seek) },
                                onPrepareScratch = { controller.prepareScratch() },
                                modifier = Modifier
                                    .requiredSize(artSize)
                                    .align(Alignment.BottomCenter)
                                    .offset { IntOffset(slideOffset.value.roundToInt(), 0) },
                            )
                        } else {
                            ArtworkOrb(
                                artworkUrl = state.currentTrack?.artworkUrl,
                                artworkSeed = state.currentTrack?.title,
                                glowColor = glowColor,
                                isPlaying = state.isPlaying,
                                progress = if (state.durationMs > 0) {
                                    ((if (isDragging) dragPosition else state.positionMs.toFloat()) / state.durationMs.toFloat()).coerceIn(0f, 1f)
                                } else 0f,
                                slideOffsetX = slideOffset,
                                style = backgroundStyle,
                                artworkShape = artworkShape,
                                artworkRingEnabled = artworkRingEnabled,
                                pulse = pulse,
                                modifier = Modifier
                                    .requiredSize(artSize)
                                    .align(Alignment.BottomCenter),
                            )
                        }
                    }

                    Spacer(Modifier.height(if (compact) 4.dp else 16.dp))

                    if (!compact || isMixPlaying) state.currentTrack?.let { track ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .offset { IntOffset(slideOffset.value.roundToInt(), 0) },
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = stringResource(R.string.player_playing_from, playingFromSource(state.queueTag, track.user.username)),
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.onMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            if (isMixPlaying) {
                                Spacer(Modifier.width(6.dp))
                                Surface(
                                    onClick = { onExcludeArtist() },
                                    shape = RoundedCornerShape(50),
                                    color = palette.card,
                                    contentColor = palette.onMuted,
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    ) {
                                        Icon(
                                            Icons.Filled.PersonOff,
                                            contentDescription = null,
                                            modifier = Modifier.size(13.dp),
                                        )
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            stringResource(R.string.player_exclude_artist_short),
                                            style = MaterialTheme.typography.labelSmall,
                                        )
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .offset { IntOffset(slideOffset.value.roundToInt(), 0) },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        state.currentTrack?.let { track ->
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Text(
                                    track.title,
                                    style = (if (compact) MaterialTheme.typography.titleLarge else MaterialTheme.typography.headlineMedium).copy(fontWeight = FontWeight.ExtraBold),
                                    maxLines = if (compact) 1 else 2,
                                    overflow = TextOverflow.Ellipsis,
                                    textAlign = TextAlign.Center,
                                    color = palette.on,
                                )
                                Text(
                                    track.user.username,
                                    style = if (compact) MaterialTheme.typography.bodyMedium else MaterialTheme.typography.titleMedium,
                                    color = palette.onMuted,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier
                                        .padding(top = 4.dp)
                                        .clickable(
                                            interactionSource = remember { MutableInteractionSource() },
                                            indication = null,
                                        ) { onArtistClick(track.user.id) },
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(if (compact) 4.dp else 8.dp))

                    libraryActions()
                }
        },
        controls = { compact, horizontal ->
        AdaptivePlayerControls(
            horizontal = horizontal,
            seekSpacing = if (compact) 8.dp else 16.dp,
            actionSpacing = if (compact) 8.dp else 14.dp,
            seek = {
            val seekValue = if (isDragging) dragPosition else state.positionMs.toFloat()
            val scrubLevels = remember(waveform) { waveformLevels(waveform, SCRUB_DETENTS) }
            val onSeekValueChange: (Float) -> Unit = { value ->
                val detent = scrubDetent(value, state.durationMs)
                if (!isDragging) {
                    haptics.seekGrab()
                    lastScrubDetent = detent
                    onScrubStart()
                } else if (detent != lastScrubDetent) {
                    haptics.scrub(if (waveform == null) SCRUB_FALLBACK_LEVEL else scrubLevels[detent])
                    lastScrubDetent = detent
                }
                dragPosition = value
                isDragging = true
                onScrub(value.roundToLong())
            }
            val onSeekValueChangeFinished: () -> Unit = {
                haptics.seekRelease()
                onSeek(dragPosition.roundToLong())
                isDragging = false
            }
            val seekValueRange = 0f..(state.durationMs.coerceAtLeast(1L)).toFloat()
            val seekColors = SliderDefaults.colors(
                thumbColor = accent,
                activeTrackColor = accent,
                inactiveTrackColor = palette.onMuted.copy(alpha = 0.25f),
            )
            val markerColor = palette.onMuted.copy(alpha = 0.5f)

            TimedCommentChip(
                comment = activeComment,
                enabled = commentsEnabled,
                accent = accent,
                onColor = palette.on,
                surfaceColor = palette.card,
                highlighted = pinnedComment != null && pinnedComment?.id == activeComment?.id,
                onClick = { showComments = true },
                modifier = Modifier.padding(top = 12.dp, bottom = 4.dp),
            )

            AdaptivePlayerSeek(
                horizontal = horizontal,
                elapsed = formatTime(if (isDragging) dragPosition.toLong() else state.positionMs),
                duration = formatTime(state.durationMs),
                color = palette.onMuted,
            ) {
            if (seekBarStyle == SeekBarStyle.WAVEFORM) {
                WaveformSeekSlider(
                    value = seekValue,
                    onValueChange = onSeekValueChange,
                    onValueChangeFinished = onSeekValueChangeFinished,
                    valueRange = seekValueRange,
                    samples = waveform,
                    activeColor = accent,
                    inactiveColor = palette.onMuted.copy(alpha = 0.25f),
                    isDragging = isDragging,
                    modifier = Modifier.loopRegion(
                        loop = state.loop,
                        durationMs = state.durationMs,
                        color = accent,
                        trackInset = 2.dp,
                    ).timedCommentMarkers(
                        comments = timedComments,
                        durationMs = state.durationMs,
                        activeId = activeComment?.id,
                        color = markerColor,
                        activeColor = accent,
                        trackInset = 2.dp,
                        lift = 24.dp,
                    ),
                )
            } else if (seekBarStyle == SeekBarStyle.WAVY) {
                Slider(
                    value = seekValue,
                    onValueChange = onSeekValueChange,
                    onValueChangeFinished = onSeekValueChangeFinished,
                    valueRange = seekValueRange,
                    colors = seekColors,
                    modifier = Modifier.loopRegion(
                        loop = state.loop,
                        durationMs = state.durationMs,
                        color = accent,
                        trackInset = 8.dp,
                    ).timedCommentMarkers(
                        comments = timedComments,
                        durationMs = state.durationMs,
                        activeId = activeComment?.id,
                        color = markerColor,
                        activeColor = accent,
                        trackInset = 8.dp,
                    ),
                    track = { sliderState ->
                        WavySeekTrack(
                            sliderState = sliderState,
                            activeColor = accent,
                            inactiveColor = palette.onMuted.copy(alpha = 0.25f),
                            isDragging = isDragging,
                        )
                    },
                    thumb = {
                        val thumbScale by animateFloatAsState(
                            targetValue = if (isDragging) 1.3f else 1f,
                            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
                            label = "wavySeekThumbScale",
                        )
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .scale(thumbScale)
                                .background(accent, CircleShape),
                        )
                    },
                )
            } else {
                Slider(
                    value = seekValue,
                    onValueChange = onSeekValueChange,
                    onValueChangeFinished = onSeekValueChangeFinished,
                    valueRange = seekValueRange,
                    colors = seekColors,
                    modifier = Modifier.loopRegion(
                        loop = state.loop,
                        durationMs = state.durationMs,
                        color = accent,
                        trackInset = 10.dp,
                    ).timedCommentMarkers(
                        comments = timedComments,
                        durationMs = state.durationMs,
                        activeId = activeComment?.id,
                        color = markerColor,
                        activeColor = accent,
                        trackInset = 10.dp,
                    ),
                )
            }
            }

            },
            primary = {

            Surface(
                onClick = { onTogglePlay() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (compact) 48.dp else 64.dp)
                    .graphicsLayer { scaleX = playScale; scaleY = playScale },
                shape = RoundedCornerShape(50),
                color = accent,
                contentColor = PlayerAccentInk,
            ) {
                Box(contentAlignment = Alignment.Center) {
                    if (state.isBuffering || state.loadingTrackId != null) {
                        LoadingIndicator(
                            modifier = Modifier.size(28.dp),
                            color = PlayerAccentInk,
                        )
                    } else {
                        Icon(
                            if (state.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = stringResource(if (state.isPlaying) R.string.player_pause else R.string.player_play),
                            modifier = Modifier.size(32.dp),
                        )
                    }
                }
            }

            },
            secondary = {

            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PlayerCircleIconButton(
                    size = if (compact) 48.dp else 52.dp,
                    icon = Icons.Filled.Shuffle,
                    contentDescription = stringResource(R.string.player_shuffle),
                    onClick = onToggleShuffle,
                    tint = if (state.shuffleEnabled) accent else palette.onMuted,
                )
                PlayerCircleIconButton(
                    size = if (compact) 48.dp else 52.dp,
                    icon = Icons.Filled.SkipPrevious,
                    contentDescription = stringResource(R.string.player_previous),
                    onClick = onPrev,
                    tint = palette.on,
                )
                PlayerCircleIconButton(
                    size = if (compact) 48.dp else 52.dp,
                    icon = Icons.Filled.SkipNext,
                    contentDescription = stringResource(R.string.player_next),
                    onClick = onNext,
                    tint = palette.on,
                )
                PlayerCircleIconButton(
                    size = if (compact) 48.dp else 52.dp,
                    icon = if (state.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    contentDescription = stringResource(R.string.player_repeat),
                    onClick = onCycleRepeat,
                    tint = if (state.repeatMode != Player.REPEAT_MODE_OFF) accent else palette.onMuted,
                )
            }
        },
        )
        },
    )
    }

    if (showSleepTimer) {
        SleepTimerSheet(controller = controller, onDismiss = { showSleepTimer = false })
    }
    if (showQueue) {
        QueueSheet(controller = controller, onDismiss = { showQueue = false })
    }
    if (showSound) {
        SoundModeSheet(controller = controller, onDismiss = { showSound = false })
    }
    if (showSpeed) {
        PlaybackSpeedSheet(controller = controller, onDismiss = { showSpeed = false })
    }
    if (showLoop) {
        LoopSheet(controller = controller, waveform = waveform, onDismiss = { showLoop = false })
    }
}

@Composable
private fun PlayerCircleIconButton(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
    tint: Color,
    modifier: Modifier = Modifier,
    size: Dp = 52.dp,
    iconSize: Dp = 24.dp,
) {
    val palette = rememberPlayerPalette()
    IconButton(
        onClick = { onClick() },
        modifier = modifier.size(size),
        colors = IconButtonDefaults.iconButtonColors(containerColor = palette.card, contentColor = tint),
    ) {
        Icon(icon, contentDescription = contentDescription, modifier = Modifier.size(iconSize))
    }
}

@Composable
private fun OrbGlow(
    glowColor: Color?,
    isPlaying: Boolean,
    orbSize: Dp,
    pulse: () -> Float = { 0f },
) {
    val colorSpec = tween<Color>(1400, easing = FastOutSlowInEasing)
    val orbA by animateColorAsState(glowColor ?: MaterialTheme.colorScheme.primary, colorSpec, label = "orbColorA")
    val orbB by animateColorAsState(
        glowColor?.let { lerp(it, MaterialTheme.colorScheme.tertiary, 0.55f) } ?: MaterialTheme.colorScheme.tertiary,
        colorSpec,
        label = "orbColorB",
    )
    fun softGradient(c: Color) = Brush.radialGradient(
        0f to c,
        0.55f to c.copy(alpha = c.alpha * 0.55f),
        1f to c.copy(alpha = 0f),
    )

    // Collapses the orb down to a faint speck when paused, and blooms it back out when playback resumes.
    val presence by animateFloatAsState(
        targetValue = if (isPlaying) 1f else 0.1f,
        animationSpec = tween(900, easing = FastOutSlowInEasing),
        label = "orbPresence",
    )
    val presenceAlpha by animateFloatAsState(
        targetValue = if (isPlaying) 1f else 0.3f,
        animationSpec = tween(900, easing = FastOutSlowInEasing),
        label = "orbPresenceAlpha",
    )

    val infiniteTransition = rememberInfiniteTransition(label = "orb")
    val speed = if (isPlaying) 1f else 0.35f
    val angleA by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween((14000 / speed).toInt(), easing = LinearEasing),
        ),
        label = "orbAngleA",
    )
    val angleB by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween((19000 / speed).toInt(), easing = LinearEasing),
        ),
        label = "orbAngleB",
    )
    val breathe by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween((4200 / speed).toInt(), easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "orbBreathe",
    )

    Box(
        modifier = Modifier
            .requiredSize(orbSize)
            .graphicsLayer {
                val bump = 1f + pulse() * ORB_PULSE
                scaleX = breathe * presence * bump; scaleY = breathe * presence * bump
                alpha = presenceAlpha
                val rad = Math.toRadians(angleA.toDouble())
                translationX = (cos(rad) * 70f).toFloat()
                translationY = (sin(rad) * 70f).toFloat()
            }
            .background(softGradient(orbA.copy(alpha = 1f)), CircleShape)
            .blur(46.dp, BlurredEdgeTreatment.Unbounded)
    )
    Box(
        modifier = Modifier
            .requiredSize(orbSize * 0.85f)
            .graphicsLayer {
                val bump = 1f + pulse() * ORB_PULSE
                scaleX = breathe * presence * bump; scaleY = breathe * presence * bump
                alpha = presenceAlpha
                val rad = Math.toRadians(angleB.toDouble())
                translationX = (cos(rad) * 65f).toFloat()
                translationY = (sin(rad) * 65f).toFloat()
            }
            .background(softGradient(orbB.copy(alpha = 1f)), CircleShape)
            .blur(46.dp, BlurredEdgeTreatment.Unbounded)
    )
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun ArtworkOrb(
    artworkUrl: String?,
    artworkSeed: Any?,
    glowColor: Color?,
    isPlaying: Boolean,
    progress: Float,
    slideOffsetX: androidx.compose.animation.core.Animatable<Float, androidx.compose.animation.core.AnimationVector1D>,
    style: com.savoo.scclient.data.repository.PlayerBackgroundStyle = com.savoo.scclient.data.repository.PlayerBackgroundStyle.ORB,
    artworkShape: ArtworkShape = ArtworkShape.SQUARE,
    artworkRingEnabled: Boolean = true,
    modifier: Modifier = Modifier,
    pulse: () -> Float = { 0f },
) {
    val fallback = MaterialTheme.colorScheme.primary
    val presenceAlpha by animateFloatAsState(
        targetValue = if (isPlaying) 1f else 0.3f,
        animationSpec = tween(900, easing = FastOutSlowInEasing),
        label = "orbPresenceAlpha",
    )
    val orbA by animateColorAsState(
        glowColor ?: fallback,
        tween(1400, easing = FastOutSlowInEasing),
        label = "orbColorA",
    )

    val blobShape = rememberArtworkShape(artworkShape)
    val ringColor = orbA.tone(0.45f, Color.White)
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(300, easing = LinearEasing),
        label = "artworkRingProgress",
    )

    // requiredSize lets the orb overflow past the artwork's own bounds (unlike fillMaxWidth, it isn't clamped to the parent's constraints).
    // The inner Box is pinned to exactly artSize so that overflow, so it doesn't push the title/controls below it further down the screen.
    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val artSize = maxWidth
        val orbSize = artSize * 1.1f
        val ringGap = 14.dp
        val ringStroke = 4.dp
        val ringSize = artSize + ringGap * 2 + ringStroke
        Box(modifier = Modifier.size(artSize), contentAlignment = Alignment.Center) {
            if (style == com.savoo.scclient.data.repository.PlayerBackgroundStyle.ORB) {
                OrbGlow(glowColor = glowColor, isPlaying = isPlaying, orbSize = orbSize, pulse = pulse)
            } else if (style == com.savoo.scclient.data.repository.PlayerBackgroundStyle.BLURRED_ARTWORK) {
                // Deliberately bounded (not requiredSize + Unbounded like the orb glow above): an
                // overflowing blurred layer here would transiently clip on every recomposition that
                // reflows this BoxWithConstraints (track change, lyrics toggle, seeking). Staying
                // within the box's own bounds sidesteps that entirely, at the cost of the blur not
                // bleeding past the artwork's edges.
                Crossfade(
                    targetState = artworkUrl,
                    animationSpec = tween(500, easing = FastOutSlowInEasing),
                    label = "blurredBackdrop",
                ) { url ->
                    TrackArtwork(
                        artworkUrl = url,
                        contentDescription = null,
                        seed = artworkSeed,
                        shape = blobShape,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { alpha = presenceAlpha * 0.55f }
                            .blur(36.dp),
                    )
                }
            }
            TrackArtwork(
                artworkUrl = artworkUrl,
                contentDescription = null,
                seed = artworkSeed,
                animated = true,
                shape = blobShape,
                modifier = Modifier
                    .fillMaxSize()
                    .offset { IntOffset(slideOffsetX.value.roundToInt(), 0) },
            )
            if (artworkRingEnabled) {
                Box(
                    modifier = Modifier
                        .requiredSize(ringSize)
                        .artworkProgressRing(blobShape, { animatedProgress }, ringColor, ringStroke),
                )
            }
        }
    }
}
