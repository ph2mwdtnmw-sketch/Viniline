package com.savoo.scclient.auth

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WebLoginSupportTest {
    private val token1 = "2-111111-222222-aaaaaaaaaaaaaaaa"
    private val token2 = "2-333333-444444-bbbbbbbbbbbbbbbb"

    @Test
    fun allowsSoundCloudAndItsLoginHelpers() {
        listOf(
            "soundcloud.com", "secure.soundcloud.com", "api-v2.soundcloud.com",
            "geo.captcha-delivery.com", "accounts.google.com", "www.facebook.com",
            "web.facebook.com", "m.facebook.com", "facebook.com", "idmsa.apple.com",
            "appleid.apple.com", "www.recaptcha.net", "newassets.hcaptcha.com",
        ).forEach { assertTrue("$it should be allowed", isAllowedAuthHost(it)) }
    }

    @Test
    fun blocksEverythingElseAndLookAlikes() {
        listOf(
            "evil.com", "evilsoundcloud.com", "soundcloud.com.evil.com",
            "notfacebook.com", "example.org", "", "  ",
        ).forEach { assertFalse("$it should be blocked", isAllowedAuthHost(it)) }
    }

    @Test
    fun hostMatchingIgnoresCaseAndTrailingDot() {
        assertTrue(isAllowedAuthHost("SoundCloud.com"))
        assertTrue(isAllowedAuthHost("secure.soundcloud.com."))
    }

    @Test
    fun readsTokenFromCookieHeader() {
        assertEquals(token1, oauthTokenFromCookies("sc_anonymous_id=abc; oauth_token=$token1; datadome=zzz"))
        assertNull(oauthTokenFromCookies("sc_anonymous_id=abc; datadome=zzz"))
        assertNull(oauthTokenFromCookies("oauth_token=short"))
        assertNull(oauthTokenFromCookies(null))
    }

    @Test
    fun parsesJavascriptResult() {
        assertEquals(token1, parseHydrationResult("\"token:$token1\""))
        assertNull(parseHydrationResult("\"none\""))
        assertNull(parseHydrationResult("null"))
        assertNull(parseHydrationResult(null))
        assertNull(parseHydrationResult("\"token:tiny\""))
    }

    @Test
    fun theNewestTokenWinsNotTheFirstOne() {
        val c = TokenCandidates()
        assertTrue(c.add(token1)) // seen before sign-in
        assertTrue(c.add(token2)) // seen after sign-in
        assertEquals(listOf(token2, token1), c.newestFirst())
    }

    @Test
    fun duplicatesDoNotReorderUnlessTheyBecomeNewest() {
        val c = TokenCandidates()
        c.add(token1)
        c.add(token2)
        assertFalse(c.add(token2))
        assertTrue(c.add(token1))
        assertEquals(listOf(token1, token2), c.newestFirst())
        assertEquals(2, c.newestFirst().size)
    }

    @Test
    fun ignoresJunkTokens() {
        val c = TokenCandidates()
        assertFalse(c.add(null))
        assertFalse(c.add(""))
        assertFalse(c.add("short"))
        assertTrue(c.isEmpty())
    }

    @Test
    fun classifiesFailures() {
        assertEquals(LoginOutcome.Rejected, classifyLoginFailure(401, false))
        assertEquals(LoginOutcome.Rejected, classifyLoginFailure(403, false))
        assertEquals(LoginOutcome.Network, classifyLoginFailure(null, true))
        assertEquals(LoginOutcome.Failed, classifyLoginFailure(500, false))
        assertEquals(LoginOutcome.Failed, classifyLoginFailure(null, false))
    }
}
