package com.savoo.scclient.ui.screens.account

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.savoo.scclient.auth.TokenCandidates
import com.savoo.scclient.auth.isAllowedAuthHost
import com.savoo.scclient.auth.oauthTokenFromCookies
import com.savoo.scclient.auth.parseHydrationResult
import com.savoo.scclient.debug.DebugLog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

private const val LOG_TAG = "ResonaLogin"

/**
 * Watches the SoundCloud sign-in page and collects the session token it reveals: from the
 * `Authorization` header of the page's own API calls, from the `window.__sc_hydration` blob, and
 * from the `oauth_token` cookie.
 *
 * Nothing here is trusted on its own. The page makes requests before the user has signed in that
 * carry a token for a signed-out session, so every token is kept (newest wins, see
 * [TokenCandidates]) and the caller verifies them against the API before accepting any.
 *
 * The WebView keeps its real user agent: it is no longer disguised as a desktop browser.
 */
class WebViewTokenCapture {
    val candidates = TokenCandidates()

    private val _version = MutableStateFlow(0)

    /** Increases every time a new token shows up. Safe to bump from any thread. */
    val version: StateFlow<Int> = _version

    fun cookies(): String? = CookieManager.getInstance().getCookie("https://soundcloud.com")

    private fun offer(token: String?, source: String) {
        if (candidates.add(token)) {
            DebugLog.log(LOG_TAG, "token candidate from $source")
            _version.update { it + 1 }
        }
    }

    /** Settings every sign-in WebView needs. */
    @SuppressLint("SetJavaScriptEnabled")
    fun configure(webView: WebView) {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
        }
        // The bot check and the social login buttons live in frames from other sites; with
        // third-party cookies off (the WebView default) they cannot keep their own session.
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }
    }

    fun newClient(): WebViewClient = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val host = request.url.host.orEmpty()
            val allowed = isAllowedAuthHost(host)
            if (request.isForMainFrame) {
                DebugLog.log(LOG_TAG, "navigation to $host -> ${if (allowed) "allowed" else "blocked"}")
            }
            return !allowed
        }

        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            val auth = request.requestHeaders?.get("Authorization")
            if (auth != null && auth.startsWith("OAuth ") && request.url.host?.endsWith("soundcloud.com") == true) {
                offer(auth.removePrefix("OAuth "), "Authorization header")
            }
            return super.shouldInterceptRequest(view, request)
        }

        override fun onPageFinished(view: WebView, url: String?) {
            DebugLog.log(LOG_TAG, "page finished: ${url?.substringBefore('?')?.substringBefore('#')}")
            CookieManager.getInstance().flush()
            offer(oauthTokenFromCookies(cookies()), "cookie")
            extractHydrationToken(view) { offer(it, "page data") }
        }
    }
}

private fun extractHydrationToken(view: WebView, onResult: (String?) -> Unit) {
    val js = """
        (function() {
            try {
                var scripts = document.querySelectorAll('script');
                for (var i = 0; i < scripts.length; i++) {
                    var t = scripts[i].textContent || '';
                    if (t.indexOf('__sc_hydration') === -1) continue;
                    var re = /window\.__sc_hydration\s*=\s*(\[[\s\S]*?\])\s*;?\s*$/m;
                    var m = re.exec(t);
                    if (!m) continue;
                    var d = JSON.parse(m[1]);
                    for (var j = 0; j < d.length; j++) {
                        var s = d[j].data && d[j].data.session;
                        if (s && s.oauth_token) return 'token:' + s.oauth_token;
                        if (s && s.access_token) return 'token:' + s.access_token;
                    }
                }
            } catch(e) {}
            return 'none';
        })()
    """.trimIndent()

    view.evaluateJavascript(js) { result -> onResult(parseHydrationResult(result)) }
}
