package com.savoo.scclient.auth

/*
 * Logic for the web sign-in flow, kept free of Android classes so it can be unit-tested on a
 * plain JVM.
 */

/**
 * Hosts a SoundCloud sign-in may legitimately need to visit (the social login providers, the bot
 * check, and its captcha frames). Everything else stays blocked so the login page can never turn
 * into an open browser.
 */
internal val ALLOWED_AUTH_HOSTS = listOf(
    "soundcloud.com",
    "sndcdn.com",
    "captcha-delivery.com",
    "datadome.co",
    "google.com",
    "gstatic.com",
    "recaptcha.net",
    "hcaptcha.com",
    "accounts.youtube.com",
    "facebook.com",
    "apple.com",
)

/** True for the host itself or any of its subdomains, never for look-alikes such as `evilsoundcloud.com`. */
fun isAllowedAuthHost(host: String): Boolean {
    val h = host.trim().lowercase().trimEnd('.')
    if (h.isEmpty()) return false
    return ALLOWED_AUTH_HOSTS.any { h == it || h.endsWith(".$it") }
}

private const val MIN_TOKEN_LENGTH = 20

/** The `oauth_token` cookie SoundCloud's own site sets for a signed-in browser session. */
fun oauthTokenFromCookies(cookies: String?): String? =
    cookies?.split(";")
        ?.map { it.trim() }
        ?.firstOrNull { it.startsWith("oauth_token=") }
        ?.substringAfter("=")
        ?.trim()
        ?.takeIf { it.length > MIN_TOKEN_LENGTH }

/**
 * Turns the raw result of `evaluateJavascript` (a JSON string such as `"token:2-123..."`) into the
 * token, or null when the page did not have one.
 */
fun parseHydrationResult(raw: String?): String? {
    val unwrapped = raw?.removeSurrounding("\"")?.replace("\\\"", "\"") ?: return null
    if (!unwrapped.startsWith("token:")) return null
    return unwrapped.removePrefix("token:").trim().takeIf { it.length > MIN_TOKEN_LENGTH }
}

/**
 * Every token the sign-in page revealed, newest last. The page also makes requests before the user
 * has signed in, and those carry a token for a signed-out session, so the FIRST token seen must
 * not win: the one that matters usually arrives last. Each candidate is verified against the API
 * before it is accepted.
 */
class TokenCandidates {
    private val tokens = ArrayList<String>()

    /** Adds [token]; returns true when it is new or became the newest one. */
    @Synchronized
    fun add(token: String?): Boolean {
        val t = token?.trim().orEmpty()
        if (t.length <= MIN_TOKEN_LENGTH) return false
        if (tokens.lastOrNull() == t) return false
        tokens.remove(t)
        tokens.add(t)
        return true
    }

    /** Most recently seen first. */
    @Synchronized
    fun newestFirst(): List<String> = tokens.asReversed().toList()

    @Synchronized
    fun isEmpty(): Boolean = tokens.isEmpty()
}

sealed interface LoginOutcome {
    /** Signed in, the account was loaded. */
    data object Success : LoginOutcome

    /** The page has not revealed any token yet (not signed in, or not finished loading). */
    data object NoToken : LoginOutcome

    /** SoundCloud refused every token we found (HTTP 401/403): still signed out, or session not valid. */
    data object Rejected : LoginOutcome

    /** No connection, so nothing could be verified. */
    data object Network : LoginOutcome

    /** Anything else. */
    data object Failed : LoginOutcome
}

fun classifyLoginFailure(httpCode: Int?, isNetwork: Boolean): LoginOutcome = when {
    httpCode == 401 || httpCode == 403 -> LoginOutcome.Rejected
    isNetwork -> LoginOutcome.Network
    else -> LoginOutcome.Failed
}
