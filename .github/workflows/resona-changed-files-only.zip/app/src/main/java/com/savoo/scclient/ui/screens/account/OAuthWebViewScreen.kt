package com.savoo.scclient.ui.screens.account

import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.savoo.scclient.R
import com.savoo.scclient.auth.LoginOutcome
import com.savoo.scclient.auth.oauthTokenFromCookies
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * SoundCloud's own sign-in page. The user types their details straight into SoundCloud's page:
 * the app never sees a password. When the page reveals a session token, it is verified against
 * the API (see AccountViewModel.completeWebLogin) and the screen closes by itself on success.
 * The "Done" button is only a manual fallback.
 */
@Composable
fun OAuthWebViewScreen(
    startUrl: String,
    onSessionCaptured: suspend (tokens: List<String>, cookies: String?) -> LoginOutcome,
    onCancel: () -> Unit,
) {
    val capture = remember { WebViewTokenCapture() }
    var popupWebView by remember { mutableStateOf<WebView?>(null) }
    var verifying by remember { mutableStateOf(false) }
    val rejectedTokens = remember { mutableSetOf<String>() }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    fun say(message: String) {
        scope.launch { snackbarHostState.showSnackbar(message) }
    }

    /** [manual] is true when the user pressed Done: then everything is tried again and every failure is explained. */
    suspend fun attempt(manual: Boolean) {
        if (manual) capture.candidates.add(oauthTokenFromCookies(capture.cookies()))
        val all = capture.candidates.newestFirst()
        val tokens = if (manual) all else all.filter { it !in rejectedTokens }
        if (tokens.isEmpty()) {
            if (manual) say(context.getString(R.string.login_browser_not_signed_in))
            return
        }
        verifying = true
        val outcome = try {
            onSessionCaptured(tokens, capture.cookies())
        } finally {
            verifying = false
        }
        when (outcome) {
            LoginOutcome.Success -> Unit // the account screen takes over
            LoginOutcome.Rejected -> {
                // Usually the token of a signed-out session; the real one arrives after sign-in.
                rejectedTokens.addAll(tokens)
                if (manual) say(context.getString(R.string.login_error_rejected))
            }
            LoginOutcome.Network -> say(context.getString(R.string.login_error_network))
            LoginOutcome.NoToken -> if (manual) say(context.getString(R.string.login_browser_not_signed_in))
            LoginOutcome.Failed -> if (manual) say(context.getString(R.string.login_error_unknown))
        }
    }

    // Try automatically whenever the page reveals a new token.
    LaunchedEffect(capture) {
        capture.version.collectLatest { version ->
            if (version > 0) {
                delay(600) // let the page settle; a newer token cancels this attempt and replaces it
                attempt(manual = false)
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    capture.configure(this)
                    webViewClient = capture.newClient()
                    webChromeClient = object : WebChromeClient() {
                        override fun onCreateWindow(
                            view: WebView,
                            isDialog: Boolean,
                            isUserGesture: Boolean,
                            resultMsg: android.os.Message,
                        ): Boolean {
                            val popup = WebView(ctx).apply {
                                capture.configure(this)
                                webViewClient = capture.newClient()
                                webChromeClient = object : WebChromeClient() {
                                    override fun onCloseWindow(window: WebView) {
                                        popupWebView = null
                                        window.destroy()
                                    }
                                }
                            }
                            popupWebView = popup
                            val transport = resultMsg.obj as WebView.WebViewTransport
                            transport.webView = popup
                            resultMsg.sendToTarget()
                            return true
                        }
                    }
                    loadUrl(startUrl)
                }
            },
        )

        popupWebView?.let { popup ->
            AndroidView(modifier = Modifier.fillMaxSize(), factory = { popup })

            IconButton(
                onClick = {
                    popup.destroy()
                    popupWebView = null
                },
                modifier = Modifier.align(Alignment.TopEnd).padding(16.dp),
            ) {
                Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.close))
            }
        }

        IconButton(
            onClick = onCancel,
            modifier = Modifier.align(Alignment.TopStart).padding(16.dp),
        ) {
            Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.close))
        }

        if (verifying) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                tonalElevation = 6.dp,
                shadowElevation = 6.dp,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 20.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        stringResource(R.string.login_verifying),
                        style = MaterialTheme.typography.labelLarge,
                    )
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = { scope.launch { attempt(manual = true) } },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
        ) {
            Icon(Icons.Filled.Check, contentDescription = null)
            Text(stringResource(R.string.done), modifier = Modifier.padding(start = 8.dp))
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 88.dp),
        )
    }
}
