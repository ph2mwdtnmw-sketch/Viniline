package com.savoo.scclient.auth

import android.content.Context
import android.content.SharedPreferences
import com.savoo.scclient.data.local.createSecurePrefs
import com.savoo.scclient.data.model.TokenResponse
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TokenStore @Inject constructor(
    @ApplicationContext context: Context
) {
    private val prefs: SharedPreferences = createSecurePrefs(context, "sc_auth_secure_prefs")

    private val _isLoggedIn = MutableStateFlow(accessToken != null)
    val isLoggedIn = _isLoggedIn.asStateFlow()

    var accessToken: String?
        get() = prefs.getString(KEY_ACCESS, null)
        private set(value) { prefs.edit().putString(KEY_ACCESS, value).apply() }

    var refreshToken: String?
        get() = prefs.getString(KEY_REFRESH, null)
        private set(value) { prefs.edit().putString(KEY_REFRESH, value).apply() }

    fun save(token: TokenResponse) {
        accessToken = token.accessToken
        refreshToken = token.refreshToken
        _isLoggedIn.value = true
    }

    /**
     * Stores a web session WITHOUT signing the user in yet. The API client reads the same
     * preferences, so the session can be tried out (see AccountViewModel.completeWebLogin)
     * before the app switches to the signed-in state, and the token and the cookies always
     * arrive together.
     */
    fun stageSession(token: String, cookies: String?) {
        prefs.edit().apply {
            putString(KEY_ACCESS, token)
            remove(KEY_REFRESH)
            if (cookies.isNullOrBlank()) remove(KEY_COOKIES) else putString(KEY_COOKIES, cookies)
        }.apply()
    }

    /** The staged session worked: the user is now signed in. */
    fun commitSession() {
        _isLoggedIn.value = true
    }

    /** The staged session did not work: forget it. */
    fun rollbackSession() {
        prefs.edit().clear().apply()
        _isLoggedIn.value = false
    }

    fun saveWebToken(accessTokenValue: String) {
        accessToken = accessTokenValue
        _isLoggedIn.value = true
    }

    fun saveCookies(cookies: String) {
        webCookies = cookies
    }

    fun replaceCookie(pair: String) {
        val name = pair.substringBefore("=")
        val kept = webCookies.orEmpty().split(";")
            .map { it.trim() }
            .filter { it.isNotEmpty() && it.substringBefore("=") != name }
        webCookies = (kept + pair).joinToString("; ")
    }

    var webCookies: String?
        get() = prefs.getString(KEY_COOKIES, null)
        private set(value) { prefs.edit().putString(KEY_COOKIES, value).apply() }

    fun clear() {
        prefs.edit().clear().apply()
        _isLoggedIn.value = false
    }

    companion object {
        private const val KEY_ACCESS = "access_token"
        private const val KEY_REFRESH = "refresh_token"
        private const val KEY_COOKIES = "web_cookies"
    }
}
