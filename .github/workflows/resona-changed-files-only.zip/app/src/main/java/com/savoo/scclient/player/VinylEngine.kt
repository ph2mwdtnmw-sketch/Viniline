package com.savoo.scclient.player

import kotlin.concurrent.Volatile
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/*
 * Pure Kotlin DSP for the vinyl feel. No Android or Media3 imports on purpose, so the logic can be
 * unit-tested and benchmarked on a plain JVM. Nothing here allocates per sample.
 */

/**
 * Synthesised record surface noise: a soft hiss, small ticks, the odd low pop, and a "needle drop"
 * thump followed by a few seconds of denser crackle.
 */
class VinylNoise(private val sampleRate: Int, initialSeed: Int = 0x2545F491) {
    private var seed = if (initialSeed == 0) 0x2545F491 else initialSeed
    private var hissLowpass = 0f
    private var tickEnvelope = 0f
    private var popEnvelope = 0f
    private var popLowpass = 0f
    private var dropSamplesLeft = 0
    private var dropSamplesTotal = 1

    private val tickDecay = exp(-1f / (sampleRate * 0.0007f))
    private val popDecay = exp(-1f / (sampleRate * 0.006f))
    private val ticksPerSample = TICKS_PER_SECOND / sampleRate
    private val popsPerSample = POPS_PER_SECOND / sampleRate

    fun needleDrop() {
        dropSamplesTotal = (sampleRate * DROP_SECONDS).toInt().coerceAtLeast(1)
        dropSamplesLeft = dropSamplesTotal
        popEnvelope = DROP_THUMP
    }

    /** Next mono noise sample. [level] is 0..1. [extraHiss] adds hiss (used for scratch friction). */
    fun next(level: Float, extraHiss: Float = 0f): Float {
        if (level <= 0f) {
            // Noise is switched off: stay completely silent (and forget any pending needle drop).
            tickEnvelope = 0f
            popEnvelope = 0f
            dropSamplesLeft = 0
            if (extraHiss <= 0f) return 0f
            val white = random() * 2f - 1f
            hissLowpass += (white - hissLowpass) * HISS_LOWPASS
            return (white - hissLowpass) * SCRATCH_HISS_AMPLITUDE * extraHiss
        }
        val boost = if (dropSamplesLeft > 0) {
            dropSamplesLeft--
            dropSamplesLeft.toFloat() / dropSamplesTotal
        } else {
            0f
        }
        val white = random() * 2f - 1f
        hissLowpass += (white - hissLowpass) * HISS_LOWPASS
        val highPassed = white - hissLowpass

        var out = 0f
        run {
            val boosted = level * (1f + 2f * boost)
            out += highPassed * HISS_AMPLITUDE * (level + 0.5f * boost)

            // One dice roll per sample decides between "tick", "pop" or nothing.
            val roll = random()
            val tickChance = ticksPerSample * boosted
            if (roll < tickChance) {
                val r = random()
                tickEnvelope = (0.02f + 0.20f * r * r * r) * (0.4f + 0.6f * level)
            } else if (roll < tickChance + popsPerSample * boosted) {
                popEnvelope = max(popEnvelope, (0.05f + 0.12f * random()) * (0.5f + 0.5f * level))
            }
        }
        // The envelopes are zero almost all the time, so skip the work then.
        if (tickEnvelope > SILENT) {
            out += tickEnvelope * (random() * 2f - 1f)
            tickEnvelope *= tickDecay
        } else {
            tickEnvelope = 0f
        }
        if (popEnvelope > SILENT) {
            popLowpass += (white - popLowpass) * POP_LOWPASS
            out += popEnvelope * popLowpass * POP_GAIN
            popEnvelope *= popDecay
        } else {
            popEnvelope = 0f
            popLowpass = 0f
        }

        if (extraHiss > 0f) out += highPassed * SCRATCH_HISS_AMPLITUDE * extraHiss
        return out
    }

    private fun random(): Float {
        // xorshift32 -> [0, 1)
        var x = seed
        x = x xor (x shl 13)
        x = x xor (x ushr 17)
        x = x xor (x shl 5)
        seed = x
        return (x ushr 8) / 16777216f
    }

    private companion object {
        const val HISS_AMPLITUDE = 0.02f
        const val HISS_LOWPASS = 0.12f
        const val SCRATCH_HISS_AMPLITUDE = 0.03f
        const val TICKS_PER_SECOND = 14f
        const val POPS_PER_SECOND = 0.5f
        const val POP_LOWPASS = 0.04f
        const val POP_GAIN = 8f
        const val DROP_SECONDS = 2.2f
        const val DROP_THUMP = 0.2f
        const val SILENT = 0.0003f
    }
}

/**
 * The last few seconds of audio that went through the effects processor, stereo, as floats.
 *
 * One thread (the audio processor) writes and calls [commit] once per chunk; another thread (the
 * scratch voice) reads. Only [committed] is volatile, so the per-sample write path has no memory
 * barrier. The reader never reads closer to the write head than the last commit, and never further
 * back than [MAX_LAG_FRAMES] behind it, which keeps it away from the slots being overwritten.
 */
class ScratchHistory(val sampleRate: Int) {
    val capacity: Int = sampleRate * HISTORY_SECONDS
    internal val data = FloatArray(capacity * 2)

    /** Total frames committed since the last [reset]. */
    @Volatile
    var committed: Long = 0L
        private set

    private var pending = 0L
    private var writeIndex = 0

    /** Largest distance behind the newest frame that is safe to read. */
    val maxLagFrames: Int get() = capacity - sampleRate / 4

    fun write(left: Float, right: Float) {
        val slot = writeIndex * 2
        data[slot] = left
        data[slot + 1] = right
        writeIndex++
        if (writeIndex == capacity) writeIndex = 0
        pending++
    }

    fun commit() {
        committed = pending
    }

    fun reset() {
        pending = 0L
        writeIndex = 0
        committed = 0L
    }

    companion object {
        const val HISTORY_SECONDS = 3
    }
}

/**
 * The scratch sound. It reads [ScratchHistory] at the speed and direction of the finger and renders
 * small blocks of 16-bit stereo PCM, meant to be written straight to a low-latency AudioTrack.
 *
 * Speed 1 = the history played forward at its normal rate, negative = backwards, 0 = held still
 * (silence, with a short fade so a constant value never clicks). Everything here is allocation free.
 */
class ScratchVoice(
    private val history: ScratchHistory,
    private val noiseLeft: VinylNoise,
    private val noiseRight: VinylNoise,
    /** How loud the shuffling sound of the finger on the record is, 0..1. */
    private val frictionAmount: Float = 1f,
) {
    private val sampleRate = history.sampleRate
    private var readPos = 0.0
    private var speed = 0f
    private var gain = 0f
    private var atBackEdge = false

    private val speedCoef = 1f - exp(-1f / (sampleRate * 0.012f))
    private val gainUpStep = 1f / (sampleRate * 0.004f)
    private val gainDownStep = 1f / (sampleRate * 0.012f)

    /**
     * Start reading [latencyFrames] behind the newest audio. The audio the listener actually hears
     * is that far behind what the processor has already seen (it sits in the player's output buffer),
     * so this is where "now" really is.
     */
    fun begin(initialSpeed: Float, latencyFrames: Int) {
        val newest = (history.committed - 1).coerceAtLeast(0L)
        readPos = (newest - latencyFrames).coerceAtLeast(0L).toDouble()
        speed = initialSpeed
        gain = 0f
        atBackEdge = false
    }

    /**
     * Fill [out] (interleaved stereo, [frames] frames). Returns false once [active] is false and the
     * voice has faded out completely, i.e. the caller can stop.
     */
    fun render(out: ShortArray, frames: Int, active: Boolean, targetSpeed: Float, noiseLevel: Float): Boolean =
        renderCore(frames, active, targetSpeed, noiseLevel) { n, l, r ->
            out[n * 2] = toShort(l)
            out[n * 2 + 1] = toShort(r)
        }

    /** Same as [render] but into two float channels (-1..1), for audio APIs that want floats. */
    fun renderFloat(
        left: FloatArray,
        right: FloatArray,
        frames: Int,
        active: Boolean,
        targetSpeed: Float,
        noiseLevel: Float,
    ): Boolean = renderCore(frames, active, targetSpeed, noiseLevel) { n, l, r ->
        left[n] = if (l > 1f) 1f else if (l < -1f) -1f else l
        right[n] = if (r > 1f) 1f else if (r < -1f) -1f else r
    }

    private inline fun renderCore(
        frames: Int,
        active: Boolean,
        targetSpeed: Float,
        noiseLevel: Float,
        sink: (Int, Float, Float) -> Unit,
    ): Boolean {
        val committed = history.committed
        val capacity = history.capacity
        val data = history.data
        val newest = (committed - 1).toDouble()
        val oldest = maxOf(0L, committed - history.maxLagFrames).toDouble()
        val headIndex = (committed % capacity).toInt() // slot of the next write == newest + 1

        for (n in 0 until frames) {
            speed += (targetSpeed - speed) * speedCoef
            gain = if (active) minOf(1f, gain + gainUpStep) else maxOf(0f, gain - gainDownStep)

            readPos += speed
            atBackEdge = false
            if (readPos >= newest) {
                readPos = newest
            } else if (readPos <= oldest) {
                readPos = oldest
                atBackEdge = speed < 0f
            }

            var left = 0f
            var right = 0f
            if (committed > 1L) {
                val i0 = floor(readPos).toLong()
                val frac = (readPos - i0).toFloat()
                val lag0 = (newest - i0).toInt()
                var a = headIndex - 1 - lag0
                if (a < 0) a += capacity
                var b = a + 1
                if (b == capacity) b = 0
                if (lag0 == 0) b = a // nothing newer to interpolate towards
                a *= 2
                b *= 2
                left = data[a] + (data[b] - data[a]) * frac
                right = data[a + 1] + (data[b + 1] - data[a + 1]) * frac
            }

            // Quieter when nearly stopped (a constant value would be a DC click), silent when stuck
            // against the end of the history.
            val speedGain = if (atBackEdge) 0f else minOf(1f, abs(speed) / FULL_GAIN_SPEED)
            val g = gain * speedGain
            val friction = minOf(1f, abs(speed)) * gain * frictionAmount
            var l = left * g
            var r = right * g
            if (noiseLevel > 0f || friction > 0f) {
                l += noiseLeft.next(noiseLevel * gain, friction)
                r += noiseRight.next(noiseLevel * gain, friction)
            }
            sink(n, l, r)
        }
        return active || gain > 0f
    }

    private fun toShort(v: Float): Short {
        val x = (v * 32767f).toInt()
        return (if (x > 32767) 32767 else if (x < -32768) -32768 else x).toShort()
    }

    private companion object {
        const val FULL_GAIN_SPEED = 0.12f
    }
}
